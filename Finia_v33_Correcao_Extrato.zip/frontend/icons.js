/* global window, document */

import {
  ArrowLeft,
  BookOpen,
  CarFront,
  ChartNoAxesCombined,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  CirclePlus,
  Gamepad2,
  Gauge,
  HeartPulse,
  House,
  KeyRound,
  Landmark,
  LaptopMinimal,
  LogOut,
  ReceiptText,
  RefreshCw,
  Settings,
  Shapes,
  Sparkles,
  Utensils,
  UserRound,
  WalletCards,
  createIcons
} from 'lucide';

const icons = {
  ArrowLeft,
  BookOpen,
  CarFront,
  ChartNoAxesCombined,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  CirclePlus,
  Gamepad2,
  Gauge,
  HeartPulse,
  House,
  KeyRound,
  Landmark,
  LaptopMinimal,
  LogOut,
  ReceiptText,
  RefreshCw,
  Settings,
  Shapes,
  Sparkles,
  Utensils,
  UserRound,
  WalletCards
};

window.FiniaIcons = Object.freeze({
  render(root = document) {
    createIcons({
      icons,
      root,
      attrs: {
        'aria-hidden': 'true',
        'stroke-width': '1.65'
      }
    });
  }
});

window.FiniaIcons.render();
