/* Guided analysis: deterministic calculations, no external AI; conversation kept for this browser session. */
(() => {
  'use strict';
  const civil = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  function range(month, today = civil(new Date())) {
    const [year, m] = month.split('-').map(Number);
    const last = civil(new Date(year,m,0));
    return { from: `${month}-01`, to: last < today ? last : today };
  }
  function invoiceRange(month, closing) {
    const [year,m]=month.split('-').map(Number);
    const close=(y,mo)=>new Date(y,mo,Math.min(Number(closing),new Date(y,mo+1,0).getDate()));
    const end=close(year,m-1);end.setDate(end.getDate()-1);
    return {from:civil(close(year,m-2)),to:civil(end)};
  }
  function periodFor(scope, today) {
    return scope.mode==='invoice'?invoiceRange(scope.month,scope.closing):range(scope.month,today);
  }
  function expenses(transactions, wallets, scope, today) {
    const period=periodFor(scope,today), fallback=wallets.find(w=>w.padrao)?.id;
    return transactions.filter(t=> {
      const date=String(t.data_lancamento || '').slice(0,10);
      return t.tipo==='saida' && Number.isFinite(Number(t.valor)) && date>=period.from && date<=period.to
        && (scope.wallet==='all' || String(t.carteira_id || fallback)===String(scope.wallet))
        && (!scope.day || date===scope.day) && (!scope.category || t.categoria===scope.category);
    });
  }
  const sum = rows => rows.reduce((total,t)=>total+Math.round(Number(t.valor)*100),0)/100;
  function groups(rows, key) {
    const totals = new Map();
    rows.forEach(t=>{const k=key(t);totals.set(k,(totals.get(k)||0)+Math.round(Number(t.valor)*100));});
    return [...totals].map(([key,cents])=>({key,value:cents/100})).sort((a,b)=>b.value-a.value || String(a.key).localeCompare(String(b.key)));
  }
  function previous(scope, today=civil(new Date())) {
    const [year,m]=scope.month.split('-').map(Number), date=new Date(year,m-2,1);
    const month=civil(date).slice(0,7), period=periodFor({...scope,month},today);
    if(scope.mode!=='invoice' && scope.month===today.slice(0,7)) period.to=`${month}-${String(Math.min(Number(today.slice(8)),new Date(year,m-1,0).getDate())).padStart(2,'0')}`;
    return {...period,month};
  }
  if(typeof module!=='undefined' && module.exports) { module.exports={range,invoiceRange,periodFor,expenses,sum,groups,previous}; return; }
  let owner=null, context=null, busy=false, pendingReply=null, pendingDelivery=null, history=[];
  const storageKey='finia-assistant-session-v32';
  const $=id=>document.getElementById(id);
  const money=value=>fmt(value);
  const monthName=month=>new Date(`${month}-01T12:00:00`).toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
  const categoryName=key=>getCategoryLabel(key)||key;
  const rows=scope=>expenses(state.transactions,state.wallets,scope);
  const base=()=>({...context});
  const question=(label,action,scope=base())=>({label,action,scope:{...scope}});
  function starters(page=0) {
    const items=[question('Quanto gastei no período?','summary'),question('Qual dia teve mais gastos?','day'),question('Qual categoria mais pesou?','category'),question(context.mode==='invoice'?'Gastei mais que na fatura anterior?':'Gastei mais que no mês anterior?','compare'),question('Qual foi minha maior compra?','purchase'),question('Quais foram minhas 3 maiores categorias?','topCategories'),question('Quais foram minhas 3 maiores compras?','topPurchases'),question('Qual foi o valor médio por lançamento?','average'),question('Em quantos dias tive gastos?','frequency'),...(context.mode==='invoice'?[]:[question('Como estou em relação ao limite?','limit')]),question('Escolher outra organização ou período','scope')];
    const start=page*3, choices=items.slice(start,start+3);
    if(start+3<items.length)choices.push(question('Mais perguntas','more',{...base(),page:page+1}));
    return choices;
  }
  function save() {
    if(!owner)return;
    try{sessionStorage.setItem(storageKey,JSON.stringify({owner,context,history,pendingDelivery}));}catch{}
  }
  function clearChoices() {
    $('assistant-log').querySelectorAll('.assistant-choices,.assistant-period-form').forEach(el=>el.remove());
    history.forEach(item=>{item.actions=[];item.ui=null;});save();
  }
  function scrollToLatest(node) {
    if(!$('screen-assistant').classList.contains('active'))return;
    const log=$('assistant-log'), row=node?.parentElement;
    const top=row?log.scrollTop+row.getBoundingClientRect().top-log.getBoundingClientRect().top-16:log.scrollHeight;
    log.scrollTo({top,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  }
  function addPeriodForm(article) {
    const form=document.createElement('form');form.className='assistant-period-form';
    const label=document.createElement('label');label.textContent=context.mode==='invoice'?'Fatura (mês de fechamento)':'Mês da análise';
    const input=document.createElement('input');input.type='month';input.required=true;input.setAttribute('aria-label',label.textContent);
    input.value=context.month || (context.mode==='invoice'?invoiceMonthFor(civil(new Date()),context.closing):civil(new Date()).slice(0,7));
    if(context.mode!=='invoice')input.max=civil(new Date()).slice(0,7);
    input.addEventListener('input',()=>{history.at(-1).ui={month:input.value};save();});
    label.append(input);
    const button=document.createElement('button');button.type='submit';button.textContent=context.mode==='invoice'?'Analisar fatura':'Analisar mês';
    form.append(label,button);
    form.addEventListener('submit',event=>{event.preventDefault();if(form.reportValidity())ask(question((context.mode==='invoice'?'Fatura de ':'')+monthName(input.value),'period',{...context,month:input.value}));});
    article.append(form);return input;
  }
  function message(text, user=false, actions=[], ui=null, remember=true) {
    if(actions.length>4 && actions[0]?.action==='summary' && actions[1]?.action==='day'){
      actions=[...actions.slice(0,3),question('Mais perguntas','more',{...actions[0].scope,page:1})];
    }
    const row=document.createElement('div');row.className=`assistant-row ${user?'assistant-row-user':'assistant-row-bot'}`;
    const avatar=document.createElement('span');avatar.className='assistant-avatar';avatar.setAttribute('aria-hidden','true');
    avatar.textContent=user?(state.user?.nome_completo?.charAt(0).toUpperCase() || 'U'):'F';
    if(user && state.token && state.user?.avatar?.presente!==false){
      const img=document.createElement('img');img.alt='';img.src=`${API_URL}/user/profile/avatar?v=${encodeURIComponent(state.user.avatar?.atualizado_em || state.user.id || 'current')}`;
      img.addEventListener('error',()=>img.remove());avatar.append(img);
    }
    const article=document.createElement('article');article.className=`assistant-message ${user?'assistant-user':'assistant-bot'}`;
    const label=document.createElement('small');label.textContent=user?'Você':'Finia';article.append(label);
    const paragraph=document.createElement('p');
    text.split(/(R\$\s?[\d.,]+)/g).forEach(part=>{
      if(part.startsWith('R$')){const strong=document.createElement('strong');strong.textContent=part;paragraph.append(strong);}
      else paragraph.append(document.createTextNode(part));
    });
    article.append(paragraph);
    if(actions.length){
      const choices=document.createElement('div');choices.className='assistant-choices';
      actions.forEach(choice=>{const button=document.createElement('button');button.type='button';button.textContent=choice.label;if(choice.action==='menu')button.className='assistant-other';button.addEventListener('click',()=>ask(choice));choices.append(button);});article.append(choices);
    }
    if(ui){const input=addPeriodForm(article);if(ui.month)input.value=ui.month;}
    row.append(avatar,article);$('assistant-log').append(row);
    if(remember){history.push({text,user,actions,ui});save();}
    return article;
  }
  function cancelReply() {
    if(pendingReply){clearTimeout(pendingReply.timer);pendingReply.finish(false);pendingReply=null;}
    busy=false;
    pendingDelivery=null;
  }
  function typingPause() {
    busy=true;
    const bubble=message('',false,[],null,false);bubble.classList.add('assistant-typing');
    bubble.setAttribute('aria-label','Finia está digitando');
    const dots=bubble.querySelector('p');dots.className='assistant-dots';dots.setAttribute('aria-hidden','true');
    for(let i=0;i<3;i++)dots.append(document.createElement('span'));
    scrollToLatest(bubble);
    return new Promise(finish=>{
      pendingReply={finish,timer:setTimeout(()=>{
        pendingReply=null;bubble.parentElement.remove();busy=false;finish(true);
      },1800+Math.random()*600)};
    });
  }
  async function reply(text, actions=[], ui=null) {
    pendingDelivery={text,actions,ui};save();
    if(!await typingPause())return;
    pendingDelivery=null;
    const node=message(text,false,actions,ui);scrollToLatest(node);
  }
  function updateContext() {
    const wallet=context?.wallet==='all'?'Todas as organizações':state.wallets.find(w=>String(w.id)===context?.wallet)?.nome || 'Organização';
    $('assistant-context').textContent=context?.month?`${context.mode==='invoice'?'Fatura de ':''}${monthName(context.month)} · ${wallet}`:context?.wallet?`${wallet} · Escolha ${context.mode==='invoice'?'a fatura':'o mês'}`:'Vamos começar pela organização';
  }
  function organizations() {
    return [question('Todas as organizações','wallet',{wallet:'all',mode:'month'}),...state.wallets.map(w=>question(w.nome,'wallet',{wallet:String(w.id),mode:w.tipo==='credito'?'invoice':'month',closing:Number(w.dia_fechamento)||null}))];
  }
  function reset() {
    cancelReply();owner=null;context=null;history=[];
    try{sessionStorage.removeItem(storageKey);}catch{}
    $('assistant-log')?.replaceChildren();
  }
  function restart() {
    reset();if(!state.user)return;owner=String(state.user.id);updateContext();
    message('Qual organização você quer analisar?',false,organizations());
  }
  function open() {
    if(!state.user){reset();return;}
    const id=String(state.user.id);
    if(owner===id && history.length){updateContext();return;}
    let saved;
    try{saved=JSON.parse(sessionStorage.getItem(storageKey));}catch{}
    if(saved?.owner===id && Array.isArray(saved.history) && saved.history.length){
      cancelReply();owner=id;context=saved.context;history=[];$('assistant-log').replaceChildren();
      saved.history.forEach(item=>message(item.text,item.user,item.actions,item.ui));
      if(saved.pendingDelivery){const item=saved.pendingDelivery;message(item.text,false,item.actions,item.ui);}
      updateContext();requestAnimationFrame(()=>scrollToLatest($('assistant-log').lastElementChild?.querySelector('article')));return;
    }
    restart();
  }
  async function ask(choice) {
    if(busy||!state.user || String(state.user.id)!==owner)return;
    if(choice.action==='report'){
      const period=periodFor(choice.scope);
      state.walletFilter=choice.scope.wallet;
      state.detailFilters=choice.scope.mode==='invoice' && !choice.scope.day?{period:'invoice',invoiceMonth:choice.scope.month,type:'saida',category:choice.scope.category||'all'}:{period:'between',type:'saida',category:choice.scope.category||'all',dateFrom:choice.scope.day||period.from,dateTo:choice.scope.day||period.to};
      state.heatmapMonth=choice.scope.month;state.selectedTransactionIds.clear();
      busy=true;
      try {await goTo('screen-detail');}catch{showToast('Não foi possível abrir os lançamentos. Tente novamente.','error');}finally{busy=false;}
      return;
    }
    clearChoices();message(choice.label,true);
    if(choice.action==='scope'){
      await reply('Qual organização você quer analisar agora?',organizations());return;
    }
    if(choice.action==='wallet'){
      const wallet=state.wallets.find(w=>String(w.id)===choice.scope.wallet);
      if(choice.scope.wallet!=='all' && !wallet){await reply('Essa organização não está mais disponível. Escolha outra.',organizations());return;}
      context={wallet:choice.scope.wallet,mode:wallet?.tipo==='credito'?'invoice':'month',closing:Number(wallet?.dia_fechamento)||null,month:null};
      if(context.mode==='invoice' && (!context.closing || context.closing<1 || context.closing>31)){
        updateContext();await reply('Cadastre o dia de fechamento desse cartão em Organizações para analisar suas faturas. Depois, escolha o cartão novamente.',organizations());return;
      }
      updateContext();
      await reply(context.mode==='invoice'?'Qual fatura você quer analisar? Escolha o mês de fechamento da fatura.':'Qual mês você quer analisar?',[],{});return;
    }
    if(choice.action==='period'){
      if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(choice.scope.month))return;
      context={...choice.scope};updateContext();
      await reply(context.mode==='invoice'?'Fatura selecionada. O que você quer descobrir?':'Mês selecionado. O que você quer descobrir?',starters());return;
    }
    if(!context?.month)return;
    const scope=choice.scope, selected=rows(scope), total=sum(selected);
    let answer='', next=[];
    const report=(label='Ver lançamentos',target=scope)=>question(label,'report',target);
    if(choice.action==='menu'){
      answer='O que mais você quer descobrir nesse período?';next=starters();
    }else if(choice.action==='more'){
      answer='Aqui estão mais perguntas para explorar seus gastos.';next=starters(Number(scope.page)||1);
    }else if(choice.action!=='limit' && choice.action!=='compare' && !selected.length){
      answer='Não há despesas registradas nesse período e organização para esta análise. Você pode escolher outra organização ou período em Outra análise.';
      next=[question('Outra análise','menu')];
    }else if(choice.action==='day'){
      const ranked=groups(selected,t=>String(t.data_lancamento).slice(0,10)), best=ranked[0];
      const target={...scope,day:best.key}, count=rows(target).length, ties=ranked.filter(g=>g.value===best.value).length;
      answer=`Seu maior gasto diário foi em ${fmtDate(best.key)}: ${money(best.value)}, em ${count} lançamento${count===1?'':'s'}.${ties>1?' Há '+ties+' dias empatados nesse valor; mostrei o primeiro.':''}`;
      next=[question('Qual categoria mais pesou nesse dia?','category',target),report('Ver lançamentos desse dia',target),question('Qual categoria mais pesou no período?','category')];
    }else if(choice.action==='category'){
      const ranked=groups(selected,t=>t.categoria), best=ranked[0], target={...scope,category:best.key};
      answer=`${categoryName(best.key)} foi a maior categoria${scope.day?' nesse dia':' no período'}: ${money(best.value)}${total>0?', equivalente a '+Math.round(best.value/total*100)+'% das despesas':''}.${ranked.filter(g=>g.value===best.value).length>1?' Há outras categorias empatadas nesse valor.':''}`;
      next=[question('Qual foi a maior compra dessa categoria?','purchase',target),question('Comparar essa categoria com o período anterior','compare',{...base(),category:best.key}),report('Ver lançamentos da categoria',target)];
    }else if(choice.action==='purchase'){
      const sorted=[...selected].sort((a,b)=>Number(b.valor)-Number(a.valor)), best=sorted[0];
      answer=`A maior compra foi “${best.descricao}”: ${money(Number(best.valor))}, em ${fmtDate(best.data_lancamento)}, na categoria ${categoryName(best.categoria)}.${sorted.filter(t=>Number(t.valor)===Number(best.valor)).length>1?' Há outros lançamentos empatados nesse valor.':''}`;
      const target={...scope,day:String(best.data_lancamento).slice(0,10),category:best.categoria};
      next=[report('Ver lançamentos desse dia e categoria',target),question('Quanto gastei nessa categoria no período?','total',{...base(),category:best.categoria}),question('Outra análise','menu')];
    }else if(choice.action==='total'){
      answer=`Você registrou ${money(total)} em ${categoryName(scope.category)} no período, em ${selected.length} lançamento${selected.length===1?'':'s'}.`;
      next=[question('Comparar com o período anterior','compare',scope),question('Qual dia mais pesou nessa categoria?','day',scope),report()];
    }else if(choice.action==='compare'){
      const prior=previous(scope), priorRows=rows({...scope,month:prior.month,day:null}).filter(t=>String(t.data_lancamento).slice(0,10)<=prior.to);
      const current=rows({...scope,day:null}), now=sum(current), before=sum(priorRows), delta=now-before;
      const period=periodFor(scope);
      const note=`${scope.mode==='invoice'?'Comparação entre faturas. ':''}Comparação de ${fmtDate(period.from)} a ${fmtDate(period.to)} com ${fmtDate(prior.from)} a ${fmtDate(prior.to)}.`;
      if(!current.length||!priorRows.length) answer=`${note} Não há registros de despesas em ${!current.length?'seu período selecionado':'seu período anterior'} para uma comparação confiável. Totais registrados: ${money(now)} e ${money(before)}, respectivamente.`;
      else answer=`${note} Você gastou ${money(now)}, contra ${money(before)} anteriormente. ${delta===0?'Os totais foram iguais.':`${money(Math.abs(delta))} ${delta>0?'a mais':'a menos'}${before>0?' ('+Math.abs(delta/before*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%)':''}.`}`;
      next=[question('Qual categoria mais pesou no período?','category'),question('Qual foi minha maior compra?','purchase',scope),report('Ver lançamentos do período',scope)];
    }else if(choice.action==='summary'){
      answer=`Você registrou ${money(total)} em despesas neste período, em ${selected.length} lançamento${selected.length===1?'':'s'}.`;
      next=[question('Quais foram minhas 3 maiores categorias?','topCategories',scope),question('Qual foi o valor médio por lançamento?','average',scope),report()];
    }else if(choice.action==='topCategories'){
      answer='As maiores categorias do período foram:\n'+groups(selected,t=>t.categoria).slice(0,3).map((g,i)=>`${i+1}. ${categoryName(g.key)}: ${money(g.value)}`).join('\n');
      next=[question('Qual categoria mais pesou?','category',scope),question('Quais foram minhas 3 maiores compras?','topPurchases',scope),report()];
    }else if(choice.action==='topPurchases'){
      answer='Os maiores lançamentos do período foram:\n'+[...selected].sort((a,b)=>Number(b.valor)-Number(a.valor)).slice(0,3).map((t,i)=>`${i+1}. ${t.descricao}: ${money(Number(t.valor))} (${fmtDate(t.data_lancamento)})`).join('\n');
      next=[question('Qual categoria mais pesou?','category',scope),question('Qual foi o valor médio por lançamento?','average',scope),report()];
    }else if(choice.action==='average'){
      answer=`O valor médio foi ${money(total/selected.length)} por lançamento: ${money(total)} divididos entre ${selected.length} despesas registradas.`;
      next=[question('Qual foi minha maior compra?','purchase',scope),question('Em quantos dias tive gastos?','frequency',scope),report()];
    }else if(choice.action==='frequency'){
      const days=new Set(selected.map(t=>String(t.data_lancamento).slice(0,10))).size;
      answer=`Você teve despesas registradas em ${days} dia${days===1?'':'s'} do período, com ${selected.length} lançamento${selected.length===1?'':'s'} no total.`;
      next=[question('Qual dia teve mais gastos?','day',scope),question('Quanto gastei no período?','summary',scope),report()];
    }else if(choice.action==='limit'){
      const globalScope={month:scope.month,wallet:'all'}, spent=sum(rows(globalScope)), limit=Number(state.monthlyLimit||0);
      answer=limit>0?`Seu limite mensal atual é ${money(limit)}. Considerando todas as organizações, você registrou ${money(spent)} em despesas neste mês (${Math.round(spent/limit*100)}% do limite). ${spent>limit?'Ultrapassou em '+money(spent-limit):'Restam '+money(limit-spent)}. O limite é geral da conta e não possui histórico por mês.`:'Você ainda não definiu um limite mensal. Pode cadastrá-lo no cartão de limite da Visão geral. Ele vale para todas as organizações.';
      next=[question('Quais categorias mais pesaram nesse total?','category',globalScope),report('Ver despesas de todas as organizações',globalScope),question('Outra análise','menu')];
    }
    next=next.filter(item=>item.action!=='menu');
    if(choice.action!=='menu')next.push(question('Outra análise','menu'));
    await reply(answer,next);
  }
  window.FiniaAssistant={open,reset};
  window.addEventListener('DOMContentLoaded',()=>{
    $('assistant-new').addEventListener('click',restart);
  });
})();
