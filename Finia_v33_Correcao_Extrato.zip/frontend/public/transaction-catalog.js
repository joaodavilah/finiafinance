/* Shared catalog: browser and server use the same categories and matching rules. */
(function(root, factory) {
  const catalog = factory();
  if (typeof module === 'object' && module.exports) module.exports = catalog;
  else root.FiniaCatalog = catalog;
})(typeof globalThis === 'object' ? globalThis : this, function() {
  const labels = {alimentacao:'Alimentação',supermercado:'Supermercado',transporte:'Transporte',combustivel:'Combustível',saude:'Saúde',academia:'Academia e esportes',lazer:'Lazer',moradia:'Moradia',contas:'Água, luz e gás',telefonia:'Internet e telefonia',educacao:'Educação',vestuario:'Roupas e acessórios',assinaturas:'Assinaturas',cuidados_pessoais:'Cuidados pessoais',pets:'Pets',presentes:'Presentes e doações',viagens:'Viagens',impostos:'Impostos',tarifas:'Tarifas e juros',salario:'Salário',freelance:'Freelance',vendas:'Vendas',beneficios:'Benefícios',reembolsos:'Reembolsos',rendimentos:'Rendimentos',investimentos:'Aplicações financeiras',resgates:'Resgates de investimentos',pagamento_fatura:'Pagamento de fatura',transferencias:'Transferências',outros:'Outros'};
  const types={entrada:['salario','freelance','vendas','beneficios','reembolsos','rendimentos','resgates','transferencias','outros'],saida:['alimentacao','supermercado','transporte','combustivel','saude','academia','lazer','moradia','contas','telefonia','educacao','vestuario','assinaturas','cuidados_pessoais','pets','presentes','viagens','impostos','tarifas','investimentos','pagamento_fatura','transferencias','outros']};
  const icons={}; Object.keys(labels).forEach(k=>icons[k]='Shapes');
  Object.assign(icons,{alimentacao:'Utensils',supermercado:'Utensils',transporte:'CarFront',combustivel:'CarFront',saude:'HeartPulse',academia:'HeartPulse',lazer:'Gamepad2',moradia:'House',contas:'ReceiptText',telefonia:'LaptopMinimal',educacao:'BookOpen',salario:'WalletCards',freelance:'LaptopMinimal',assinaturas:'ReceiptText',tarifas:'Landmark',impostos:'Landmark',investimentos:'Landmark',resgates:'Landmark',rendimentos:'Landmark',pagamento_fatura:'WalletCards',presentes:'Sparkles',vestuario:'Sparkles',cuidados_pessoais:'Sparkles'});
  function normalize(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9]+/g,' ').trim();}
  const phrases = [
    'EXTRATO CONSOLIDADO INTELIGENTE','Movimentação','Saldos por Período','Compras com Cartão de Débito',
    'DEBITO VISA ELECTRON BRASIL','PIX RECEBIDO','PIX ENVIADO','APLICACAO CDB/RDB','RESGATE CDB/RDB',
    'LIQUIDO DE VENCIMENTO','REMUNERACAO APLICACAO AUTOMATICA','RECARGA TELEFONE CELULAR',
    'IOF IMPOSTO OPERACOES FINANCEIRAS','IOF ADICIONAL - AUTOMATICO','PAGAMENTO CARTAO CREDITO BCE','PERIODO:',
    'janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro',
    'Pista 4','Lacoste Tijucas','Lacoste','Levis','IFS Ifashion Tijuca','Emporio Seletto','Porto Belo',
    'Rede Juninho Porto','Machado e Barbirato','Shopping Park','Pix Marketplace','Do Kilo','Lanchonete Dusky',
    'Athena Restaurante','Athena','Ana Clara Goumet','Americanas SA','Burger King','SRRestaurante','Santa Bella',
    'Bisa Grill Itajai','HamsGrill','Chiquinho Itajai','Multilog','Villa Door Spacio','Cafe Central','RedeDePostosPoffo',
    'IFOOD COM AGENCIA DE REST','Better Comercio De','MK Beira Mar','Galo Ko','LambuzaSorvetes',
    'Force One Academia','Force One Acade','ItalianaGarden','Mini Kalzone','CityParkestac','TIM BRASI',
    'Supermercado','Hipermercado','Restaurante','Lanchonete','Farmacia','Drogaria','Academia','Netflix','Spotify'
  ];
  function flexiblePhrase(phrase) {
    return phrase.replace(/\s+/g,'').split('').map(c=>c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('\\s*');
  }
  const repairs=phrases.map(phrase=>[new RegExp('(?<![\\p{L}\\p{N}])'+flexiblePhrase(phrase)+'(?![\\p{L}\\p{N}])','giu'),phrase]);
  function repairText(value) {
    let text=String(value||'').replace(/[\u00a0\u200b]/g,' ').replace(/(\d)\s*\/\s*(?=\d)/g,'$1/');
    for(const [pattern,phrase] of repairs)text=text.replace(pattern,phrase);
    return text.replace(/[ \t]+/g,' ').trim();
  }
  function merchantKey(description) {
    const text=repairText(description).replace(/^DEBITO (?:VISA ELECTRON BRASIL|CARTAO(?: DE DEBITO)?)\s*/i,'').replace(/^\d{2}\/\d{2}(?:\/\d{4})?\s*/,'');
    // Exact compact matching, separated by movement type at storage time.
    // Keep payment channels and meaningful numbers to avoid merging people or branches.
    return normalize(text).replace(/\s/g,'');
  }
  function readable(value){return String(value||'').replace(/\s+/g,' ').trim().toLocaleLowerCase('pt-BR').replace(/(^|[\s-])([\p{L}])/gu,(_,a,b)=>a+b.toLocaleUpperCase('pt-BR'));}
  function suggest(description,type){
    const original=repairText(description).replace(/\s+/g,' ').trim();
    const n=normalize(original), compact=n.replace(/\s/g,'');
    let name=original.replace(/^DEBITO (?:VISA ELECTRON BRASIL|CARTAO(?: DE DEBITO)?)\s*/i,'').replace(/^\d{2}\/\d{2}(?:\/\d{4})?\s*/,'').trim();
    let category='outros', reason='Descrição insuficiente para identificar a finalidade.', review=true, selected=true;
    function match(cat,why,clean,special=false){category=cat;reason=why;review=special;selected=!special;if(clean)name=clean;}
    if(type==='saida' && /APLICACAO.*(?:CDB|RDB|INVEST)/.test(n)) match('investimentos','Movimentação de patrimônio; desmarcada para não somar como consumo. Se incluída, será contabilizada como saída.','Aplicação financeira',true);
    else if(type==='entrada' && /RESGATE.*(?:CDB|RDB|INVEST)/.test(n)) match('resgates','Resgate não é renda nova; desmarcado. Se incluído, será contabilizado como entrada.','Resgate de investimento',true);
    else if(type==='saida' && /PAGAMENTO CARTAO|PAGAMENTO.*FATURA/.test(n)) match('pagamento_fatura','Pode duplicar despesas já lançadas no cartão. Use o pagamento entre organizações quando aplicável; se incluído aqui, conta como saída.','Pagamento de fatura',true);
    else if(type==='entrada' && /LIQUIDO DE VENCIMENTO|CREDITO DE SALARIO|PAGAMENTO DE SALARIO|\bSALARIO\b/.test(n)) match('salario','Descrição de pagamento salarial.', 'Salário'+(n.includes('MULTILOG')?' — Multilog':''));
    else if(type==='entrada' && /REMUNERACAO APLICACAO|RENDIMENTO|DIVIDENDO|JUROS SOBRE CAPITAL/.test(n))match('rendimentos','Descrição de rendimento financeiro.','Rendimento financeiro');
    else if(type==='entrada' && /REEMBOLSO|ESTORNO/.test(n))match('reembolsos','Descrição de devolução ou reembolso.');
    else if(type==='saida'){
      if(/RECARGA TELEFONE|TELEFONIA|\bINTERNET\b/.test(n)) match('telefonia','Descrição de serviço de telefonia.',/TIM/.test(n)?'Recarga de celular — TIM':'Internet / telefonia');
      else if(/\bIOF\b|\bIPVA\b|\bIPTU\b|IMPOSTO/.test(n))match('impostos','Tributo identificado na descrição.');
      else if(/TARIFA|JUROS|ENCARGO/.test(n))match('tarifas','Tarifa ou encargo bancário.');
      else if(/SUPERMERCADO|HIPERMERCADO|ATACADAO|\bASSAI\b/.test(n))match('supermercado','Estabelecimento identificado como supermercado.');
      else if(/POSTOS|POSTO DE|COMBUSTIVEL/.test(n)||compact.includes('REDEDEPOSTOS'))match('combustivel','Nome indica posto de combustível.');
      else if(/BURGER KING|IFOOD|RESTAURANTE|LANCHONETE|GRILL|KALZONE|SORVETE|CAFE CENTRAL|PIZZARIA|PADARIA|DO KILO|CHIQUINHO/.test(n)||/SRRESTAURANTE|LAMBUZASORVETES/.test(compact))match('alimentacao','Nome de restaurante, alimentação ou delivery.',n.includes('IFOOD')?'iFood':undefined);
      else if(/\bLACOSTE\b|\bLEVIS\b|VESTUARIO|CONFECCOES|SAPATARIA/.test(n))match('vestuario','Loja de roupas ou acessórios reconhecida.');
      else if(/ACADEMIA|FORCE ONE ACADE|SMART FIT/.test(n))match('academia','Nome de academia reconhecido.');
      else if(/FARMACIA|DROGARIA|HOSPITAL|CLINICA|LABORATORIO/.test(n))match('saude','Nome indica serviço ou produto de saúde.');
      else if(/NETFLIX|SPOTIFY|DISNEY PLUS|YOUTUBE PREMIUM/.test(n))match('assinaturas','Serviço de assinatura reconhecido.');
      else if(/PET SHOP|PETSHOP|VETERINAR|\bPETZ\b|COBASI/.test(n))match('pets','Estabelecimento voltado a animais.');
      else if(/BARBEARIA|CABELEIREIR|SALAO DE BELEZA/.test(n))match('cuidados_pessoais','Serviço de cuidados pessoais.');
      else if(/UNIVERSIDADE|FACULDADE|ESCOLA|UDEMY|ALURA/.test(n))match('educacao','Instituição ou curso reconhecido.');
      else if(/\bUBER\b|ESTACIONAMENTO|CITYPARKESTAC|PEDAGIO/.test(n))match('transporte','Transporte ou estacionamento reconhecido.');
    }
    if(category==='outros' && /^PIX (ENVIADO|RECEBIDO)|^TED |^TRANSFERENCIA/.test(n)){category='transferencias';reason='O nome do destinatário não informa a finalidade. Confira a categoria; transferências próprias podem duplicar entradas e saídas.';}
    if(!types[type]?.includes(category))category='outros';
    return {descricao:readable(name||original).slice(0,150),categoria:category,revisar:review,motivo:reason,selecionado:selected};
  }
  return {labels,types,icons,suggest,normalize,repairText,merchantKey};
});
