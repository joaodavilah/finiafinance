const API_URL = '/api/v1';


const LEGACY_ACTIONS_WITHOUT_ARGUMENTS = Object.freeze({
  hideFutureFeatures,
  showFutureFeatures,
  doLogin,
  doRegister,
  requestPasswordReset,
  resetPassword,
  toggleTheme,
  doLogout,
  toggleScheduleFields,
  saveTransaction,
  saveMonthlyLimit,
  exportTransactionsCsv,
  exportTransactionsPdf,
  clearTransactionSelection,
  deleteSelectedTransactions,
  resetDetailFilters
});

function runLegacyAction(code, event, element) {
  const action = String(code || '').trim().replace(/;$/, '');
  if (event.type === 'click' || event.type === 'submit') event.preventDefault();

  const noArgumentMatch = action.match(/^([A-Za-z][A-Za-z0-9]*)\(\)$/);
  if (noArgumentMatch && LEGACY_ACTIONS_WITHOUT_ARGUMENTS[noArgumentMatch[1]]) {
    return LEGACY_ACTIONS_WITHOUT_ARGUMENTS[noArgumentMatch[1]]();
  }

  if (action === 'saveProfileName(event)') return saveProfileName(event);
  if (action === 'saveNewPassword(event)') return saveNewPassword(event);
  if (action === 'importStatementFile(event)') return importStatementFile(event);
  if (action === 'checkPwd(this.value)') return checkPwd(element.value);
  if (action === 'toggleSelectAllTransactions(this.checked)') {
    return toggleSelectAllTransactions(element.checked);
  }

  let match = action.match(/^goTo\('(screen-[a-z-]+)'\)$/);
  if (match) return goTo(match[1]);
  match = action.match(/^setType\('(entrada|saida)'\)$/);
  if (match) return setType(match[1]);
  match = action.match(/^toggleActionMenu\('([a-z-]+)'\)$/);
  if (match) return toggleActionMenu(match[1]);
  match = action.match(/^triggerImport\('(csv|pdf)'\)$/);
  if (match) return triggerImport(match[1]);
  match = action.match(/^setDetailFilter\('(period|type|category|dateFrom|dateTo|invoiceMonth)', this\.value\)$/);
  if (match) return setDetailFilter(match[1], element.value);
  match = action.match(/^changeHeatmapMonth\((-?1)\)$/);
  if (match) return changeHeatmapMonth(Number(match[1]));
  match = action.match(/^(startEditTransaction|handleDeleteTransaction)\((\d+)\)$/);
  if (match) {
    return match[1] === 'startEditTransaction'
      ? startEditTransaction(Number(match[2]))
      : handleDeleteTransaction(Number(match[2]));
  }
  match = action.match(/^toggleTransactionSelection\((\d+), this\.checked\)$/);
  if (match) return toggleTransactionSelection(Number(match[1]), element.checked);

  console.warn('Ação de interface não reconhecida:', action);
}

function bindLegacyEventAttributes(root = document) {
  const elements = root.nodeType === Node.ELEMENT_NODE ? [root, ...root.querySelectorAll('*')] : [...root.querySelectorAll('*')];
  const eventAttributes = { onclick: 'click', onchange: 'change', oninput: 'input', onsubmit: 'submit' };

  elements.forEach(element => {
    Object.entries(eventAttributes).forEach(([attribute, eventName]) => {
      const code = element.getAttribute?.(attribute);
      if (!code) return;
      element.removeAttribute(attribute);
      element.addEventListener(eventName, event => runLegacyAction(code, event, element));
    });
  });
}

window.addEventListener('DOMContentLoaded', () => {
  bindLegacyEventAttributes(document);
  new MutationObserver(records => {
    records.forEach(record => record.addedNodes.forEach(node => {
      if (node.nodeType === Node.ELEMENT_NODE) bindLegacyEventAttributes(node);
    }));
  }).observe(document.body, { childList: true, subtree: true });
});

/* ── STATE ── */
let state = {
  user: null,
  token: null,
  transactions: [],
  insertType: 'entrada',
  editingTransactionId: null,
  detailFilters: {
    period: 'all',
    type: 'all',
    category: 'all'
  },
  selectedTransactionIds: new Set(),
  heatmapMonth: null,
  customCategories: [],
  wallets: [],
  walletFilter: 'all',
  homeMonth: '',
  payments: [],
  loading: {
    login: false,
    register: false,
    saveTransaction: false,
    deleteTransactionId: null,
    bulkDelete: false,
    bankConnect: false,
    bankSync: false,
    saveLimit: false,
    saveProfile: false,
    changePassword: false
  },
  importMode: 'csv',
  monthlyLimit: 0
};

const catLabels = window.FiniaCatalog.labels;

const CATEGORY_ICONS={'Geral':'Shapes','Alimentação':'Utensils','Transporte':'CarFront','Saúde':'HeartPulse','Lazer':'Gamepad2','Moradia':'House','Contas':'ReceiptText','Educação':'BookOpen','Salário':'WalletCards','Trabalho':'LaptopMinimal','Banco':'Landmark','Extras':'Sparkles'};
let selectedCategoryIcon='Shapes';
const catIconNames = window.FiniaCatalog.icons;

function getCategoryLabel(category) {
  const custom = state.customCategories.find(item => item.id === category);
  if (custom) return custom.label;
  if (catLabels[category]) return catLabels[category];
  if (String(category || '').startsWith('custom_')) {
    return String(category).replace(/^custom_(entrada|saida)_/, '').replace(/_/g, ' ').replace(/\b\p{L}/gu, letter => letter.toUpperCase());
  }
  return category || 'Outros';
}

function isCategoryAllowedForType(category, type) {
  if ((categoriesByType[type] || []).includes(category)) return true;
  return state.customCategories.some(item => item.id === category && item.type === type) || String(category || '').startsWith(`custom_${type}_`);
}

function categoryColor(category){
  const color=state.customCategories.find(c=>c.id===category)?.color;
  return typeof color==='string'&&/^#[0-9a-fA-F]{6}$/.test(color)?color:null;
}
function categoryIcon(category, className = '') {
  const custom=state.customCategories.find(c=>c.id===category);
  const iconName = Object.values(CATEGORY_ICONS).includes(custom?.icon)?custom.icon:(catIconNames[category] || catIconNames.outros);
  return `<i data-lucide="${iconName}" class="category-icon ${className}"${categoryColor(category)?` style="color:${categoryColor(category)}"`:""}></i>`;
}

function refreshLucideIcons(root = document) {
  window.FiniaIcons?.render(root);
}

const categoriesByType = window.FiniaCatalog.types;

/* ── HELPERS ── */
const fmt = v =>
  'R$ ' + Number(v || 0).toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

function fmtDate(d) {
  if (!d) return '';
  const raw = String(d).trim();
  const civilDate = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (civilDate) return `${civilDate[3]}/${civilDate[2]}/${civilDate[1]}`;

  const data = new Date(raw);
  if (Number.isNaN(data.getTime())) return raw;
  return `${String(data.getDate()).padStart(2, '0')}/${String(data.getMonth() + 1).padStart(2, '0')}/${data.getFullYear()}`;
}

function getDateInputValue(d) {
  if (!d) return '';
  const raw = String(d).trim();
  const civilDate = raw.match(/^(\d{4}-\d{2}-\d{2})/);
  if (civilDate) return civilDate[1];

  const data = new Date(raw);
  if (Number.isNaN(data.getTime())) return raw.slice(0, 10);
  return `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}-${String(data.getDate()).padStart(2, '0')}`;
}

function getTodayInputValue() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function setupDateInputLimit() {
  const dateInput = document.getElementById('f-data');
  if (!dateInput) return;

  const today = getTodayInputValue();
  dateInput.max = today;

  if (!dateInput.value || dateInput.value > today) {
    dateInput.value = today;
  }
}

function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast' + (type ? ' ' + type : '');
  void t.offsetWidth;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

function cssVar(name) {
  return getComputedStyle(document.body).getPropertyValue(name).trim();
}

function showFutureFeatures() {
  const modal = document.getElementById('future-modal');
  if (!modal) return;

  modal.classList.add('show');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');

  const closeBtn = modal.querySelector('.feature-modal-close');
  if (closeBtn) closeBtn.focus();
}

function hideFutureFeatures() {
  const modal = document.getElementById('future-modal');
  if (!modal) return;

  modal.classList.remove('show');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
}

function showConfirmDialog({ title, text, okText = 'Confirmar' }) {
  return new Promise(resolve => {
    const modal = document.getElementById('confirm-modal');
    const titleEl = document.getElementById('confirm-title');
    const textEl = document.getElementById('confirm-text');
    const okBtn = document.getElementById('confirm-ok');
    const cancelBtn = document.getElementById('confirm-cancel');
    if (!modal || !okBtn || !cancelBtn) {
      resolve(window.confirm(text || title));
      return;
    }

    titleEl.textContent = title;
    textEl.textContent = text;
    okBtn.textContent = okText;

    const cleanup = result => {
      modal.classList.remove('show');
      modal.setAttribute('aria-hidden', 'true');
      okBtn.onclick = null;
      cancelBtn.onclick = null;
      resolve(result);
    };

    okBtn.onclick = () => cleanup(true);
    cancelBtn.onclick = () => cleanup(false);
    modal.classList.add('show');
    modal.setAttribute('aria-hidden', 'false');
    cancelBtn.focus();
  });
}

function toggleActionMenu(id) {
  document.querySelectorAll('.action-menu').forEach(menu => {
    menu.classList.toggle('open', menu.id === id && !menu.classList.contains('open'));
  });
}

function closeActionMenus() {
  document.querySelectorAll('.action-menu').forEach(menu => menu.classList.remove('open'));
}

function triggerImport(mode) {
  state.importMode = mode;
  closeActionMenus();
  const input = document.getElementById('import-file');
  if (!input) return;
  input.accept = mode === 'pdf' ? '.pdf,application/pdf' : '.csv,text/csv';
  input.click();
}



function setDevResetLink(resetLink) {
  const box = document.getElementById('dev-reset-link');
  const anchor = document.getElementById('dev-reset-link-anchor');
  if (!box || !anchor) return;

  if (!resetLink) {
    box.classList.add('hidden');
    anchor.removeAttribute('href');
    anchor.textContent = '';
    return;
  }

  anchor.href = resetLink;
  anchor.textContent = resetLink;
  box.classList.remove('hidden');
}

async function requestPasswordReset() {
  try {
    const email = document.getElementById('forgot-email').value.trim();
    setDevResetLink('');

    if (!email) {
      showToast('Informe o e-mail', 'error');
      return;
    }

    const res = await fetch(`${API_URL}/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.erro || 'Erro ao solicitar recuperação');
    }

    showToast('Link de recuperação enviado para o e-mail informado', 'success');
    if (data.resetLink) {
      setDevResetLink(data.resetLink);
      showToast('Link local gerado para teste', 'success');
      return;
    }

    goTo('screen-login');
  } catch (error) {
    console.error(error);
    showToast(error.message || 'Erro ao solicitar recuperação', 'error');
  }
}

function getResetTokenFromUrl() {
  const hash = window.location.hash.replace(/^#screen-reset-password&?/, '');
  return new URLSearchParams(hash).get('token');
}

async function resetPassword() {
  try {
    const token = getResetTokenFromUrl();
    const novaSenha = document.getElementById('reset-new-password').value;

    if (!token) {
      showToast('Token de redefinição não encontrado', 'error');
      return;
    }

    if (!novaSenha) {
      showToast('Informe a nova senha', 'error');
      return;
    }

    const { length, upper, special, number } = pwdCheck(novaSenha);
    if (!length || !upper || !special || !number) {
      showToast('A nova senha não atende aos requisitos', 'error');
      return;
    }

    const res = await fetch(`${API_URL}/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, novaSenha })
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.erro || 'Erro ao redefinir senha');
    }

    showToast('Senha redefinida com sucesso', 'success');

    window.history.replaceState({}, '', '#screen-login');

    goTo('screen-login');
  } catch (error) {
    console.error(error);
    showToast(error.message || 'Erro ao redefinir senha', 'error');
  }
}

function clearAuthLocal() {
  localStorage.removeItem('finia_user');
  localStorage.removeItem('finia_token');
}

function loadThemeLocal() {
  return localStorage.getItem('finia_theme') || 'light';
}

function saveThemeLocal(theme) {
  localStorage.setItem('finia_theme', theme);
}

function syncThemeButtons(theme) {
  document.querySelectorAll('.theme-toggle').forEach(button => {
    button.classList.toggle('active', theme === 'dark');
    button.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
  });
}

function applyTheme(theme) {
  const nextTheme = theme === 'dark' ? 'dark' : 'light';
  document.body.dataset.theme = nextTheme;
  syncThemeButtons(nextTheme);
}

function toggleTheme() {
  const currentTheme = document.body.dataset.theme === 'dark' ? 'dark' : 'light';
  const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';

  applyTheme(nextTheme);
  saveThemeLocal(nextTheme);

  if (document.getElementById('screen-detail')?.classList.contains('active')) {
    renderDetail();
  }
}

function getAuthHeaders() {
  const headers = { 'Content-Type': 'application/json' };
  const csrfToken = document.cookie
    .split('; ')
    .find(cookie => cookie.startsWith('finia_csrf='))
    ?.slice('finia_csrf='.length);

  if (csrfToken) headers['X-CSRF-Token'] = decodeURIComponent(csrfToken);
  return headers;
}

function setAvatars() {
  if (!state.user) return;
  const initial = state.user.nome_completo?.charAt(0).toUpperCase() || 'U';
  document.querySelectorAll('[id^="nav-avatar"]:is(button), #profile-avatar-preview').forEach(el => {
    el.textContent = initial;
    if (!state.token || state.user.avatar?.presente === false) return;
    const img = document.createElement('img');
    img.alt = '';
    img.src = `${API_URL}/user/profile/avatar?v=${encodeURIComponent(state.user.avatar?.atualizado_em || state.user.id || 'current')}`;
    img.addEventListener('error', () => img.remove());
    el.appendChild(img);
  });
}

function calcTotals(txs) {
  const entradas = txs
    .filter(t => t.tipo === 'entrada')
    .reduce((s, t) => s + Number(t.valor), 0);

  const saidas = txs
    .filter(t => t.tipo === 'saida')
    .reduce((s, t) => s + Number(t.valor), 0);

  return {
    entradas,
    saidas,
    saldo: entradas - saidas
  };
}

function getSaveButton() {
  return document.querySelector('#screen-insert .btn.btn-primary');
}

function getLoginButton() {
  return document.querySelector('#screen-login .btn.btn-primary');
}

function getRegisterButton() {
  return document.querySelector('#screen-register .btn.btn-primary');
}

function setButtonLoading(button, isLoading, loadingText, normalText) {
  if (!button) return;
  button.disabled = isLoading;
  button.textContent = isLoading ? loadingText : normalText;
  button.style.opacity = isLoading ? '0.7' : '1';
  button.style.cursor = isLoading ? 'not-allowed' : 'pointer';
}

function ensureCancelEditButton() {
  const formActions = document.querySelector('#screen-insert .form-actions');
  if (!formActions) return null;

  let cancelBtn = document.getElementById('btn-cancel-edit');

  if (!cancelBtn) {
    cancelBtn = document.createElement('button');
    cancelBtn.id = 'btn-cancel-edit';
    cancelBtn.className = 'btn btn-ghost';
    cancelBtn.type = 'button';
    cancelBtn.textContent = 'Cancelar edição';
    cancelBtn.style.display = 'none';
    cancelBtn.onclick = cancelEdit;
    formActions.appendChild(cancelBtn);
  }

  return cancelBtn;
}

function updateInsertHeader() {
  const title = document.querySelector('#screen-insert .page-title');
  const sub = document.querySelector('#screen-insert .page-sub');
  const btn = getSaveButton();
  const cancelBtn = ensureCancelEditButton();

  if (state.editingTransactionId) {
    if (title) title.textContent = 'Editar movimentação';
    if (sub) sub.textContent = 'Atualize os dados da movimentação';
    if (btn) btn.textContent = state.loading.saveTransaction ? 'Salvando...' : 'Salvar alterações';
    if (cancelBtn) cancelBtn.style.display = 'inline-flex';
  } else {
    if (title) title.textContent = 'Nova movimentação';
    if (sub) sub.textContent = 'Registre uma receita ou despesa';
    if (btn) btn.textContent = state.loading.saveTransaction ? 'Salvando...' : 'Salvar movimentação';
    if (cancelBtn) cancelBtn.style.display = 'none';
  }
}

function isSameMonth(dateA, dateB) {
  return (
    dateA.getMonth() === dateB.getMonth() &&
    dateA.getFullYear() === dateB.getFullYear()
  );
}

function parseTransactionDate(value) {
  const text = String(value || '').slice(0, 10);
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (match) return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));

  return new Date(value);
}

function invoiceMonthFor(dateValue,closing){
  const date=parseTransactionDate(dateValue);
  const lastDay=new Date(date.getFullYear(),date.getMonth()+1,0).getDate();
  const month=new Date(date.getFullYear(),date.getMonth()+(date.getDate()>=Math.min(Number(closing),lastDay)?1:0),1);
  return `${month.getFullYear()}-${String(month.getMonth()+1).padStart(2,'0')}`;
}
function getFilteredTransactions(byPurchaseDate = false) {
  let txs = walletTransactions();
  if (byPurchaseDate && state.detailFilters.period!=='invoice') txs = txs.map(t=>({...t, data_lancamento: t.data_compra || t.data_lancamento}));
  const { period, type, category } = state.detailFilters;

  if(period==='between'){
    const {dateFrom,dateTo}=state.detailFilters;
    if(dateFrom&&dateTo&&dateFrom>dateTo)return [];
    txs=txs.filter(t=>{const day=String(t.data_lancamento).slice(0,10);return (!dateFrom||day>=dateFrom)&&(!dateTo||day<=dateTo);});
  }
  if(period==='invoice'){
    const wallet=state.wallets.find(w=>String(w.id)===state.walletFilter);
    if(!wallet?.dia_fechamento)return [];
    txs=txs.filter(t=>invoiceMonthFor(t.data_lancamento,wallet.dia_fechamento)===state.detailFilters.invoiceMonth);
    if(byPurchaseDate)txs=txs.map(t=>({...t,data_lancamento:t.data_compra||t.data_lancamento}));
  }
  if (period !== 'all') {
    const today = new Date();

    if (period === 'current_month') {
      txs = txs.filter(t => {
        const d = parseTransactionDate(t.data_lancamento);
        return isSameMonth(d, today);
      });
    }

    if (period === 'previous_month') {
      const previousMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      txs = txs.filter(t => {
        const d = parseTransactionDate(t.data_lancamento);
        return isSameMonth(d, previousMonthDate);
      });
    }

    if (period === '7d' || period === '30d' || period === '90d') {
      const limitDate = new Date();

      if (period === '7d') limitDate.setDate(today.getDate() - 7);
      if (period === '30d') limitDate.setDate(today.getDate() - 30);
      if (period === '90d') limitDate.setDate(today.getDate() - 90);

      txs = txs.filter(t => parseTransactionDate(t.data_lancamento) >= limitDate);
    }
  }

  if (type !== 'all') {
    txs = txs.filter(t => t.tipo === type);
  }

  if (category !== 'all') {
    txs = txs.filter(t => t.categoria === category);
  }

  return txs;
}

function setDetailFilter(key, value) {
  state.detailFilters[key] = value;
  state.heatmapMonth = null;
  if(key==='period'&&value==='invoice'&&!state.detailFilters.invoiceMonth)state.detailFilters.invoiceMonth=getTodayInputValue().slice(0,7);
  state.selectedTransactionIds.clear();
  renderDetail();
}

function resetDetailFilters() {
  state.heatmapMonth = null;
  state.detailFilters = {
    period: 'all',
    type: 'all',
    category: 'all'
  };
  state.selectedTransactionIds.clear();
  renderDetail();
}

function renderAdvancedFilters() {
  const container = document.getElementById('filter-row');
  if (!container) return;

  const categoriasUnicas = [...new Set(state.transactions.map(t => t.categoria))].sort((a, b) =>
    getCategoryLabel(a).localeCompare(getCategoryLabel(b), 'pt-BR')
  );
  const hasCustomFilters =
    state.detailFilters.period !== 'all' ||
    state.detailFilters.type !== 'all' ||
    state.detailFilters.category !== 'all';

  const credit=state.wallets.find(w=>String(w.id)===state.walletFilter&&w.tipo==='credito');
  const months=new Set([getTodayInputValue().slice(0,7),state.detailFilters.invoiceMonth].filter(Boolean));
  if(credit?.dia_fechamento)walletTransactions().forEach(t=>months.add(invoiceMonthFor(t.data_lancamento,credit.dia_fechamento)));
  container.innerHTML = `
    <div class="filter-group">
      <label for="filter-period">Período</label>
      <select id="filter-period" onchange="setDetailFilter('period', this.value)">
        <option value="between" ${state.detailFilters.period==='between'?'selected':''}>Entre duas datas</option>
        ${credit?.dia_fechamento?`<option value="invoice" ${state.detailFilters.period==='invoice'?'selected':''}>Fatura do cartão</option>`:''}
        <option value="all" ${state.detailFilters.period === 'all' ? 'selected' : ''}>Todo período</option>
        <option value="current_month" ${state.detailFilters.period === 'current_month' ? 'selected' : ''}>Mês atual</option>
        <option value="previous_month" ${state.detailFilters.period === 'previous_month' ? 'selected' : ''}>Mês anterior</option>
        <option value="7d" ${state.detailFilters.period === '7d' ? 'selected' : ''}>Últimos 7 dias</option>
        <option value="30d" ${state.detailFilters.period === '30d' ? 'selected' : ''}>Últimos 30 dias</option>
        <option value="90d" ${state.detailFilters.period === '90d' ? 'selected' : ''}>Últimos 90 dias</option>
      </select>
    </div>

    <div class="filter-group">
      <label for="filter-type">Tipo</label>
      <select id="filter-type" onchange="setDetailFilter('type', this.value)">
        <option value="all" ${state.detailFilters.type === 'all' ? 'selected' : ''}>Todos</option>
        <option value="entrada" ${state.detailFilters.type === 'entrada' ? 'selected' : ''}>Entradas</option>
        <option value="saida" ${state.detailFilters.type === 'saida' ? 'selected' : ''}>Saídas</option>
      </select>
    </div>

    <div class="filter-group filter-group-wide">
      <label for="filter-category">Categoria</label>
      <select id="filter-category" onchange="setDetailFilter('category', this.value)">
        <option value="all" ${state.detailFilters.category === 'all' ? 'selected' : ''}>Todas categorias</option>
        ${categoriasUnicas.map(cat => `
          <option value="${cat}" ${state.detailFilters.category === cat ? 'selected' : ''}>${escapeHtml(getCategoryLabel(cat))}</option>
        `).join('')}
      </select>
    </div>

    ${state.detailFilters.period==='between'?`<div class="filter-group"><label for="filter-from">De</label><input id="filter-from" type="date" value="${escapeHtml(state.detailFilters.dateFrom||'')}" onchange="setDetailFilter('dateFrom', this.value)"></div><div class="filter-group"><label for="filter-to">Até</label><input id="filter-to" type="date" value="${escapeHtml(state.detailFilters.dateTo||'')}" onchange="setDetailFilter('dateTo', this.value)"></div>${state.detailFilters.dateFrom>state.detailFilters.dateTo&&state.detailFilters.dateTo?'<p role="alert">A data inicial deve ser anterior ou igual à final.</p>':''}`:''}
    ${state.detailFilters.period==='invoice'?`<div class="filter-group"><label for="filter-invoice">Fatura de:</label><select id="filter-invoice" onchange="setDetailFilter('invoiceMonth', this.value)">${[...months].sort().reverse().map(m=>`<option value="${m}" ${m===state.detailFilters.invoiceMonth?'selected':''}>${getMonthLabel(parseTransactionDate(m+'-01'))}</option>`).join('')}</select></div>`:''}
    ${credit&&!credit.dia_fechamento?'<p class="wallet-hint">Defina o fechamento deste cartão em Organizações para filtrar suas faturas.</p>':''}
    <button class="filter-clear" onclick="resetDetailFilters()" ${hasCustomFilters ? '' : 'disabled'}>Limpar</button>
  `;
}

function getCurrentMonthTransactions() {
  const today = new Date();
  return walletTransactions().filter(t => {
    const data = parseTransactionDate(t.data_lancamento);
    return isSameMonth(data, today);
  });
}

function getMonthLabel(date) {
  return date.toLocaleDateString('pt-BR', {
    month: 'long',
    year: 'numeric'
  });
}

function getDashboardTransactions() {
  const month = state.homeMonth || getTodayInputValue().slice(0, 7);
  const selected = state.wallets.find(w => String(w.id) === state.walletFilter);
  const credit = selected?.tipo === 'credito';
  const hasClosing = credit && Number(selected.dia_fechamento) > 0;
  const transactions = walletTransactions().filter(t =>
    (hasClosing ? invoiceMonthFor(t.data_lancamento, selected.dia_fechamento) : String(t.data_lancamento).slice(0, 7)) === month
  );
  return { transactions, month, credit, hasClosing,
    label: `${hasClosing ? 'Fatura' : 'Movimentações'} de ${getMonthLabel(parseTransactionDate(month + '-01'))}` };
}

function getApiErrorMessage(error, fallback = 'Ocorreu um erro inesperado') {
  if (!error) return fallback;
  if (error.message) return error.message;
  return fallback;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function displayDescription(value) {
  let text = String(value || '').replace(/\s+/g, ' ').trim();

  const replacements = [
    [/\bP\s*I\s*X\b/gi, 'PIX'],
    [/\bR\s*E\s*C\s*A\s*R\s*G\s*A\b/gi, 'RECARGA'],
    [/\bT\s*E\s*L\s*E\s*F\s*O\s*N\s*E\b/gi, 'TELEFONE'],
    [/\bC\s*E\s*L\s*U\s*L\s*A\s*R\b/gi, 'CELULAR'],
    [/\bB\s*R\s*A\s*S\s*I\s*L?\b/gi, 'BRASIL'],
    [/\bE\s*N\s*V\s*I\s*A\s*D\s*O\b/gi, 'ENVIADO'],
    [/\bR\s*E\s*C\s*E\s*B\s*I\s*D\s*O\b/gi, 'RECEBIDO'],
    [/\bR\s*E?\s*B\s*I\s*D\s*O\b/gi, 'RECEBIDO'],
    [/\bD\s*E\s*B\s*I\s*T\s*O\b/gi, 'DEBITO'],
    [/\bC\s*A\s*R\s*T\s*A\s*O\b/gi, 'CARTAO'],
    [/\bC\s*R\s*E\s*D\s*I\s*T\s*O\b/gi, 'CREDITO'],
    [/\bP\s*A\s*G\s*A\s*M\s*E\s*N\s*T\s*O\b/gi, 'PAGAMENTO'],
    [/\bL\s*I\s*Q\s*U\s*I\s*D\s*O\b/gi, 'LIQUIDO'],
    [/\bV\s*E\s*N\s*C\s*I\s*M\s*E\s*N\s*T\s*O\b/gi, 'VENCIMENTO'],
    [/\bA\s*P\s*L\s*I\s*C\s*A\s*C\s*A\s*O\b/gi, 'APLICACAO'],
    [/\bC\s*D\s*B\s*\/\s*R\s*D\s*B\b/gi, 'CDB/RDB'],
    [/\bV\s*I\s*S\s*A\b/gi, 'VISA']
  ];

  replacements.forEach(([pattern, replacement]) => {
    text = text.replace(pattern, replacement);
  });

  return text
    .replace(/^PIX RECEBIDO\s+/i, 'PIX RECEBIDO - ')
    .replace(/^PIX ENVIADO\s+/i, 'PIX ENVIADO - ')
    .replace(/^RECARGA TELEFONE CELULAR\s+/i, 'RECARGA CELULAR - ')
    .replace(/^PAGAMENTO CARTAO CREDITO\s+/i, 'PAGAMENTO CARTAO - ')
    .replace(/\s+-\s+/g, ' - ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

function isValidUserName(nome) {
  const normalized = String(nome || '').trim().replace(/\s+/g, ' ');
  const letterCount = (normalized.match(/\p{L}/gu) || []).length;

  return (
    letterCount >= 3 &&
    !/[0-9]/.test(normalized) &&
    /^[\p{L}\s'.-]+$/u.test(normalized)
  );
}

function handleUnauthorized() {
  showToast('Sessão expirada. Faça login novamente.', 'error');
  doLogout();
}

async function parseApiResponse(res) {
  let data = null;

  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (res.status === 401) {
    handleUnauthorized();
    throw new Error('Sessão expirada');
  }

  if (!res.ok) {
    throw new Error(data?.erro || 'Erro na requisição');
  }

  return data;
}

/* ── API ── */
async function fetchLancamentos() {
  if (!state.token) return;
  const items=[];
  let cursor=null;
  do {
    const query=new URLSearchParams({limit:'100'});
    if(cursor) query.set('cursor',cursor);
    const data=await parseApiResponse(await fetch(`${API_URL}/lancamentos?${query}`,{headers:getAuthHeaders()}));
    items.push(...(Array.isArray(data)?data:data.items || []));
    cursor=data.next_cursor || null;
  } while(cursor);
  state.transactions=items;
  await fetchOrganization();
}

async function fetchUserSettings() {
  if (!state.token) return;

  const res = await fetch(`${API_URL}/user/settings`, {
    headers: getAuthHeaders()
  });

  const data = await parseApiResponse(res);
  state.monthlyLimit = Number(data.limite_gastos_mensal || 0);
}

async function updateUserSettings(payload) {
  const res = await fetch(`${API_URL}/user/settings`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });

  return await parseApiResponse(res);
}

async function fetchUserProfile() {
  const res = await fetch(`${API_URL}/user/profile`, {
    headers: getAuthHeaders()
  });

  return await parseApiResponse(res);
}

async function updateProfileNameRequest(nome_completo) {
  const res = await fetch(`${API_URL}/user/profile`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify({ nome_completo })
  });

  return await parseApiResponse(res);
}

async function changePasswordRequest(senha_atual, nova_senha) {
  const res = await fetch(`${API_URL}/change-password`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ senha_atual, nova_senha })
  });

  return await parseApiResponse(res);
}

async function registerUser(nome_completo, email, senha) {
  const res = await fetch(`${API_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome_completo, email, senha })
  });

  return await parseApiResponse(res);
}

async function loginUser(email, senha) {
  const res = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, senha })
  });

  return await parseApiResponse(res);
}

async function restoreSession() {
  const res = await fetch(`${API_URL}/session`, { credentials: 'same-origin' });
  if (res.status === 401) return null;
  return await parseApiResponse(res);
}

async function createLancamento(payload) {
  const res = await fetch(`${API_URL}/lancamentos`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });

  return await parseApiResponse(res);
}

async function updateLancamento(id, payload) {
  const res = await fetch(`${API_URL}/lancamentos/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload)
  });

  return await parseApiResponse(res);
}

async function deleteLancamento(id) {
  const res = await fetch(`${API_URL}/lancamentos/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders()
  });

  return await parseApiResponse(res);
}

async function createBankConnectToken() {
  const res = await fetch(`${API_URL}/bank/connect-token`, {
    method: 'POST',
    headers: getAuthHeaders()
  });

  return await parseApiResponse(res);
}

async function saveBankConnection(item) {
  const itemId = item?.itemId || item?.id || item?.item?.id;
  if (!itemId) throw new Error('Banco autorizado sem identificador de conexao');

  const res = await fetch(`${API_URL}/bank/connection`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({
      itemId,
      connectorName: item?.connector?.name || item?.institution?.name || item?.name || null
    })
  });

  return await parseApiResponse(res);
}

async function syncBankTransactionsRequest() {
  const res = await fetch(`${API_URL}/bank/sync`, {
    method: 'POST',
    headers: getAuthHeaders()
  });

  return await parseApiResponse(res);
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

async function ensurePluggyConnectLoaded() {
  if (window.PluggyConnect || window.pluggyConnect) return true;

  const sources = [
    'https://cdn.pluggy.ai/pluggy-connect/v2.7.0/pluggy-connect.js',
    'https://unpkg.com/pluggy-connect/dist/pluggy-connect.umd.js'
  ];

  for (const source of sources) {
    try {
      await loadScript(source);
      if (window.PluggyConnect || window.pluggyConnect) return true;
    } catch {
      // Tenta a proxima origem.
    }
  }

  return false;
}

function getPluggyItemId(data) {
  return data?.item?.id || data?.itemId || data?.id || data?.result?.itemId || data?.result?.id || null;
}

async function handleBankConnectionSuccess(data) {
  const itemId = getPluggyItemId(data);
  if (!itemId) {
    showToast('Banco autorizado, mas nao recebi o identificador da conexao', 'error');
    return;
  }

  await saveBankConnection({ ...data, itemId });
  showToast('Banco conectado. Sincronizando lancamentos...', 'success');
  await syncBankTransactions();
}

async function openPluggyConnect(connectToken, connectOptions = {}) {
  const loaded = await ensurePluggyConnectLoaded();
  if (!loaded) {
    throw new Error('Nao foi possivel carregar o widget de conexao bancaria. Verifique sua internet ou inclua o script Pluggy Connect no projeto.');
  }

  const options = {
    connectToken,
    includeSandbox: false,
    countries: ['BR'],
    language: 'pt',
    theme: document.body.classList.contains('dark') ? 'dark' : 'light',
    ...connectOptions,
    onSuccess: handleBankConnectionSuccess,
    onError: error => {
      console.error(error);
      showToast('Nao foi possivel concluir a autorizacao bancaria', 'error');
    },
    onClose: () => showToast('Conexao bancaria encerrada', 'success')
  };

  if (typeof window.PluggyConnect === 'function') {
    const widget = new window.PluggyConnect(options);
    if (typeof widget.init === 'function') return widget.init();
    if (typeof widget.open === 'function') return widget.open();
  }

  if (window.pluggyConnect?.init) {
    return window.pluggyConnect.init(options);
  }

  throw new Error('Widget Pluggy Connect carregado em formato desconhecido');
}

async function connectBankAccount() {
  if (!state.token || state.loading.bankConnect) return;

  try {
    state.loading.bankConnect = true;
    const data = await createBankConnectToken();
    await openPluggyConnect(data.connectToken, data.connectOptions);
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao iniciar conexao bancaria'), 'error');
  } finally {
    state.loading.bankConnect = false;
  }
}

async function syncBankTransactions() {
  if (!state.token || state.loading.bankSync) return;

  try {
    state.loading.bankSync = true;
    const data = await syncBankTransactionsRequest();
    await fetchLancamentos();
    if (document.getElementById('screen-home')?.classList.contains('active')) {
      renderHome();
    }
    if (document.getElementById('screen-detail')?.classList.contains('active')) {
      state.detailFilters = { period: 'all', type: 'all', category: 'all' };
      renderDetail();
    }

    const count = Number(data.imported || 0);
    showToast(count ? `${count} lancamento(s) sincronizado(s)` : 'Banco sincronizado. Nenhum lancamento novo.', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao sincronizar banco'), 'error');
  } finally {
    state.loading.bankSync = false;
  }
}

/* ── NAVIGATION ── */
async function goTo(id) {
  closeProfileMenus();
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  updateFinanceNavigation(id);
  if (id === 'screen-assistant') {
    const assistantUserId = state.user?.id;
    try {
      if (state.token) { await fetchLancamentos(); await fetchUserSettings(); }
      if (state.user?.id === assistantUserId && document.querySelector('.screen.active')?.id === id) window.FiniaAssistant.open();
    } catch {
      if (state.user?.id === assistantUserId && document.querySelector('.screen.active')?.id === id) {
        window.FiniaAssistant.open();
        showToast('Não foi possível atualizar os dados. Sua conversa foi mantida.','error');
      }
    }
  }

  if (id === 'screen-home') {
    if (state.token) {
      await fetchLancamentos();
      await fetchUserSettings();
    }
    renderHome();
  }

  if (id === 'screen-detail') {
    if (state.token) {
      await fetchLancamentos();
      await fetchUserSettings();
    }
    renderDetail();
  }

  if (id === 'screen-wallets' || id === 'screen-categories') {
    await fetchOrganization();
    renderOrganization();
  }
  if (id === 'screen-insert') {
    await fetchOrganization();
    renderWalletSelect();
    initInsertForm();
  }

  if (id === 'screen-limit') {
    initLimitForm();
  }

  if (id === 'screen-settings') {
    await initSettingsForm();
  }

  if (id === 'screen-forgot-password') {
    setDevResetLink('');
  }

  window.scrollTo(0, 0);
}

/* ── AUTH ── */
function pwdCheck(v) {
  return {
    length: Array.from(v).length >= 8,
    upper: /[A-Z]/.test(v),
    special: /[^A-Za-z0-9]/.test(v),
    number: /[0-9]/.test(v)
  };
}

function toggle(id, ok) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('ok', ok);
}

function checkPwd(v) {
  const c = pwdCheck(v);
  toggle('rule-length', c.length);
  toggle('rule-upper', c.upper);
  toggle('rule-special', c.special);
  toggle('rule-number', c.number);
}

async function doRegister() {
  if (state.loading.register) return;

  const button = getRegisterButton();

  try {
    state.loading.register = true;
    setButtonLoading(button, true, 'Criando conta...', 'Criar minha conta');

    const nome_completo = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const senha = document.getElementById('reg-pwd').value;

    if (!nome_completo || !email || !senha) {
      showToast('Preencha todos os campos', 'error');
      return;
    }

    if (!isValidUserName(nome_completo)) {
      showToast('Nome deve ter no mínimo 3 letras e não pode conter números', 'error');
      return;
    }

    if (!isValidEmail(email)) {
      showToast('Informe um e-mail válido', 'error');
      return;
    }

    const { length, upper, special, number } = pwdCheck(senha);
    if (!length || !upper || !special || !number) {
      showToast('Senha não atende aos requisitos', 'error');
      return;
    }

    await registerUser(nome_completo, email, senha);

    showToast('Conta criada com sucesso! Faça login.', 'success');
    goTo('screen-login');

    document.getElementById('login-email').value = email;
    document.getElementById('login-pwd').value = '';
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao cadastrar usuário'), 'error');
  } finally {
    state.loading.register = false;
    setButtonLoading(button, false, 'Criando conta...', 'Criar minha conta');
  }
}

async function doLogin() {
  if (state.loading.login) return;

  const button = getLoginButton();

  try {
    state.loading.login = true;
    setButtonLoading(button, true, 'Entrando...', 'Entrar na conta');

    const email = document.getElementById('login-email').value.trim();
    const senha = document.getElementById('login-pwd').value;

    if (!email || !senha) {
      showToast('Preencha todos os campos', 'error');
      return;
    }

    const data = await loginUser(email, senha);

    state.user = data.usuario;
    state.token = true;
    setAvatars();

    await fetchLancamentos();
    await fetchUserSettings();
    await goTo('screen-home');

    showToast('Login realizado com sucesso!', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao fazer login'), 'error');
  } finally {
    state.loading.login = false;
    setButtonLoading(button, false, 'Entrando...', 'Entrar na conta');
  }
}

async function doLogout() {
  window.FiniaAssistant?.reset();
  const hadSession = state.token;

  if (hadSession) {
    try {
      await fetch(`${API_URL}/logout`, {
        method: 'POST',
        headers: getAuthHeaders(),
        credentials: 'same-origin'
      });
    } catch (error) {
      console.warn('Não foi possível encerrar a sessão no servidor.', error);
    }
  }

  document.getElementById('import-review')?.close();
  importDraft = null;
  state.user = null;
  state.token = null;
  state.transactions = [];
  state.wallets=[];state.payments=[];state.customCategories=[];state.walletFilter='all';state.homeMonth='';
  state.monthlyLimit = 0;
  state.heatmapMonth = null;
  state.editingTransactionId = null;
  clearAuthLocal();
  await goTo('screen-login');
}

/* ── SETTINGS ── */
async function initSettingsForm() {
  try {
    if (state.token) {
      const profile = await fetchUserProfile();
      if (profile?.nome_completo) {
        state.user = { ...state.user, ...profile };
        setAvatars();
      }
    }
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao carregar o perfil'), 'error');
  }

  const nameInput = document.getElementById('settings-name');
  const emailInput = document.getElementById('settings-email');
  if (nameInput) nameInput.value = state.user?.nome_completo || '';
  if (emailInput) emailInput.value = state.user?.email || '';

  ['settings-current-password', 'settings-new-password', 'settings-confirm-password'].forEach(id => {
    const input = document.getElementById(id);
    if (input) input.value = '';
  });

  refreshLucideIcons(document.getElementById('screen-settings'));
}

async function saveProfileName(event) {
  event?.preventDefault();
  if (!state.token || state.loading.saveProfile) return;

  const input = document.getElementById('settings-name');
  const button = document.getElementById('settings-profile-submit');
  const name = String(input?.value || '').trim().replace(/\s+/g, ' ');

  if (!isValidUserName(name)) {
    showToast('Informe um nome válido, com pelo menos 3 letras', 'error');
    input?.focus();
    return;
  }

  try {
    state.loading.saveProfile = true;
    setButtonLoading(button, true, 'Salvando...', 'Salvar nome');
    const profile = await updateProfileNameRequest(name);
    state.user = { ...state.user, ...profile, nome_completo: profile?.nome_completo || name };
    setAvatars();
    showToast('Nome atualizado com sucesso', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao atualizar o nome'), 'error');
  } finally {
    state.loading.saveProfile = false;
    setButtonLoading(button, false, 'Salvando...', 'Salvar nome');
  }
}

async function saveNewPassword(event) {
  event?.preventDefault();
  if (!state.token || state.loading.changePassword) return;

  const currentInput = document.getElementById('settings-current-password');
  const newInput = document.getElementById('settings-new-password');
  const confirmInput = document.getElementById('settings-confirm-password');
  const button = document.getElementById('settings-password-submit');
  const currentPassword = currentInput?.value || '';
  const newPassword = newInput?.value || '';
  const confirmation = confirmInput?.value || '';
  const strength = pwdCheck(newPassword);

  if (!currentPassword) {
    showToast('Informe sua senha atual', 'error');
    currentInput?.focus();
    return;
  }
  if (
    !strength.length ||
    !strength.upper ||
    !strength.number ||
    !strength.special
  ) {
    showToast('A nova senha não atende aos requisitos de segurança', 'error');
    newInput?.focus();
    return;
  }
  if (newPassword !== confirmation) {
    showToast('A confirmação da nova senha não confere', 'error');
    confirmInput?.focus();
    return;
  }

  try {
    state.loading.changePassword = true;
    setButtonLoading(button, true, 'Atualizando...', 'Atualizar senha');
    await changePasswordRequest(currentPassword, newPassword);
    await doLogout();
    showToast('Senha atualizada. Entre novamente com a nova senha.', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao atualizar a senha'), 'error');
  } finally {
    state.loading.changePassword = false;
    setButtonLoading(button, false, 'Atualizando...', 'Atualizar senha');
  }
}

/* ── HOME ── */
function renderHome() {
  const data=getDashboardTransactions(),transactions=data.transactions;
  renderWalletFilters();
  document.getElementById('home-period').value=data.month;
  document.getElementById('home-period-label').textContent=data.hasClosing?'Fatura':'Mês';
  document.getElementById('home-period-help').textContent=data.hasClosing
    ?'Fatura identificada pelo mês do fechamento. Compras no dia do fechamento entram na próxima fatura.'
    :data.credit?'Cadastre o fechamento em Organizações para filtrar por fatura. Por enquanto, o filtro usa o mês do lançamento.':'';
  document.querySelector('#screen-home .cards-period-label').textContent=data.label;
  const {entradas,saidas}=calcTotals(transactions);
  const visible=state.wallets.filter(w=>state.walletFilter==='all'||String(w.id)===state.walletFilter);
  const selected=state.walletFilter==='all'?null:visible[0],credit=selected?.tipo==='credito';
  const balance=credit?Number(selected.divida):visible.filter(w=>w.tipo!=='credito').reduce((sum,w)=>sum+Number(w.saldo),0);
  document.getElementById('card-saldo').textContent=fmt(balance);
  document.querySelector('#screen-home .card-balance .card-label').textContent=credit?'Dívida em aberto':selected?'Saldo da organização':'Saldo em contas e benefícios';
  document.getElementById('home-income-label').textContent=credit?'Limite total':'Entradas';
  document.getElementById('home-income-note').textContent=credit?'Configurado para este cartão':'No período selecionado';
  document.getElementById('card-entradas').textContent=fmt(credit?Number(selected.limite):entradas);
  document.getElementById('card-entradas').classList.toggle('green',!credit);
  document.getElementById('home-expense-label').textContent=credit?(data.hasClosing?'Compras na fatura':'Compras no mês'):'Saídas';
  document.getElementById('card-saidas').textContent=fmt(saidas);
  document.getElementById('home-limit-action').textContent=credit?'Gerenciar cartão':'Ajustar limite';
  renderMonthlyLimitCard();
  document.getElementById('home-recent-caption').textContent=`${transactions.length} lançamento${transactions.length===1?'':'s'} no período`;
  renderHomeSpending(transactions);
  const list=document.getElementById('home-tx-list');
  const recents=[...transactions].sort((a,b)=>parseTransactionDate(b.data_lancamento)-parseTransactionDate(a.data_lancamento)||Number(b.id)-Number(a.id)).slice(0,6);
  if(!recents.length){
    list.innerHTML='<div class="home-empty"><span class="home-empty-icon"><i data-lucide="ReceiptText"></i></span><strong>Nenhum lançamento neste período</strong><p>Escolha outro mês ou registre sua primeira movimentação.</p><button type="button" class="home-inline-link" onclick="goTo(\'screen-insert\')">Adicionar movimentação →</button></div>';
  }else{
    list.innerHTML=recents.map(t=>`<div class="tx-item"><div class="tx-icon cat-${t.categoria}">${categoryIcon(t.categoria)}</div><div class="tx-info"><div class="tx-desc">${escapeHtml(displayDescription(t.descricao))}</div><div class="tx-cat">${escapeHtml(getCategoryLabel(t.categoria))} · ${escapeHtml(walletName(t.carteira_id))}</div></div><div class="tx-right"><div class="tx-val ${t.tipo==='entrada'?'pos':'neg'}">${t.tipo==='entrada'?'+':'−'}${fmt(t.valor)}</div><div class="tx-date">${fmtDate(t.data_lancamento)}</div></div></div>`).join('');
  }
  refreshLucideIcons(document.getElementById('screen-home'));
}
function renderHomeSpending(transactions){
  const target=document.getElementById('home-spending-chart'),totals=new Map();
  for(const t of transactions)if(t.tipo==='saida'&&Number.isFinite(Number(t.valor))&&Number(t.valor)>0)totals.set(t.categoria,(totals.get(t.categoria)||0)+Number(t.valor));
  const sorted=[...totals].sort((a,b)=>b[1]-a[1]),sum=sorted.reduce((s,r)=>s+r[1],0);
  if(!sum){target.innerHTML='<div class="home-empty home-chart-empty"><span class="home-empty-icon"><i data-lucide="ChartNoAxesCombined"></i></span><strong>Ainda não há gastos para mostrar</strong><p>Suas despesas aparecerão aqui, separadas por categoria.</p></div>';return;}
  const rows=sorted.length>5?[...sorted.slice(0,4),[null,sorted.slice(4).reduce((s,r)=>s+r[1],0)]]:sorted;
  const colors=['#f2b84b','#5b8cff','#38b985','#b29bff','#e08da7'];
  target.innerHTML=`<div class="home-spending-total"><span>Total de saídas</span><strong>${fmt(sum)}</strong></div><ul class="home-category-list">${rows.map(([cat,value],i)=>{
    const pct=value/sum*100,label=cat===null?'Demais categorias':getCategoryLabel(cat),color=categoryColor(cat)||colors[i];
    return `<li><div class="home-category-heading"><span class="home-category-name"><i class="home-category-dot" style="background:${color}" aria-hidden="true"></i>${escapeHtml(label)}</span><strong>${fmt(value)}</strong></div><div class="home-category-meter"><div class="home-category-track" aria-hidden="true"><span style="width:${pct.toFixed(3)}%;background:${color}"></span></div><span class="home-category-percent">${pct<1?'< 1':Math.round(pct)}%</span></div></li>`;
  }).join('')}</ul>`;
}
window.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('home-import').addEventListener('click',async()=>{
    const button=document.getElementById('home-import');if(button.disabled)return;button.disabled=true;
    try{await goTo('screen-insert');toggleActionMenu('import-menu');document.querySelector('#import-menu > button').focus();}
    catch(error){showToast(getApiErrorMessage(error,'Não foi possível abrir a importação'),'error');}
    finally{button.disabled=false;}
  });
  document.getElementById('home-limit-action').addEventListener('click',()=>{
    const credit=state.wallets.some(w=>String(w.id)===state.walletFilter&&w.tipo==='credito');goTo(credit?'screen-wallets':'screen-limit');
  });
});

/* ── INSERT / EDIT ── */
function renderMonthlyLimitCard() {
  const limit = Number(state.monthlyLimit || 0);
  const value = document.getElementById('card-limite');

  if (!value) return;

  const selected=state.wallets.find(w=>String(w.id)===state.walletFilter);
  const credit=selected?.tipo==='credito';
  value.closest('.card').querySelector('.card-label').textContent=credit?'Limite disponível':'Limite mensal';
  value.textContent=credit?fmt(selected.disponivel):(limit>0?fmt(limit):'Sem limite');
  value.title=credit?`Limite total: ${fmt(selected.limite)} · inclui parcelas futuras`:'Limite mensal de gastos definido nas configurações';
}

async function saveMonthlyLimit() {
  if (!state.token || state.loading.saveLimit) return;

  const input = document.getElementById('monthly-limit-input');
  const value = Number(String(input?.value || '0').replace(',', '.'));

  if (!Number.isFinite(value) || value < 0) {
    showToast('Informe um limite mensal valido', 'error');
    return;
  }

  try {
    state.loading.saveLimit = true;
    const data = await updateUserSettings({ limite_gastos_mensal: value });
    state.monthlyLimit = Number(data.limite_gastos_mensal || 0);
    await goTo('screen-home');
    if (document.getElementById('screen-detail')?.classList.contains('active')) renderDetail();
    showToast('Limite mensal salvo', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao salvar limite mensal'), 'error');
  } finally {
    state.loading.saveLimit = false;
  }
}

function initLimitForm() {
  const input = document.getElementById('monthly-limit-input');
  const title = document.getElementById('limit-page-title');
  const limit = Number(state.monthlyLimit || 0);

  if (title) title.textContent = limit > 0 ? 'Editar limite débito' : 'Adicionar limite débito';
  if (input) {
    input.value = limit > 0 ? String(limit) : '';
    setTimeout(() => input.focus(), 0);
  }
}

function initInsertForm() {
  setupDateInputLimit();

  if (!state.editingTransactionId) {
    document.getElementById('f-data').value = getTodayInputValue();
    document.getElementById('f-desc').value = '';
    document.getElementById('f-valor').value = '';
    document.getElementById('f-cat').value = '';
    setType('entrada');
    resetScheduleFields();
  }
  updateInsertHeader();
}

function resetInsertMode() {
  state.editingTransactionId = null;
  document.getElementById('f-desc').value = '';
  document.getElementById('f-valor').value = '';
  document.getElementById('f-cat').value = '';
  setupDateInputLimit();
  document.getElementById('f-data').value = getTodayInputValue();
  setType('entrada');
  resetScheduleFields();
  updateInsertHeader();
}

function cancelEdit() {
  resetInsertMode();
  showToast('Edição cancelada', 'success');
}

function renderCategoryOptions(type, selectedCategory = '') {
  const select = document.getElementById('f-cat');
  if (!select) return;

  const validCategories = categoriesByType[type] || [];
  const options = ['<option value="">Selecione uma categoria</option>']
    .concat(validCategories.map(cat => {
      const selected = cat === selectedCategory ? 'selected' : '';
      return `<option value="${cat}" ${selected}>${getCategoryLabel(cat)}</option>`;
    }));

  const customCategories = state.customCategories
    .filter(item => item.type === type)
    .sort((a, b) => a.label.localeCompare(b.label, 'pt-BR'));

  if (selectedCategory?.startsWith(`custom_${type}_`) && !customCategories.some(item => item.id === selectedCategory)) {
    customCategories.push({ id: selectedCategory, type, label: getCategoryLabel(selectedCategory) });
  }

  if (customCategories.length) {
    options.push('<optgroup label="Categorias personalizadas">');
    customCategories.forEach(item => {
      const selected = item.id === selectedCategory ? 'selected' : '';
      options.push(`<option value="${item.id}" ${selected}>${escapeHtml(item.label)}</option>`);
    });
    options.push('</optgroup>');
  }

  select.innerHTML = options.join('');
}

function resetScheduleFields() {
  const parcelado = document.getElementById('f-parcelado');
  const parcelas = document.getElementById('f-parcelas');

  if (parcelado) parcelado.checked = false;
  if (parcelas) parcelas.value = '2';
  toggleScheduleFields();
}

function toggleScheduleFields() {
  const isEditable = !state.editingTransactionId;
  const options = document.getElementById('schedule-options');
  const parcelado = document.getElementById('f-parcelado');
  const parcelasField = document.getElementById('parcelas-field');

  options?.classList.toggle('hidden', !isEditable);
  parcelasField?.classList.toggle('hidden', !parcelado?.checked);
  const income=state.insertType==='entrada';
  document.getElementById('schedule-label').textContent=income?'Entrada recorrente':'Valor parcelado';
  document.getElementById('schedule-count-label').textContent=income?'Quantidade de meses':'Quantidade de parcelas';
  document.getElementById('f-parcelas').max=income?'120':'60';
  document.getElementById('schedule-hint').hidden=!isEditable||!income||!parcelado?.checked;
}

function setType(t, selectedCategory = '') {
  const changed=state.insertType!==t;
  state.insertType = t;
  if(changed)resetScheduleFields();
  document.getElementById('btn-entrada').className = 'type-btn' + (t === 'entrada' ? ' active entrada' : '');
  document.getElementById('btn-saida').className = 'type-btn' + (t === 'saida' ? ' active saida' : '');
  renderCategoryOptions(t, selectedCategory);
  toggleScheduleFields();
}

function goInsertType(t) {
  state.editingTransactionId = null;
  setType(t);
  goTo('screen-insert');
}

function startEditTransaction(id) {
  const tx = state.transactions.find(t => Number(t.id) === Number(id));
  if (!tx) {
    showToast('Lançamento não encontrado', 'error');
    return;
  }

  state.editingTransactionId = tx.id;
  resetScheduleFields();
  setType(tx.tipo, tx.categoria);
  document.getElementById('f-desc').value = tx.descricao;
  document.getElementById('f-valor').value = tx.valor;
  setupDateInputLimit();
  document.getElementById('f-data').value = getDateInputValue(tx.data_lancamento);
  updateInsertHeader();
  goTo('screen-insert');
}

async function handleDeleteTransaction(id) {
  if (state.loading.deleteTransactionId) return;

  try {
    if (!state.token) {
      showToast('Usuário não autenticado', 'error');
      return;
    }

    const confirmar = await showConfirmDialog({
      title: 'Excluir lancamento?',
      text: 'Essa acao nao podera ser desfeita.',
      okText: 'Excluir'
    });
    if (!confirmar) return;

    state.loading.deleteTransactionId = id;
    renderDetail();

    await deleteLancamento(id);
    await fetchLancamentos();

    if (state.editingTransactionId === Number(id)) {
      resetInsertMode();
    }

    renderDetail();
    showToast('Lançamento excluído com sucesso!', 'success');
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao excluir lançamento'), 'error');
  } finally {
    state.loading.deleteTransactionId = null;
    renderDetail();
  }
}

async function saveTransaction() {
  if (state.loading.saveTransaction) return;

  const button = getSaveButton();

  try {
    state.loading.saveTransaction = true;
    updateInsertHeader();
    if (button) {
      button.disabled = true;
      button.style.opacity = '0.7';
      button.style.cursor = 'not-allowed';
    }

    const descricao = document.getElementById('f-desc').value.trim();
    const valor = parseFloat(document.getElementById('f-valor').value);
    const categoria = document.getElementById('f-cat').value;
    const data_lancamento = document.getElementById('f-data').value;
    const scheduled=!state.editingTransactionId&&Boolean(document.getElementById('f-parcelado')?.checked);
    const parcelado=scheduled&&state.insertType==='saida';
    const recorrente=scheduled&&state.insertType==='entrada';
    const count=parseInt(document.getElementById('f-parcelas')?.value||'1',10);
    const parcelas_total=parcelado?count:1;
    const recorrencias_total=recorrente?count:1;

    if (!state.token) {
      showToast('Usuário não autenticado', 'error');
      return;
    }

    if (!descricao) {
      showToast('Informe uma descrição', 'error');
      return;
    }

    if (!valor || valor <= 0) {
      showToast('Informe um valor válido', 'error');
      return;
    }

    if (!categoria) {
      showToast('Selecione uma categoria', 'error');
      return;
    }

    if (!isCategoryAllowedForType(categoria, state.insertType)) {
      showToast('Selecione uma categoria compatível com o tipo da movimentação', 'error');
      return;
    }

    if (!data_lancamento) {
      showToast('Informe a data', 'error');
      return;
    }

    if (data_lancamento > getTodayInputValue()) {
      showToast('A data do lançamento não pode ser posterior a hoje', 'error');
      document.getElementById('f-data')?.focus();
      return;
    }

    if (parcelado && (!Number.isInteger(parcelas_total) || parcelas_total < 2 || parcelas_total > 60)) {
      showToast('Informe uma quantidade de parcelas entre 2 e 60', 'error');
      return;
    }

    if (recorrente && (!Number.isInteger(recorrencias_total) || recorrencias_total < 2 || recorrencias_total > 120)) {
      showToast('Informe uma recorrencia entre 2 e 120 meses', 'error');
      return;
    }

    const payload = {
      tipo: state.insertType,
      carteira_id: Number(document.getElementById('f-wallet').value),
      descricao,
      valor,
      categoria,
      data_lancamento,
      parcelado,
      parcelas_total,
      recorrente,
      recorrencias_total
    };

    if (state.editingTransactionId) {
      await updateLancamento(state.editingTransactionId, payload);
      await fetchLancamentos();
      renderDetail();
      showToast('Movimentação atualizada com sucesso!', 'success');
      resetInsertMode();
      await goTo('screen-detail');
    } else {
      await createLancamento(payload);
      await fetchLancamentos();
      showToast('Movimentação salva com sucesso!', 'success');
      resetInsertMode();
      await goTo('screen-home');
    }
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao salvar movimentação'), 'error');
  } finally {
    state.loading.saveTransaction = false;
    if (button) {
      button.disabled = false;
      button.style.opacity = '1';
      button.style.cursor = 'pointer';
    }
    updateInsertHeader();
  }
}

/* ── DETAIL ── */
function renderDetail() {
  renderWalletFilters();
  renderAdvancedFilters();
  renderBarChart();
  renderDonut();
  renderEvolutionAreaChart();
  renderSpendingHeatmap();
  renderDetailTable();
}

function csvEscape(value) {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

function exportTransactionsCsv() {
  const txs = getFilteredTransactions();
  if (!txs.length) {
    showToast('Nao ha lancamentos para exportar', 'error');
    return;
  }

  const header = ['data', 'tipo', 'descricao', 'categoria', 'carteira', 'valor'];
  const rows = txs.map(t => [
    getDateInputValue(t.data_lancamento),
    t.tipo,
    t.descricao,
    getCategoryLabel(t.categoria),
    walletName(t.carteira_id),
    Number(t.valor).toFixed(2).replace('.', ',')
  ]);
  const csv = [header, ...rows].map(row => row.map(csvEscape).join(';')).join('\n');
  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `finia-finance-lancamentos-${getTodayInputValue()}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function exportTransactionsPdf() {
  const txs = getFilteredTransactions();
  if (!txs.length) {
    showToast('Nao ha lancamentos para exportar', 'error');
    return;
  }

  const totals = calcTotals(txs);
  const rows = txs.map(t => `
    <tr>
      <td>${fmtDate(t.data_lancamento)}</td>
      <td>${t.tipo}</td>
      <td>${escapeHtml(displayDescription(t.descricao))}</td>
      <td>${escapeHtml(getCategoryLabel(t.categoria))}</td>
      <td style="text-align:right">${fmt(t.valor)}</td>
    </tr>
  `).join('');

  const win = window.open('', '_blank');
  if (!win) {
    showToast('Permita pop-ups para gerar o PDF', 'error');
    return;
  }

  win.document.write(`
    <!doctype html>
    <html>
      <head>
        <title>Relatorio Finia Finance</title>
        <style>
          body { font-family: Arial, sans-serif; color: #111; padding: 28px; }
          h1 { margin: 0 0 8px; }
          .muted { color: #666; margin-bottom: 24px; }
          .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
          .box { border: 1px solid #ddd; border-radius: 8px; padding: 12px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { border-bottom: 1px solid #ddd; padding: 8px; font-size: 12px; }
          th { text-align: left; background: #f4f4f4; }
        </style>
      </head>
      <body>
        <h1>Finia Finance</h1>
        <div class="muted">Relatorio de lancamentos - ${new Date().toLocaleDateString('pt-BR')}</div>
        <div class="summary">
          <div class="box"><strong>Entradas</strong><br>${fmt(totals.entradas)}</div>
          <div class="box"><strong>Saidas</strong><br>${fmt(totals.saidas)}</div>
          <div class="box"><strong>Entradas menos despesas</strong><br>${fmt(totals.saldo)}</div>
        </div>
        <table>
          <thead>
            <tr><th>Data</th><th>Tipo</th><th>Descricao</th><th>Categoria</th><th style="text-align:right">Valor</th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
        <script>window.onload = () => { window.print(); }<\/script>
      </body>
    </html>
  `);
  win.document.close();
}

function splitCsvLine(line) {
  const delimiter = line.includes(';') ? ';' : ',';
  const result = [];
  let current = '';
  let quoted = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && line[i + 1] === '"') {
      current += '"';
      i++;
    } else if (ch === '"') {
      quoted = !quoted;
    } else if (ch === delimiter && !quoted) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }

  result.push(current.trim());
  return result;
}

function normalizeImportedDate(value) {
  const text = String(value || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
  const match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (match) return `${match[3]}-${match[2]}-${match[1]}`;
  return '';
}

function normalizeImportedValue(value) {
  const normalized = String(value || '')
    .replace(/[R$\s.]/g, '')
    .replace(',', '.');
  return Number(normalized);
}

function normalizeImportedCategory(value, tipo) {
  const raw = String(value || '').trim().toLowerCase();
  const found = Object.entries(catLabels).find(([, label]) => label.toLowerCase() === raw);
  const category = found ? found[0] : raw;
  return categoriesByType[tipo]?.includes(category) ? category : 'outros';
}

/* Import review: no movements are written until the user confirms the selection. */
let importDraft=null, importReading=false;
function setImportButtonsDisabled(disabled){document.querySelectorAll('#import-menu button').forEach(b=>{b.disabled=disabled;});}
async function importStatementFile(event){
 const file=event.target.files?.[0];event.target.value='';if(!file||importReading||importDraft)return;
 const userId=state.user?.id;importReading=true;setImportButtonsDisabled(true);
 try{
  let response;
  if(file.name.toLowerCase().endsWith('.pdf')||file.type==='application/pdf'){
   if(file.size>8*1024*1024)throw new Error('O PDF deve ter até 8 MB.');
   const body=new FormData();body.append('statement',file);const headers=getAuthHeaders();delete headers['Content-Type'];
   response=await fetch(`${API_URL}/import/pdf`,{method:'POST',headers,body});
  }else{
   if(file.size>2*1024*1024)throw new Error('O CSV deve ter até 2 MB.');
   response=await fetch(`${API_URL}/lancamentos/import/csv/preview`,{method:'POST',headers:getAuthHeaders(),body:JSON.stringify({csv:await file.text()})});
  }
  const data=await parseApiResponse(response);
  if(data.errors?.length)throw new Error(`O extrato tem ${data.errors.length} erro(s). ${data.errors[0].message||'Revise o arquivo.'} Nenhum lançamento foi salvo.`);
  if(!data.items?.length)throw new Error('Nenhum lançamento reconhecido neste arquivo.');
  if(state.user?.id===userId)await openImportReview(data);
 }catch(error){showToast(getApiErrorMessage(error,'Não foi possível ler o extrato'),'error');}
 finally{importReading=false;setImportButtonsDisabled(false);}
}
function importRowStatus(row){
 if(row.duplicate)return ['duplicate','Já importado'];
 if(row.reviewed)return ['reviewed','Revisado'];
 if(row.source==='saved')return ['saved','Regra pessoal'];
 if(row.source==='file')return ['suggested','Categoria do arquivo'];
 return row.suggestion.revisar?['review','Revisar']:['suggested','Categoria sugerida'];
}
function importRuleValid(rule){return categoriesByType[rule.tipo]?.includes(rule.categoria)||state.customCategories.some(c=>c.id===rule.categoria&&c.type===rule.tipo);}
async function openImportReview(data){
 const userId=state.user?.id;await fetchOrganization();
 let rules=[],ruleWarning='';
 try{rules=await organizationRequest('/regras-importacao');}
 catch(error){ruleWarning='Não foi possível carregar as regras pessoais. As sugestões gerais continuam disponíveis.';}
 if(state.user?.id!==userId)return;
 const duplicates=new Set(data.duplicate_indexes||[]);
 importDraft={saving:false,keys:new Map(),rules,rows:data.items.map((item,index)=>{
  const original=item.descricao_original||item.descricao;
  const suggestion=window.FiniaCatalog.suggest(original,item.tipo);
  const key=window.FiniaCatalog.merchantKey(original);
  const explicit=item.categoria&&item.categoria!=='outros';
  const rule=!explicit&&rules.find(r=>r.tipo===item.tipo&&r.estabelecimento===key&&importRuleValid(r));
  return {payload:{...item,descricao_original:original,descricao:rule?.nome||suggestion.descricao,categoria:explicit?item.categoria:rule?.categoria||suggestion.categoria},original,key,suggestion,source:explicit?'file':rule?'saved':'auto',duplicate:duplicates.has(index),selected:!duplicates.has(index)&&suggestion.selecionado,reviewed:false,remember:false};
 })};
 const wallet=document.getElementById('import-review-wallet');wallet.innerHTML=walletOptions(state.wallets);
 wallet.value=document.getElementById('f-wallet').value||String(state.wallets.find(w=>w.padrao)?.id||state.wallets[0]?.id||'');
 document.getElementById('import-review-rule-warning').textContent=ruleWarning;
 document.getElementById('import-review-filter').value='all';
 renderImportRows();renderImportRules();document.getElementById('import-review-status').textContent='';
 updateImportSummary();applyImportFilter();document.getElementById('import-review').showModal();
}
function renderImportRows(){
 if(!importDraft)return;
 document.getElementById('import-review-rows').innerHTML=importDraft.rows.map((row,index)=>{
  const t=row.payload,[status,label]=importRowStatus(row);
  const categories=[...categoriesByType[t.tipo].map(id=>({id,label:getCategoryLabel(id)})),...state.customCategories.filter(c=>c.type===t.tipo)];
  return `<article class="import-review-row ${row.duplicate?'import-duplicate':''}" data-import-row="${index}">
   <div class="import-row-heading"><label class="import-include"><input type="checkbox" data-import-field="selected" aria-label="Incluir lançamento ${index+1}" ${row.selected?'checked':''} ${row.duplicate?'disabled':''}><span>Lançamento ${index+1}<small>${fmtDate(t.data_lancamento)} · ${t.tipo==='saida'?'Saída':'Entrada'}</small></span></label><strong class="import-amount ${t.tipo==='saida'?'expense':'income'}">${t.tipo==='saida'?'−':'+'}${fmt(t.valor)}</strong></div>
   <div class="import-status-line"><span class="import-badge ${status}" data-import-badge>${label}</span><span class="import-excluded" data-import-excluded ${row.selected?'hidden':''}>Não será importado</span></div>
   <div class="import-row-fields"><label>Nome do lançamento<input data-import-field="descricao" maxlength="150" value="${escapeHtml(t.descricao)}" ${row.duplicate?'disabled':''}></label><label>Categoria<select data-import-field="categoria" ${row.duplicate?'disabled':''}>${categories.map(c=>`<option value="${escapeHtml(c.id)}" ${c.id===t.categoria?'selected':''}>${escapeHtml(c.label)}</option>`).join('')}</select></label></div>
   <p class="import-reason">${escapeHtml(row.source==='saved'?'Nome e categoria definidos por uma regra da sua conta.':row.source==='file'?'Categoria informada no arquivo; você pode ajustar.':row.suggestion.motivo)}</p>
   <div class="import-row-bottom"><details class="original-description"><summary>Ver descrição original</summary><p>${escapeHtml(row.original)}</p></details>${!row.duplicate?'<button type="button" class="import-mark-reviewed" data-import-reviewed>Marcar revisado</button>':''}</div>
   ${!row.duplicate&&row.key.length>=4&&row.key.length<=220?`<label class="import-remember"><input type="checkbox" data-import-field="remember"><span>Lembrar nome e categoria<small>Aplicar a este mesmo estabelecimento nas próximas importações.</small></span></label>`:''}
  </article>`;
 }).join('');
}
function renderImportRules(){
 if(!document.getElementById('import-rules-list'))return;
 if(!importDraft)return;
 document.getElementById('import-rules-label').textContent=`Minhas regras (${importDraft.rules.length})`;
 document.getElementById('import-rules-list').innerHTML=importDraft.rules.length?importDraft.rules.map(r=>`<div class="import-rule-item"><span><strong>${escapeHtml(r.nome)}</strong><small>${escapeHtml(getCategoryLabel(r.categoria))} · ${r.tipo==='saida'?'Saída':'Entrada'}${importRuleValid(r)?'':' · Categoria indisponível'}</small></span><button type="button" class="btn btn-outline btn-sm" data-delete-import-rule="${escapeHtml(r.chave)}" aria-label="Remover regra ${escapeHtml(r.nome)}">Remover</button></div>`).join(''):'<p class="import-reason">Ao corrigir um lançamento, marque “Lembrar nome e categoria”. A regra será salva depois da confirmação da importação e ficará disponível nesta conta.</p>';
}
function updateImportSummary(){
 if(!importDraft)return;
 const selected=importDraft.rows.filter(r=>r.selected&&!r.duplicate),totals=calcTotals(selected.map(r=>r.payload));
 const pending=selected.filter(r=>importRowStatus(r)[0]==='review').length;
 document.getElementById('import-review-count').textContent=String(selected.length);
 document.getElementById('import-review-income').textContent=fmt(totals.entradas);
 document.getElementById('import-review-expense').textContent=fmt(totals.saidas);
 document.getElementById('import-review-summary').textContent=`${selected.length} de ${importDraft.rows.length} selecionados${pending?` · ${pending} para revisar`:''}`;
 const submit=document.getElementById('import-review-submit');submit.disabled=!selected.length||importDraft.saving;submit.textContent=importDraft.saving?'Importando…':`Importar ${selected.length} lançamento${selected.length===1?'':'s'}`;
}
function applyImportFilter(){
 if(!importDraft)return;
 const filter=document.getElementById('import-review-filter').value,query=window.FiniaCatalog.normalize('').replace(/\s/g,'');let visible=0;
 document.querySelectorAll('[data-import-row]').forEach(el=>{
  const r=importDraft.rows[Number(el.dataset.importRow)],status=importRowStatus(r)[0];
  const text=window.FiniaCatalog.normalize(`${r.payload.descricao} ${r.original} ${getCategoryLabel(r.payload.categoria)}`).replace(/\s/g,'');
  const match=(!query||text.includes(query))&&(filter==='all'||filter===status||(filter==='excluded'&&!r.selected));
  el.hidden=!match;if(match)visible++;
 });
 document.getElementById('import-review-empty').hidden=visible>0;
 document.getElementById('import-review-visible').textContent=`${visible} lançamento${visible===1?'':'s'} exibido${visible===1?'':'s'}`;
}
function closeImportReview(){if(importDraft?.saving)return;document.getElementById('import-review').close();importDraft=null;}
async function confirmImportReview(event){
 event.preventDefault();if(!importDraft||importDraft.saving)return;
 const draft=importDraft,userId=state.user?.id,walletId=Number(document.getElementById('import-review-wallet').value);
 const selected=draft.rows.filter(r=>r.selected&&!r.duplicate),items=selected.map(r=>({...r.payload,carteira_id:walletId}));
 const status=document.getElementById('import-review-status');if(!items.length)return;
 if(!walletId||items.some(t=>!t.descricao.trim())){status.textContent='Escolha uma organização e informe o nome dos lançamentos selecionados.';return;}
 const savedRules=new Map();
 for(const row of selected.filter(r=>r.remember)){
  const rule={tipo:row.payload.tipo,descricao_original:row.original,nome:row.payload.descricao.trim(),categoria:row.payload.categoria},key=`${rule.tipo}:${row.key}`,old=savedRules.get(key);
  if(old&&(old.nome!==rule.nome||old.categoria!==rule.categoria)){status.textContent='Há correções diferentes para o mesmo estabelecimento. Marque apenas a regra que deseja lembrar.';return;}
  savedRules.set(key,rule);
 }
 if(savedRules.size>100){status.textContent='Salve no máximo 100 regras por importação.';return;}
 draft.saving=true;
 const controls=[...document.querySelectorAll('#import-review input,#import-review select,#import-review button')],disabledBefore=controls.map(el=>el.disabled);
 controls.forEach(el=>{el.disabled=true;});status.textContent='Validando e salvando lançamentos…';updateImportSummary();
 let completed=false;
 try{
  const preview=await parseApiResponse(await fetch(`${API_URL}/lancamentos/import/preview`,{method:'POST',headers:getAuthHeaders(),body:JSON.stringify({items})}));
  if(!preview.ok)throw new Error(preview.errors?.[0]?.message||'Revise os lançamentos selecionados.');
  if(!draft.keys.has(preview.preview_hash))draft.keys.set(preview.preview_hash,crypto.randomUUID());
  const result=await parseApiResponse(await fetch(`${API_URL}/lancamentos/import`,{method:'POST',headers:{...getAuthHeaders(),'Idempotency-Key':draft.keys.get(preview.preview_hash)},body:JSON.stringify({items:preview.items,preview_hash:preview.preview_hash})}));
  completed=true;if(state.user?.id!==userId)return;
  let ruleError=false;
  if(savedRules.size){try{await organizationRequest('/regras-importacao','PUT',{rules:[...savedRules.values()]});}catch(error){ruleError=true;}}
  if(state.user?.id!==userId)return;
  draft.saving=false;closeImportReview();state.walletFilter=String(walletId);state.detailFilters={period:'all',type:'all',category:'all'};
  await goTo('screen-detail');
  showToast(`${result.imported} lançamento(s) importado(s). ${result.skipped_duplicates||0} duplicado(s) ignorado(s).${ruleError?' As regras pessoais não puderam ser salvas.':savedRules.size?' Correções lembradas para as próximas importações.':''}`,ruleError?'error':'success');
 }catch(error){status.textContent=completed?'Importação salva. Não foi possível atualizar a tela; volte ao painel para recarregar.':getApiErrorMessage(error,'Falha ao importar. Tente novamente sem duplicar o lote.');showToast(status.textContent,'error');}
 finally{draft.saving=false;controls.forEach((el,i)=>{el.disabled=disabledBefore[i];});updateImportSummary();}
}
window.addEventListener('DOMContentLoaded',()=>{
 const dialog=document.createElement('dialog');dialog.id='import-review';dialog.setAttribute('aria-labelledby','import-review-title');
 dialog.innerHTML=`<form id="import-review-form"><header class="import-review-header"><div class="import-title-row"><div><span class="import-eyebrow">IMPORTAÇÃO DE EXTRATO</span><h2 id="import-review-title">Revise antes de importar</h2><p class="import-intro">Confira os nomes, ajuste as categorias e escolha o que deseja salvar.</p></div><button type="button" class="import-close" id="import-review-close" aria-label="Fechar revisão">×</button></div><div class="import-top-grid"><label>Organização de destino<select id="import-review-wallet" required></select></label><div class="import-totals"><div><span>Selecionados</span><strong id="import-review-count">0</strong></div><div><span>Entradas</span><strong id="import-review-income" class="income">R$ 0,00</strong></div><div><span>Saídas</span><strong id="import-review-expense" class="expense">R$ 0,00</strong></div></div></div></header><div class="import-review-scroll"><p id="import-review-rule-warning" role="status"></p><div class="import-review-toolbar"><label>Exibir<select id="import-review-filter"><option value="all">Todos</option><option value="review">Para revisar</option><option value="suggested">Categorias sugeridas</option><option value="saved">Regras pessoais</option><option value="reviewed">Revisados</option><option value="excluded">Desmarcados</option><option value="duplicate">Já importados</option></select></label></div><p id="import-review-visible" class="import-reason"></p><div id="import-review-rows"></div><p id="import-review-empty" hidden>Nenhum lançamento encontrado para este filtro.</p></div><footer class="import-review-footer"><p id="import-review-status" role="status"></p><p id="import-review-summary" aria-live="polite"></p><div class="import-footer-actions"><button type="button" class="btn btn-outline" id="import-review-cancel">Cancelar</button><button type="submit" class="btn btn-primary" id="import-review-submit">Importar selecionados</button></div></footer></form>`;
 document.body.appendChild(dialog);
 dialog.addEventListener('cancel',event=>{if(importDraft?.saving)event.preventDefault();else importDraft=null;});
 ['import-review-cancel','import-review-close'].forEach(id=>document.getElementById(id).addEventListener('click',closeImportReview));
 document.getElementById('import-review-form').addEventListener('submit',confirmImportReview);
 
 document.getElementById('import-review-filter').addEventListener('change',applyImportFilter);
 function updateBadge(el,row){const [status,label]=importRowStatus(row);const badge=el.querySelector('[data-import-badge]');badge.className=`import-badge ${status}`;badge.textContent=label;el.querySelector('[data-import-excluded]').hidden=row.selected;}
 document.getElementById('import-review-rows').addEventListener('input',event=>{
  const el=event.target.closest('[data-import-row]');if(!el||!importDraft||importDraft.saving)return;
  const row=importDraft.rows[Number(el.dataset.importRow)],field=event.target.dataset.importField;
  if(row.duplicate)return;
  if(field==='selected'||field==='remember')row[field]=event.target.checked;
  else if(field==='descricao'||field==='categoria'){row.payload[field]=event.target.value;row.reviewed=true;}
  updateBadge(el,row);updateImportSummary();
 });
 document.getElementById('import-review-rows').addEventListener('click',event=>{
  const button=event.target.closest('[data-import-reviewed]');if(!button||!importDraft||importDraft.saving)return;
  const el=button.closest('[data-import-row]'),row=importDraft.rows[Number(el.dataset.importRow)];row.reviewed=true;button.textContent='Revisado';updateBadge(el,row);updateImportSummary();applyImportFilter();
 });
 document.getElementById('import-rules-list')?.addEventListener('click',async event=>{
  const button=event.target.closest('[data-delete-import-rule]');if(!button||!importDraft||importDraft.saving)return;
  button.disabled=true;const draft=importDraft;
  try{await organizationRequest(`/regras-importacao/${button.dataset.deleteImportRule}`,'DELETE');if(importDraft!==draft)return;draft.rules=draft.rules.filter(r=>r.chave!==button.dataset.deleteImportRule);renderImportRules();showToast('Regra removida para as próximas importações.','success');}
  catch(error){button.disabled=false;showToast(getApiErrorMessage(error,'Erro ao remover regra'),'error');}
 });
});

function renderBarChart() {
  const filtered = getFilteredTransactions();
  const saidas = filtered.filter(t => t.tipo === 'saida');
  const byCat = {};

  saidas.forEach(t => {
    byCat[t.categoria] = (byCat[t.categoria] || 0) + Number(t.valor);
  });

  const sorted = Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const max = sorted.length ? sorted[0][1] : 1;
  const colors = [
    ['#ff6b6b', '#ff9a76'],
    ['#f2b84b', '#ffe08a'],
    ['#5b8cff', '#8fb8ff'],
    ['#38b985', '#72ddb0'],
    ['#8b7cf6', '#b5a8ff'],
    ['#db6fa9', '#f5a8cf']
  ];
  const el = document.getElementById('bar-chart');

  if (!sorted.length) {
    el.innerHTML = `<div class="empty-state" style="padding:24px"><p>Sem despesas registradas no filtro atual</p></div>`;
    return;
  }

  el.innerHTML = sorted.map(([cat, val], i) => `
    <div class="bar-row">
      <div class="bar-label">
        <span class="bar-category">${categoryIcon(cat)} ${escapeHtml(getCategoryLabel(cat))}</span>
        <span>${fmt(val)}</span>
      </div>
      <div class="bar-track">
        <div class="bar-fill" style="width:${(val / max * 100).toFixed(1)}%;--bar-start:${categoryColor(cat)||colors[i % colors.length][0]};--bar-end:${categoryColor(cat)||colors[i % colors.length][1]}"></div>
      </div>
    </div>
  `).join('');
  refreshLucideIcons(el);
}

function renderDonut() {
  const filtered = getFilteredTransactions();
  const { entradas, saidas } = calcTotals(filtered);
  const el = document.getElementById('compare-chart');
  if (!el) return;

  const limit = Number(state.monthlyLimit || 0);
  const limitUsedPct = limit > 0 ? Math.min((saidas / limit) * 100, 100) : 0;
  const max = Math.max(entradas, saidas, 1);
  const entradaPct = (entradas / max) * 100;
  const saidaPct = (saidas / max) * 100;
  const saldo = entradas - saidas;

  el.innerHTML = `
    <div class="compare-summary">
      <div>
        <span>Entradas menos despesas no filtro</span>
        <strong class="${saldo >= 0 ? 'pos' : 'neg'}">${fmt(saldo)}</strong>
      </div>
      <small>${filtered.length} lançamento${filtered.length !== 1 ? 's' : ''}</small>
    </div>

    <div class="compare-row">
      <div class="compare-head">
        <span><i style="background:var(--green)"></i>Entradas</span>
        <strong>${fmt(entradas)}</strong>
      </div>
      <div class="compare-track">
        <div class="compare-fill green" style="width:${entradaPct.toFixed(1)}%"></div>
      </div>
    </div>

    <div class="compare-row">
      <div class="compare-head">
        <span><i style="background:var(--red)"></i>Saídas</span>
        <strong>${fmt(saidas)}</strong>
      </div>
      <div class="compare-track">
        <div class="compare-fill red" style="width:${saidaPct.toFixed(1)}%"></div>
      </div>
    </div>

    ${limit > 0 ? `
      <div class="compare-row limit">
        <div class="compare-head">
          <span><i style="background:var(--accent)"></i>Uso do limite mensal</span>
          <strong>${limitUsedPct.toFixed(0)}% de ${fmt(limit)}</strong>
        </div>
        <div class="compare-track">
          <div class="compare-fill accent ${limitUsedPct >= 100 ? 'danger' : ''}" style="width:${limitUsedPct.toFixed(1)}%"></div>
        </div>
      </div>
    ` : ''}
  `;
}

function renderLineChart() {
  const filtered = getFilteredTransactions();
  const svg = document.getElementById('line-svg');
  const W = 800;
  const H = 220;
  const padX = 54;
  const padTop = 46;
  const padBottom = 38;
  const months = new Map();

  filtered.forEach(t => {
    const data = parseTransactionDate(t.data_lancamento);
    const chave = `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, '0')}`;
    const label = data.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }).replace('.', '');
    const current = months.get(chave) || { chave, label, entradas: 0, saidas: 0 };

    if (t.tipo === 'entrada') {
      current.entradas += Number(t.valor);
    } else {
      current.saidas += Number(t.valor);
    }

    months.set(chave, current);
  });

  const data = [...months.values()].sort((a, b) => a.chave.localeCompare(b.chave));
  if (!data.length) {
    svg.innerHTML = `
      <text x="${W / 2}" y="${H / 2}" text-anchor="middle" font-size="13" fill="${cssVar('--text-3') || '#A8A59F'}" font-family="DM Sans,sans-serif">Sem lançamentos para evoluir no filtro atual</text>
    `;
    return;
  }

  const mutedColor = cssVar('--text-3') || '#A8A59F';
  const greenColor = cssVar('--green') || '#2D7A4F';
  const redColor = cssVar('--red') || '#C0392B';
  const textColor = cssVar('--text-2') || '#6D6A64';
  const axisColor = cssVar('--text') || '#111';
  const limitColor = cssVar('--accent') || '#F5B83D';
  const limit = Number(state.monthlyLimit || 0);
  const maxValue = Math.max(...data.flatMap(m => [m.entradas, m.saidas]), limit, 1) * 1.12;
  const chartW = W - padX * 2;
  const chartH = H - padTop - padBottom;
  const groupW = chartW / data.length;
  const barW = Math.min(36, Math.max(12, groupW * 0.24));
  const gap = Math.min(8, Math.max(4, groupW * 0.08));
  const baselineY = padTop + chartH;
  const yScale = value => baselineY - (value / maxValue) * chartH;

  const bars = data.map((m, i) => {
    const cx = padX + groupW * i + groupW / 2;
    const entradaY = yScale(m.entradas);
    const saidaY = yScale(m.saidas);
    const greenH = baselineY - yScale(m.entradas);
    const redH = baselineY - yScale(m.saidas);
    const entradaLabelY = Math.max(14, entradaY - 8);
    const saidaLabelY = Math.max(14, saidaY - 8);

    return `
      ${m.entradas > 0 ? `<text x="${cx - barW / 2 - gap / 2}" y="${entradaLabelY}" text-anchor="middle" font-size="10" font-weight="700" fill="${greenColor}" font-family="DM Sans,sans-serif">${fmt(m.entradas)}</text>` : ''}
      ${m.saidas > 0 ? `<text x="${cx + barW / 2 + gap / 2}" y="${saidaLabelY}" text-anchor="middle" font-size="10" font-weight="700" fill="${redColor}" font-family="DM Sans,sans-serif">${fmt(m.saidas)}</text>` : ''}
      <rect x="${cx - barW - gap / 2}" y="${entradaY}" width="${barW}" height="${Math.max(0, greenH)}" fill="url(#incomeGradient)" rx="7" filter="url(#softShadow)"/>
      <rect x="${cx + gap / 2}" y="${saidaY}" width="${barW}" height="${Math.max(0, redH)}" fill="url(#expenseGradient)" rx="7" filter="url(#softShadow)"/>
      <text x="${cx}" y="${H - 10}" text-anchor="middle" font-size="11" fill="${mutedColor}" font-family="DM Sans,sans-serif">${m.label}</text>
    `;
  }).join('');

  const limitY = limit > 0 ? yScale(limit) : 0;
  const gridLines = [0.25, 0.5, 0.75, 1].map(ratio => {
    const y = padTop + chartH * (1 - ratio);
    return `<line x1="${padX}" x2="${W - padX}" y1="${y}" y2="${y}" stroke="${axisColor}" stroke-opacity="0.09" stroke-width="1" stroke-dasharray="4 7"/>`;
  }).join('');

  svg.innerHTML = `
    <defs>
      <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#7de2aa"/><stop offset="100%" stop-color="${greenColor}"/>
      </linearGradient>
      <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#ff9b91"/><stop offset="100%" stop-color="${redColor}"/>
      </linearGradient>
      <filter id="softShadow" x="-30%" y="-20%" width="160%" height="160%">
        <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity="0.16"/>
      </filter>
    </defs>
    ${gridLines}
    <line x1="${padX}" x2="${W - padX}" y1="${baselineY}" y2="${baselineY}" stroke="${axisColor}" stroke-opacity="0.32" stroke-width="1.5" stroke-linecap="round"/>
    ${limit > 0 ? `
      <text x="${padX - 48}" y="${Math.max(12, limitY - 5)}" font-size="11" fill="${textColor}" font-family="DM Sans,sans-serif">Limite</text>
      <line x1="${padX - 4}" x2="${W - padX + 4}" y1="${limitY}" y2="${limitY}" stroke="${limitColor}" stroke-width="2" stroke-dasharray="8 7" stroke-linecap="round"/>
    ` : ''}
    ${bars}
    <g transform="translate(${W - padX - 150}, 18)">
      <circle cx="0" cy="0" r="4" fill="${greenColor}"/><text x="10" y="4" font-size="11" fill="${textColor}" font-family="DM Sans,sans-serif">Entradas</text>
      <circle cx="82" cy="0" r="4" fill="${redColor}"/><text x="92" y="4" font-size="11" fill="${textColor}" font-family="DM Sans,sans-serif">Saídas</text>
    </g>
  `;
}

function renderEvolutionAreaChart() {
  const svg = document.getElementById('line-svg');
  const filtered = getFilteredTransactions();
  if (!svg) return;

  const height = 260;
  const padding = { left: 54, right: 24, top: 36, bottom: 44 };
  const months = new Map();

  filtered.forEach(transaction => {
    const date = parseTransactionDate(transaction.data_lancamento);
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    const current = months.get(key) || {
      key,
      label: date.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }).replace('.', ''),
      income: 0,
      expense: 0
    };
    current[transaction.tipo === 'entrada' ? 'income' : 'expense'] += Number(transaction.valor || 0);
    months.set(key, current);
  });

  const data = [...months.values()].sort((a, b) => a.key.localeCompare(b.key));
  const availableWidth = svg.parentElement.clientWidth || 320;
  // Preserve readable text and point spacing, including long histories.
  const width = Math.max(availableWidth, padding.left + padding.right + Math.max(1, data.length - 1) * 96);
  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  svg.style.width = `${width}px`;
  svg.style.height = `${height}px`;
  svg.parentElement.setAttribute('tabindex', '0');
  svg.parentElement.setAttribute('aria-label', width > availableWidth ? 'Evolução financeira. Role horizontalmente para ver todos os meses.' : 'Evolução financeira');
  svg.parentElement.classList.toggle('is-scrollable', width > availableWidth);
  if (!data.length) {
    svg.innerHTML = `<text x="${width / 2}" y="${height / 2}" text-anchor="middle" font-size="12" fill="${cssVar('--text-3') || '#A8A59F'}" font-family="DM Sans,sans-serif">Sem lançamentos neste filtro</text>`;
    return;
  }

  const green = cssVar('--green') || '#58C783';
  const red = cssVar('--red') || '#F06B5F';
  const muted = cssVar('--text-3') || '#7E766E';
  const axis = cssVar('--text') || '#F4F1EA';
  const surface = cssVar('--surface') || '#181B1E';
  const accent = cssVar('--accent') || '#F0B84A';
  const limit = Number(state.monthlyLimit || 0);
  const maxValue = Math.max(...data.flatMap(month => [month.income, month.expense]), limit, 1) * 1.18;
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const baseline = padding.top + chartHeight;
  const xAt = index => data.length === 1
    ? padding.left + chartWidth / 2
    : padding.left + (index / (data.length - 1)) * chartWidth;
  const yAt = value => baseline - (value / maxValue) * chartHeight;
  const incomePoints = data.map((month, index) => ({ x: xAt(index), y: yAt(month.income), value: month.income }));
  const expensePoints = data.map((month, index) => ({ x: xAt(index), y: yAt(month.expense), value: month.expense }));

  const smoothPath = points => {
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let index = 0; index < points.length - 1; index += 1) {
      const current = points[index];
      const next = points[index + 1];
      const controlX = (current.x + next.x) / 2;
      path += ` C ${controlX} ${current.y}, ${controlX} ${next.y}, ${next.x} ${next.y}`;
    }
    return path;
  };
  const shortMoney = value => value >= 1000
    ? `R$ ${(value / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`
    : fmt(value);
  const incomePath = smoothPath(incomePoints);
  const expensePath = smoothPath(expensePoints);
  const areaPath = points => `${smoothPath(points)} L ${points.at(-1).x} ${baseline} L ${points[0].x} ${baseline} Z`;
  const grid = [0, 0.25, 0.5, 0.75, 1].map(ratio => {
    const y = padding.top + chartHeight * (1 - ratio);
    const value = ratio === 0 ? '0' : shortMoney(maxValue * ratio).replace('R$ ', '');
    return `<line x1="${padding.left}" x2="${width - padding.right}" y1="${y}" y2="${y}" stroke="${axis}" stroke-opacity="0.08" stroke-width="1" stroke-dasharray="4 7"/><text x="${padding.left - 9}" y="${y + 3}" text-anchor="end" font-size="9" fill="${muted}" font-family="DM Sans,sans-serif">${value}</text>`;
  }).join('');
  const pointsMarkup = (points, color, name, offset) => points.map((point, index) => `
    <g class="line-point">
      <circle cx="${point.x}" cy="${point.y}" r="8" fill="${color}" fill-opacity="0.14"/>
      <circle cx="${point.x}" cy="${point.y}" r="3.7" fill="${color}" stroke="${surface}" stroke-width="2"><title>${name} em ${data[index].label}: ${fmt(point.value)}</title></circle>
      <text x="${point.x}" y="${Math.max(15, (Math.abs(incomePoints[index].y - expensePoints[index].y) < 36 ? (offset < 0 ? Math.min(incomePoints[index].y, expensePoints[index].y) : Math.max(incomePoints[index].y, expensePoints[index].y)) : point.y) + offset)}" text-anchor="${data.length === 1 ? 'middle' : index === 0 ? 'start' : index === data.length - 1 ? 'end' : 'middle'}" font-size="11" font-weight="700" fill="${color}" font-family="DM Sans,sans-serif">${shortMoney(point.value)}</text>
    </g>
  `).join('');
  const labels = data.map((month, index) => `<text x="${xAt(index)}" y="${height - 12}" text-anchor="middle" font-size="11" fill="${muted}" font-family="DM Sans,sans-serif">${month.label}</text>`).join('');
  const limitY = yAt(limit);

  svg.innerHTML = `
    <defs>
      <linearGradient id="incomeArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${green}" stop-opacity="0.3"/><stop offset="100%" stop-color="${green}" stop-opacity="0.01"/></linearGradient>
      <linearGradient id="expenseArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${red}" stop-opacity="0.24"/><stop offset="100%" stop-color="${red}" stop-opacity="0.01"/></linearGradient>
      <filter id="lineGlow" x="-20%" y="-30%" width="140%" height="160%"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#000" flood-opacity="0.12"/></filter>
    </defs>
    ${grid}
    <path d="${areaPath(incomePoints)}" fill="url(#incomeArea)"/>
    <path d="${areaPath(expensePoints)}" fill="url(#expenseArea)"/>
    <path d="${incomePath}" fill="none" stroke="${green}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" filter="url(#lineGlow)" vector-effect="non-scaling-stroke"/>
    <path d="${expensePath}" fill="none" stroke="${red}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" filter="url(#lineGlow)" vector-effect="non-scaling-stroke"/>
    ${limit > 0 ? `<line x1="${padding.left}" x2="${width - padding.right}" y1="${limitY}" y2="${limitY}" stroke="${accent}" stroke-width="2" stroke-dasharray="8 7"/><text x="${width - padding.right}" y="${Math.max(12, limitY - 7)}" text-anchor="end" font-size="10" font-weight="600" fill="${accent}" font-family="DM Sans,sans-serif">Limite ${fmt(limit)}</text>` : ''}
    ${pointsMarkup(incomePoints, green, 'Entradas', -12)}
    ${pointsMarkup(expensePoints, red, 'Saídas', 19)}
    ${labels}
  `;
}

function changeHeatmapMonth(offset) {
  const today = new Date();
  const currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const selected = state.heatmapMonth
    ? new Date(`${state.heatmapMonth}-01T12:00:00`)
    : currentMonth;
  const target = new Date(selected.getFullYear(), selected.getMonth() + Number(offset || 0), 1);

  const latest = getHeatmapExpenses().reduce((month, t) => String(t.data_lancamento || '').slice(0, 7) > month ? String(t.data_lancamento).slice(0, 7) : month, getTodayInputValue().slice(0, 7));
  if (target > new Date(`${latest}-01T12:00:00`)) return;
  state.heatmapMonth = `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, '0')}`;
  renderSpendingHeatmap();
}

function getHeatmapExpenses() {
  // Each installment belongs to its posting date, not the original purchase date.
  return getFilteredTransactions().filter(t => t.tipo === 'saida' && /^\d{4}-\d{2}-\d{2}/.test(String(t.data_lancamento || '')));
}

function renderSpendingHeatmap() {
  const container = document.getElementById('spending-heatmap');
  if (!container) return;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const filteredExpenses = getHeatmapExpenses();
  const expenseMonths = filteredExpenses.map(t => String(t.data_lancamento).slice(0, 7)).sort();
  const currentKey = getTodayInputValue().slice(0, 7);
  const initialMonth = expenseMonths.includes(currentKey) ? currentKey : expenseMonths.at(-1) || currentKey;
  const lastMonth = expenseMonths.at(-1) > currentKey ? expenseMonths.at(-1) : currentKey;
  let selectedMonth = state.heatmapMonth
    ? new Date(`${state.heatmapMonth}-01T12:00:00`)
    : new Date(`${initialMonth}-01T12:00:00`);

  if (Number.isNaN(selectedMonth.getTime())) selectedMonth = currentMonth;
  state.heatmapMonth = `${selectedMonth.getFullYear()}-${String(selectedMonth.getMonth() + 1).padStart(2, '0')}`;

  const dailySpend = new Map();
  filteredExpenses.forEach(transaction => {
    const key = String(transaction.data_lancamento || '').slice(0, 10);
    if (key.startsWith(state.heatmapMonth)) {
      dailySpend.set(key, (dailySpend.get(key) || 0) + Number(transaction.valor || 0));
    }
  });

  const maxSpend = Math.max(...dailySpend.values(), 1);
  const firstWeekday = selectedMonth.getDay();
  const daysInMonth = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 0).getDate();
  const totalCells = Math.max(35, Math.ceil((firstWeekday + daysInMonth) / 7) * 7);
  const cells = [];

  for (let index = 0; index < totalCells; index += 1) {
    const dayNumber = index - firstWeekday + 1;
    if (dayNumber < 1 || dayNumber > daysInMonth) {
      cells.push('<span class="heat-cell outside-month" aria-hidden="true"></span>');
      continue;
    }

    const date = new Date(selectedMonth.getFullYear(), selectedMonth.getMonth(), dayNumber);
    const key = `${state.heatmapMonth}-${String(dayNumber).padStart(2, '0')}`;
    const isFuture = date > today;
    const value = dailySpend.get(key) || 0;
    const level = value === 0 ? 0 : Math.min(4, Math.max(1, Math.ceil(Math.sqrt(value / maxSpend) * 4)));
    const description = isFuture && !value
      ? `${fmtDate(key)}: data futura`
      : `${fmtDate(key)}: ${value ? fmt(value) : 'sem gastos'}${isFuture && value ? ' (previsto)' : ''}`;
    const classes = [
      'heat-cell',
      `heat-level-${level}`,
      isFuture && !value ? 'future-day' : '',
      date.getTime() === today.getTime() ? 'today' : ''
    ].filter(Boolean).join(' ');
    cells.push(`<span class="${classes}" title="${description}" role="img" aria-label="${description}" tabindex="0">${dayNumber}</span>`);
  }

  const monthLabelRaw = selectedMonth.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  const monthLabel = monthLabelRaw.charAt(0).toUpperCase() + monthLabelRaw.slice(1);
  const isCurrentMonth = state.heatmapMonth >= lastMonth;

  container.innerHTML = `
    <div class="heatmap-month-nav" aria-label="Selecionar mês do calendário">
      <button type="button" onclick="changeHeatmapMonth(-1)" aria-label="Ver mês anterior"><i data-lucide="ChevronLeft"></i></button>
      <strong id="heatmap-month-label" aria-live="polite">${monthLabel}</strong>
      <button type="button" onclick="changeHeatmapMonth(1)" aria-label="Ver próximo mês"${isCurrentMonth ? ' disabled' : ''}><i data-lucide="ChevronRight"></i></button>
    </div>
    <div class="heatmap-month-view">
      <div class="heatmap-weekday-labels" aria-hidden="true"><span>Dom</span><span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span></div>
      <div class="month-heatmap-grid">${cells.join('')}</div>
    </div>
  `;
  refreshLucideIcons(container);
}

function clearTransactionSelection() {
  state.selectedTransactionIds.clear();
  renderDetailTable();
}

function toggleTransactionSelection(id, checked) {
  const transactionId = Number(id);
  if (checked) state.selectedTransactionIds.add(transactionId);
  else state.selectedTransactionIds.delete(transactionId);
  renderDetailTable();
}

function toggleSelectAllTransactions(checked) {
  const visibleIds = getFilteredTransactions().map(transaction => Number(transaction.id));
  visibleIds.forEach(id => {
    if (checked) state.selectedTransactionIds.add(id);
    else state.selectedTransactionIds.delete(id);
  });
  renderDetailTable();
}

function renderBulkToolbar() {
  const toolbar = document.getElementById('bulk-toolbar');
  const count = document.getElementById('bulk-selection-count');
  const deleteButton = document.getElementById('bulk-delete-button');
  if (!toolbar || !count || !deleteButton) return;

  const selectedCount = state.selectedTransactionIds.size;
  toolbar.classList.toggle('active', selectedCount > 0);
  count.textContent = `${selectedCount} selecionado${selectedCount !== 1 ? 's' : ''}`;
  deleteButton.disabled = selectedCount === 0 || state.loading.bulkDelete;
  deleteButton.textContent = state.loading.bulkDelete
    ? `Excluindo ${selectedCount}...`
    : `Excluir ${selectedCount || ''} selecionado${selectedCount !== 1 ? 's' : ''}`.replace('  ', ' ');
}

async function deleteSelectedTransactions() {
  if (state.loading.bulkDelete || !state.selectedTransactionIds.size) return;

  const ids = [...state.selectedTransactionIds];
  const confirmed = await showConfirmDialog({
    title: `Excluir ${ids.length} lançamento${ids.length !== 1 ? 's' : ''}?`,
    text: 'Os lançamentos selecionados serão removidos permanentemente.',
    okText: 'Excluir selecionados'
  });
  if (!confirmed) return;

  const failedIds = [];
  let deletedCount = 0;
  state.loading.bulkDelete = true;
  renderDetailTable();

  try {
    for (const id of ids) {
      try {
        await deleteLancamento(id);
        deletedCount += 1;
      } catch (error) {
        console.error(error);
        failedIds.push(id);
      }
    }

    await fetchLancamentos();
    state.selectedTransactionIds = new Set(failedIds);

    if (failedIds.length) {
      showToast(`${deletedCount} excluído(s); ${failedIds.length} não puderam ser removidos`, 'error');
    } else {
      showToast(`${deletedCount} lançamento${deletedCount !== 1 ? 's' : ''} excluído${deletedCount !== 1 ? 's' : ''}`, 'success');
    }
  } catch (error) {
    console.error(error);
    showToast(getApiErrorMessage(error, 'Erro ao atualizar os lançamentos'), 'error');
  } finally {
    state.loading.bulkDelete = false;
    renderDetail();
  }
}

function renderDetailTable() {
  let txs = [...getFilteredTransactions()].sort(
    (a, b) => parseTransactionDate(b.data_lancamento) - parseTransactionDate(a.data_lancamento)
  );

  const el = document.getElementById('detail-tx-list');
  const existingIds = new Set(state.transactions.map(transaction => Number(transaction.id)));
  state.selectedTransactionIds.forEach(id => {
    if (!existingIds.has(Number(id))) state.selectedTransactionIds.delete(id);
  });

  if (!txs.length) {
    el.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <p>Nenhum lançamento encontrado</p>
      </div>
    `;
    const selectAll = document.getElementById('select-all-transactions');
    if (selectAll) {
      selectAll.checked = false;
      selectAll.indeterminate = false;
      selectAll.disabled = true;
    }
    renderBulkToolbar();
    return;
  }

  el.innerHTML = txs.map(t => `
    <div class="tx-row ${state.selectedTransactionIds.has(Number(t.id)) ? 'selected' : ''}">
      <div class="tx-select-cell">
        <input class="tx-checkbox" type="checkbox" ${state.selectedTransactionIds.has(Number(t.id)) ? 'checked' : ''} onchange="toggleTransactionSelection(${t.id}, this.checked)" aria-label="Selecionar ${escapeHtml(displayDescription(t.descricao))}" />
      </div>
      <div class="tx-row-desc">
        <span class="tx-row-category-icon cat-${t.categoria}">${categoryIcon(t.categoria)}</span>
        <span>${escapeHtml(displayDescription(t.descricao))}${t.descricao_original ? `<details class="original-description"><summary>Descrição do extrato</summary>${escapeHtml(t.descricao_original)}</details>` : ''}</span>
        ${Number(t.parcelado) ? '<span class="tx-tag">Parcelado</span>' : ''}
        ${Number(t.recorrente) ? '<span class="tx-tag">Recorrente</span>' : ''}
        ${t.origem === 'csv' ? '<span class="tx-tag">CSV</span>' : ''}
      </div>
      <div><span class="tx-row-cat cat-${t.categoria}">${escapeHtml(getCategoryLabel(t.categoria))} · ${escapeHtml(walletName(t.carteira_id))}</span></div>
      <div class="tx-row-date">${fmtDate(t.data_lancamento)}</div>
      <div class="tx-row-val" style="color:${t.tipo === 'entrada' ? 'var(--green)' : 'var(--red)'}">
        ${t.tipo === 'entrada' ? '+' : '-'}${fmt(t.valor)}
      </div>
      <div style="text-align:right; display:flex; justify-content:flex-end; gap:6px; flex-wrap:wrap;">
        <button class="btn btn-outline btn-sm" onclick="startEditTransaction(${t.id})" ${state.loading.bulkDelete ? 'disabled' : ''}>Editar</button>
        <button class="btn btn-ghost btn-sm" onclick="handleDeleteTransaction(${t.id})" ${state.loading.bulkDelete ? 'disabled' : ''}>
          ${state.loading.deleteTransactionId === t.id ? 'Excluindo...' : 'Excluir'}
        </button>
      </div>
    </div>
  `).join('');
  refreshLucideIcons(el);

  const visibleIds = txs.map(transaction => Number(transaction.id));
  const visibleSelected = visibleIds.filter(id => state.selectedTransactionIds.has(id)).length;
  const selectAll = document.getElementById('select-all-transactions');
  if (selectAll) {
    selectAll.disabled = state.loading.bulkDelete;
    selectAll.checked = visibleSelected === visibleIds.length;
    selectAll.indeterminate = visibleSelected > 0 && visibleSelected < visibleIds.length;
  }
  renderBulkToolbar();
}

/* ── INIT ── */
window.addEventListener('DOMContentLoaded', async () => {
  applyTheme(loadThemeLocal());

  const resetToken = getResetTokenFromUrl();
  if (window.location.hash.startsWith('#screen-reset-password') && resetToken) {
    goTo('screen-reset-password');
    return;
  }

  try {
    const session = await restoreSession();
    if (session?.usuario) {
      state.user = session.usuario;
      state.token = true;
      setAvatars();
      await fetchLancamentos();
      await fetchUserSettings();
      goTo('screen-home');
    } else {
      goTo('screen-login');
    }
  } catch (error) {
    console.error(error);
    state.user = null;
    state.token = null;
    goTo('screen-login');
  }

  setupDateInputLimit();

  ensureCancelEditButton();
  updateInsertHeader();
});

window.addEventListener('keydown', event => {
  if (event.key === 'Escape') {
    hideFutureFeatures();
    closeActionMenus();
  }
});

window.addEventListener('click', event => {
  if (!event.target.closest?.('.action-menu')) {
    closeActionMenus();
  }
});

/* Carteiras e categorias pertencem à conta autenticada. */
async function organizationRequest(path, method='GET', body) {
  return parseApiResponse(await fetch(`${API_URL}${path}`, {
    method,headers:getAuthHeaders(),...(body?{body:JSON.stringify(body)}:{})
  }));
}
async function fetchOrganization() {
  const [wallets,categories]=await Promise.all([
    organizationRequest('/carteiras'),organizationRequest('/categorias')
  ]);
  state.wallets=wallets;state.customCategories=categories;
  if(state.walletFilter!=='all'&&!wallets.some(w=>String(w.id)===state.walletFilter)) state.walletFilter='all';
}
function walletName(id) {
  return (state.wallets.find(w=>Number(w.id)===Number(id)) || state.wallets.find(w=>w.padrao))?.nome || 'Débito';
}
function walletTransactions() {
  return state.transactions.filter(t=>state.walletFilter==='all'||String(t.carteira_id || state.wallets.find(w=>w.padrao)?.id)===state.walletFilter);
}
function walletOptions(wallets) {
  return wallets.map(w=>`<option value="${w.id}">${escapeHtml(w.nome)} (${w.tipo==='credito'?'Crédito':w.tipo==='vr'?'VR / VA':'Débito'})</option>`).join('');
}
function renderWalletSelect() {
  const select=document.getElementById('f-wallet');
  const tx=state.transactions.find(t=>Number(t.id)===Number(state.editingTransactionId));
  const selected=tx?.carteira_id || select.value || (state.walletFilter!=='all'?state.walletFilter:null);
  select.innerHTML=walletOptions(state.wallets);
  if(selected&&state.wallets.some(w=>String(w.id)===String(selected))) select.value=selected;
}
function renderWalletFilters() {
  document.querySelectorAll('.wallet-filter').forEach(select=>{
    select.innerHTML='<option value="all">Todas as organizações</option>'+walletOptions(state.wallets);
    select.value=state.walletFilter;
    select.onchange=()=>{state.walletFilter=select.value;state.heatmapMonth=null;if(state.detailFilters.period==='invoice')state.detailFilters.period='all';state.selectedTransactionIds.clear();renderHome();renderDetail();};
  });
}
function renderWalletCards(target) {
  const element=document.getElementById(target);
  const wallets=state.wallets.filter(w=>target==='wallet-list'||state.walletFilter==='all'||String(w.id)===state.walletFilter);
  element.innerHTML=wallets.map(w=>`<article class="wallet-card">
    <h3>${escapeHtml(w.nome)}</h3>
    ${w.tipo==='credito'?`<form class="closing-form" data-closing-wallet="${w.id}"><label>Dia de fechamento <input aria-label="Dia de fechamento de ${escapeHtml(w.nome)}" type="number" min="1" max="31" step="1" required value="${Number(w.dia_fechamento)||''}"></label><button type="submit" class="btn btn-outline">Salvar fechamento</button></form>`:''}
    <button type="button" class="btn btn-outline organization-delete" data-delete-wallet="${w.id}">Excluir organização</button>
  </article>`).join('');
}
function renderOrganization() {
  renderWalletCards('wallet-list');
  document.getElementById('category-list').innerHTML=['saida','entrada'].map(type=>`<section class="wallet-card"><h3>${type==='saida'?'Despesas':'Receitas'}</h3><div class="category-chips">${(categoriesByType[type]||[]).map(id=>`<span>${escapeHtml(getCategoryLabel(id))}</span>`).join('')}${state.customCategories.filter(c=>c.type===type).map(c=>`<span class="custom-chip" style="border-color:${categoryColor(c.id)||'#F2B84B'}">${categoryIcon(c.id)}${escapeHtml(c.label)}<button type="button" class="category-delete" data-delete-category="${escapeHtml(c.id)}" aria-label="Excluir categoria ${escapeHtml(c.label)}" title="Excluir categoria">×</button></span>`).join('')}</div></section>`).join('');
  refreshLucideIcons(document.getElementById('category-list'));
}
window.addEventListener('DOMContentLoaded',()=>{
  const colorInput=document.getElementById('category-color');
  const colorPreview=document.getElementById('category-color-preview');
  const updateColorPreview=()=>{colorPreview.style.borderColor=colorInput.value;colorPreview.style.backgroundColor=colorInput.value+'22';};
  colorInput.addEventListener('input',updateColorPreview);updateColorPreview();
  const picker=document.getElementById('category-icon-picker');
  function renderPicker(){picker.innerHTML=Object.entries(CATEGORY_ICONS).map(([label,icon])=>`<button type="button" data-icon="${icon}" title="${label}" aria-label="${label}" aria-pressed="${icon===selectedCategoryIcon}"><i data-lucide="${icon}"></i><span>${label}</span></button>`).join('');refreshLucideIcons(picker);}
  picker.addEventListener('click',e=>{const b=e.target.closest('[data-icon]');if(b){selectedCategoryIcon=b.dataset.icon;renderPicker();}});renderPicker();
  document.getElementById('wallet-list').addEventListener('submit',async e=>{
    const form=e.target.closest('[data-closing-wallet]');if(!form)return;e.preventDefault();const b=form.querySelector('button');if(b.disabled)return;b.disabled=true;
    try{await organizationRequest(`/carteiras/${form.dataset.closingWallet}/fechamento`,'PATCH',{dia_fechamento:Number(form.querySelector('input').value)});await fetchOrganization();renderOrganization();showToast('Fechamento salvo','success');}catch(err){showToast(err.message,'error');b.disabled=false;}
  });
  async function removeOrganization(event, kind) {
    const button=event.target.closest(kind==='wallet'?'[data-delete-wallet]':'[data-delete-category]');
    if(!button||button.disabled)return;
    const id=kind==='wallet'?button.dataset.deleteWallet:button.dataset.deleteCategory;
    if(!confirm(kind==='wallet'?'Excluir esta organização? Organizações com movimentações não podem ser excluídas.':'Excluir esta categoria? Categorias utilizadas em lançamentos não podem ser excluídas.'))return;
    button.disabled=true;
    try {
      await organizationRequest(`/${kind==='wallet'?'carteiras':'categorias'}/${encodeURIComponent(id)}`,'DELETE');
      await fetchOrganization();renderOrganization();renderWalletFilters();
      showToast(kind==='wallet'?'Organização excluída':'Categoria excluída','success');
    } catch(error){showToast(error.message,'error');button.disabled=false;}
  }
  document.getElementById('wallet-list').addEventListener('click',e=>removeOrganization(e,'wallet'));
  document.getElementById('category-list').addEventListener('click',e=>removeOrganization(e,'category'));
  const type=document.getElementById('w-type');
  type.addEventListener('change',()=>{
    document.getElementById('w-credit-fields').hidden=type.value!=='credito';
    document.getElementById('w-closing').required=type.value==='credito';
    document.getElementById('w-balance-field').hidden=type.value==='credito';
  });
  async function submitForm(event,action) {
    event.preventDefault();const button=event.target.querySelector('[type="submit"]');
    if(button.disabled)return;button.disabled=true;
    try {await action();await fetchOrganization();renderOrganization();}
    catch(e){showToast(e.message||'Não foi possível salvar','error');}
    finally {button.disabled=false;}
  }
  document.getElementById('wallet-create-form').addEventListener('submit',event=>submitForm(event,async()=>{
    const value=id=>document.getElementById(id).value;
    await organizationRequest('/carteiras','POST',{nome:value('w-name'),tipo:type.value,dia_fechamento:type.value==='credito'?Number(value('w-closing')):null,saldo_inicial:type.value==='credito'?0:value('w-balance'),limite:type.value==='credito'?value('w-limit'):0,divida_inicial:type.value==='credito'?value('w-debt'):0});
    event.target.reset();type.dispatchEvent(new Event('change'));showToast('Organização criada','success');
  }));
  document.getElementById('category-create-form').addEventListener('submit',event=>submitForm(event,async()=>{
    await organizationRequest('/categorias','POST',{label:document.getElementById('category-name').value,type:document.getElementById('category-type').value,icon:selectedCategoryIcon,color:document.getElementById('category-color').value});
    document.getElementById('category-name').value='';selectedCategoryIcon='Shapes';colorInput.value='#f2b84b';updateColorPreview();renderPicker();showToast('Categoria criada','success');
  }));
});


/* Profile controls and home period filter. Events are bound without inline scripts. */
let avatarSaving = false;
const financeScreens = ['screen-home', 'screen-detail', 'screen-categories', 'screen-wallets', 'screen-help', 'screen-assistant', 'screen-insert', 'screen-limit', 'screen-settings'];
function financeNavigationMarkup(activeId) {
  const links = [
    ['screen-home', 'Visão geral', 'House'],
    ['screen-detail', 'Relatórios', 'ChartNoAxesCombined'],
    ['screen-categories', 'Categorias', 'Shapes'],
    ['screen-wallets', 'Organizações', 'WalletCards'],
    ['screen-assistant', 'Assistente', 'Sparkles'],
    ['screen-help', 'Ajuda', 'BookOpen']
  ];
  return `<nav class="finance-nav" aria-label="Navegação financeira">${links.map(([id, label, icon]) => `<button type="button" data-screen="${id}" aria-label="${label}" class="${id === activeId ? 'active' : ''}" aria-current="${id === activeId ? 'page' : 'false'}" onclick="goTo('${id}')"><i data-lucide="${icon}"></i><span>${label}</span></button>`).join('')}</nav>`;
}
function financeProfileMarkup(suffix) {
  return `<div class="profile-menu"><button class="nav-avatar" id="nav-avatar-${suffix}" type="button" aria-label="Abrir menu do perfil" aria-expanded="false" aria-controls="nav-avatar-${suffix}-menu">J</button><div class="profile-menu-list" id="nav-avatar-${suffix}-menu" hidden><button type="button" data-profile-action="settings">Configurações</button><button type="button" data-profile-action="logout">Sair da conta</button></div></div>`;
}
function ensureFinanceNavigation(activeId = 'screen-home') {
  financeScreens.forEach(screenId => {
    const screen = document.getElementById(screenId), nav = screen?.querySelector('.app-nav');
    if (!nav) return;
    const suffix = screenId.replace('screen-', '');
    nav.innerHTML = `<div class="nav-logo">Finia <span>Finance</span></div>${financeNavigationMarkup(activeId === screenId ? screenId : (document.querySelector('.screen.active')?.id || activeId))}<div class="nav-right"><button class="theme-toggle" type="button" onclick="toggleTheme()" aria-label="Alternar tema escuro" aria-pressed="false"><span class="theme-toggle-track"><span class="theme-toggle-thumb"></span></span><span class="theme-toggle-label">Escuro</span></button>${financeProfileMarkup(suffix)}</div>`;
  });
  refreshLucideIcons();
}
function updateFinanceNavigation(activeId) {
  const currentId = document.querySelector('.screen.active')?.id || activeId;
  document.querySelectorAll('.finance-nav').forEach(nav => nav.querySelectorAll('button').forEach(button => {
    const isActive = button.dataset.screen === currentId;
    button.classList.toggle('active', isActive);
    button.setAttribute('aria-current', isActive ? 'page' : 'false');
  }));
}
function closeProfileMenus(restoreFocus = false) {
  document.querySelectorAll('.profile-menu').forEach(menu => {
    const button = menu.querySelector('.nav-avatar');
    if (restoreFocus && button.getAttribute('aria-expanded') === 'true') button.focus();
    button.setAttribute('aria-expanded', 'false');
    menu.querySelector('.profile-menu-list').hidden = true;
  });
}
async function saveAvatarBlob(blob) {
  if (avatarSaving) return;
  const userId = state.user?.id;
  avatarSaving = true;
  const status = document.getElementById('avatar-status');
  const controls = document.querySelectorAll('#avatar-symbols button, #profile-photo');
  controls.forEach(el => { el.disabled = true; });
  status.textContent = 'Salvando foto…';
  try {
    if (!blob || blob.size > 1024 * 1024) throw new Error('Não foi possível ajustar a foto. Escolha outra imagem.');
    const form = new FormData();
    form.append('avatar', blob, 'perfil.png');
    const headers = getAuthHeaders();
    delete headers['Content-Type'];
    const response = await fetch(`${API_URL}/user/profile/avatar`, { method: 'PUT', headers, body: form });
    const profile = await parseApiResponse(response);
    if (!state.user || state.user.id !== userId) return;
    state.user = { ...state.user, ...profile };
    setAvatars();
    status.textContent = 'Foto de perfil salva.';
    showToast('Foto de perfil atualizada', 'success');
  } catch (error) {
    status.textContent = getApiErrorMessage(error, 'Erro ao salvar a foto');
    showToast(status.textContent, 'error');
  } finally {
    avatarSaving = false;
    controls.forEach(el => { el.disabled = false; });
    document.getElementById('profile-photo').value = '';
  }
}
function canvasBlob(canvas) {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Não foi possível preparar a imagem.')), 'image/png'));
}
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-profile-action="profile"]').forEach(button => button.remove());
  document.querySelectorAll('.home-secondary-nav').forEach(nav => nav.remove());
  ensureFinanceNavigation(document.querySelector('.screen.active')?.id || 'screen-home');
  const syncMobileNavigation = () => {
    const scrolled = window.scrollY > 8;
    document.querySelectorAll('.app-nav, .finance-nav').forEach(nav => nav.classList.toggle('is-scrolled', scrolled));
  };
  window.addEventListener('scroll', syncMobileNavigation, { passive: true });
  syncMobileNavigation();
  const evolutionWrap = document.getElementById('line-chart-wrap');
  let evolutionWidth = 0;
  if (evolutionWrap && typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(entries => {
      const width = entries[0].contentRect.width;
      if (width > 0 && Math.abs(width - evolutionWidth) > 1) {
        evolutionWidth = width;
        renderEvolutionAreaChart();
      }
    }).observe(evolutionWrap);
  }
  document.getElementById('home-period').addEventListener('change', event => {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(event.target.value)) {
      event.target.value = state.homeMonth || getTodayInputValue().slice(0, 7);
      return;
    }
    state.homeMonth = event.target.value;
    renderHome();
  });
  document.querySelectorAll('.profile-menu').forEach(menu => {
    const toggle = menu.querySelector('.nav-avatar');
    const list = menu.querySelector('.profile-menu-list');
    toggle.addEventListener('click', () => {
      const opening = list.hidden;
      closeProfileMenus();
      list.hidden = !opening;
      toggle.setAttribute('aria-expanded', String(opening));
      if (opening) list.querySelector('button').focus();
    });
    list.addEventListener('click', async event => {
      const button = event.target.closest('[data-profile-action]');
      if (!button) return;
      closeProfileMenus();
      if (button.dataset.profileAction === 'logout') { await doLogout(); return; }
      await goTo('screen-settings');
    });
  });
  document.addEventListener('click', event => { if (!event.target.closest('.profile-menu')) closeProfileMenus(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeProfileMenus(true); });
  document.addEventListener('focusin', event => { if (!event.target.closest('.profile-menu')) closeProfileMenus(); });
  const symbols = [['★','Estrela'], ['♥','Coração'], ['☀','Sol'], ['☾','Lua'], ['♫','Música'], ['✿','Flor']];
  const picker = document.getElementById('avatar-symbols');
  symbols.forEach(([symbol, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = symbol;
    button.setAttribute('aria-label', `Usar símbolo: ${label}`);
    button.title = label;
    button.addEventListener('click', async () => {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 256;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#F2B84B'; ctx.fillRect(0, 0, 256, 256);
      ctx.fillStyle = '#20252b'; ctx.font = '150px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(symbol, 128, 139);
      try { await saveAvatarBlob(await canvasBlob(canvas)); }
      catch (error) { showToast(error.message, 'error'); }
    });
    picker.appendChild(button);
  });
  document.getElementById('profile-photo').addEventListener('change', async event => {
    const file = event.target.files[0];
    if (!file || avatarSaving) return;
    let url;
    try {
      if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('Escolha uma foto JPG, PNG ou WebP.');
      if (file.size > 20 * 1024 * 1024) throw new Error('Escolha uma foto de até 20 MB.');
      url = URL.createObjectURL(file);
      const img = new Image();
      img.src = url;
      await img.decode();
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 384;
      const side = Math.min(img.naturalWidth, img.naturalHeight);
      canvas.getContext('2d').drawImage(img, (img.naturalWidth-side)/2, (img.naturalHeight-side)/2, side, side, 0, 0, 384, 384);
      await saveAvatarBlob(await canvasBlob(canvas));
    } catch (error) { showToast(error.message || 'Não foi possível abrir a foto.', 'error'); }
    finally { if (url) URL.revokeObjectURL(url); event.target.value = ''; }
  });
});
