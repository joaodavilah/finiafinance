# Finia Finance v10 — leitura, regras pessoais e revisão

## Novidades

- Corrige a leitura de textos fragmentados pelo PDF, como “LACO S TE TIJU CAS”. A detecção de títulos e operações bancárias tolera esses espaços.
- O leitor Santander entende tanto a ordem visual (valor antes da linha do estabelecimento) quanto a ordem da biblioteca do site (valor depois dessa linha). Mantém a data contábil, sem substituir pela data da compra.
- Sugere nomes e categorias com regras locais e termos conhecidos. Nomes desconhecidos permanecem para revisão, sem deduzir a finalidade de um Pix pelo nome da pessoa.
- A opção “Lembrar nome e categoria” salva uma regra explícita na conta depois da importação confirmada. O reconhecimento compara o mesmo estabelecimento e tipo de movimentação, ignorando diferenças de espaçamento. Não usa aproximações entre nomes de pessoas.
- As regras podem ser consultadas e removidas em “Minhas regras”, na prévia. Remover uma regra afeta as próximas importações, sem alterar os lançamentos já salvos.
- A prévia tem busca, filtros por situação, totais separados, nomes e categorias editáveis, descrição original recolhida e indicação de lançamentos desmarcados.
- Cabeçalho e rodapé ficam separados da lista rolável, com botões acessíveis em telas pequenas. A confirmação antes de gravar foi mantida.

## Deploy e dados

As configurações de hospedagem, o arquivo de ambiente, as dependências e as migrações anteriores permanecem intactos. A nova migração 010 cria a tabela de regras por usuário usando o mecanismo automático de inicialização já existente. Não há serviço externo de IA nem nova dependência de produção.

As melhorias valem para novas importações. Não alteram os lançamentos antigos. Extratos importados pelo leitor anterior podem ter descrições e datas diferentes: revise possíveis duplicidades antes de reimportar.

Aplicações, resgates e pagamentos de fatura começam desmarcados; se incluídos, entram nos totais de entradas/saídas. A importação específica de fatura de cartão não foi adicionada nesta versão.

## Validação

- 26 testes automatizados aprovados: leitura fragmentada, categorias, datas, parcelas, saldos, regras por usuário, validação de categorias personalizadas, exclusão e substituição de regras, idempotência e descrição original.
- Leitura do PDF fornecido com pdf-parse 2.4.5 (mesma biblioteca de produção): 92 movimentações, com os totais conferidos contra o resumo do banco.
- Testes em Chromium com respostas de API conectadas aos serviços locais de teste: importação somente após confirmação, busca/filtros, nome e categoria lembrados após recarregar, exclusão de regra e duplicidades.
- Conferência de layout em 320, 375, 390, 768 e 1280 pixels, incluindo temas claro e escuro. Sem sobreposição do rodapé ou rolagem horizontal na prévia.

Os testes de persistência usam o adaptador SQLite do projeto. Não foi feito deploy nem acesso ao MySQL da hospedagem.
