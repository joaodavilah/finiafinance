# Banco de dados canônico do Finia

Esta pasta passa a ter uma única fonte de verdade para o schema: os módulos numerados em
`database/migrations/`. Os arquivos `financas_tcc.sql` e
`financas_tcc_hospedagem.sql` são preservados apenas como dumps legados e não devem receber
novas alterações manuais.

## Versão de runtime

Use Node.js 24, conforme o campo `engines` do `package.json`. A dependência `pdf-parse@2.4.5`
presente no lockfile não suporta Node 18.
Em deploy, prefira `npm ci --omit=dev` com a mesma versão de Node validada na integração
contínua.

## Pool injetável

`src/database` não lê `process.env`. A aplicação deve validar o ambiente e injetar a
configuração:

```js
const {
  createDatabasePool,
  createMigrationRunner,
  testDatabaseConnection
} = require('../src/database');

const pool = createDatabasePool({
  ...config.database,
  connectionLimit: 10,
  queueLimit: 100,
  connectTimeoutMs: 10_000,
  requireTls: config.isProduction && config.database.ssl
});

await testDatabaseConnection(pool);
await createMigrationRunner({ pool }).run();
```

`queueLimit` nunca pode ser zero: a fila é finita por construção. TLS usa no mínimo 1.2 e
valida o certificado por padrão. Desabilitar essa validação exige a opção explícita
`rejectUnauthorized=false`, que deve ser tratado como exceção temporária documentada e nunca
é aceito pelo carregador atual em produção.

## Runner de migrations

O runner:

- adquire `GET_LOCK('finia:schema-migrations')` em uma conexão dedicada;
- cria e consulta `schema_migrations`;
- verifica SHA-256 de toda migration já aplicada;
- abre transação para cada migration e só registra a versão após `up()` concluir;
- sempre tenta liberar o advisory lock.

MySQL e MariaDB fazem commit implícito em vários comandos DDL. Por isso, as migrations de
schema também são idempotentes e consultam `information_schema`: após uma interrupção, a
mesma migration pode ser executada novamente com segurança. Uma migration aplicada nunca
deve ser editada; crie a próxima numeração.

Antes de `003_enforce_idempotency`, dados legados duplicados precisam ser resolvidos por uma
decisão humana. A migration falha sem apagar registros se encontrar:

- o mesmo `item_id` Pluggy associado a mais de um usuário;
- o mesmo `(usuario_id, origem, origem_id)` em lançamentos importados.

## Garantias do schema

- `auth_sessions`: JTI do JWT e CSRF são armazenados somente como SHA-256, possuem expiração
  e `revoked_at`. O contrato corresponde a `createSessionRepository(pool)` em
  `src/repositories/sessionRepository.js`; a única definição do schema permanece nas migrations.
- `conexoes_bancarias.item_id`: único globalmente. Um item Pluggy só pode ter um dono local.
- `conexoes_bancarias`: lease de sincronização (`sync_lock_token` +
  `sync_lock_expira`) evita duas sincronizações concorrentes.
- `lancamentos`: `UNIQUE(usuario_id, origem, origem_id)` torna o upsert importado idempotente.
- `lotes_importacao`: `UNIQUE(usuario_id, idempotency_key)` registra progresso, resultados e
  falhas sem guardar payload bancário bruto.
- `itens_lote_importacao`: trilha dos lançamentos inseridos ou atualizados em cada lote.

## Integração Pluggy

Os módulos são CommonJS e recebem todas as dependências:

```js
const { createPluggyClient } = require('../src/integrations/pluggy');
const { createBankRepository } = require('../src/repositories/bankRepository');
const { createBankService } = require('../src/services/bankService');
const { createBankRouter } = require('../src/routes/bankRouter');

if (!config.pluggy.enabled) {
  throw new Error('Integração Pluggy não configurada');
}

const pluggyClient = createPluggyClient(config.pluggy);

const repository = createBankRepository({ pool });
const bankService = createBankService({
  repository,
  pluggyClient,
  logger,
  connectTokenOptions: config.pluggy.connectOptions
});

app.use(
  '/api/v1/bank',
  createBankRouter({
    bankService,
    authenticate,
    requireCsrf,
    logger
  })
);
```

`authenticate` deve validar uma sessão ativa/revogável no servidor e preencher
`req.auth.userId` ou `req.user.id`. `requireCsrf` é obrigatório no factory e deve comparar o
token recebido com o hash da sessão usando comparação de tempo constante.

### Contrato HTTP do router

- `GET /api/v1/bank/status`: lista somente as conexões do usuário autenticado.
- `POST /api/v1/bank/connect-token`: cria token Pluggy com `clientUserId` derivado da sessão.
  `itemId` no corpo é opcional e serve para atualizar uma conexão já pertencente ao usuário.
- `POST /api/v1/bank/connection`: recebe `{ "itemId": "..." }`. Antes de salvar, o serviço chama
  `GET /items/{id}` e exige que `item.clientUserId === String(userId)`.
- `POST /api/v1/bank/sync`: recebe `itemId`, `dateFrom` e `dateTo`; exige header
  `Idempotency-Key` com 8–128 caracteres seguros. Sincroniza somente um item owned por vez.
- `DELETE /api/v1/bank/connection/:itemId`: valida o owner, chama `DELETE /items/{id}` e então
  remove metadados, lotes e locks locais. `?purgeImportedData=true` também remove os
  lançamentos Pluggy vinculados; sem essa opção, preserva o histórico financeiro e desvincula
  a conexão.

Erros públicos seguem o contrato comum da API:

```json
{
  "erro": "O provedor bancario demorou para responder. Tente novamente",
  "codigo": "BANK_PROVIDER_TIMEOUT",
  "requestId": "..."
}
```

Mensagens, payloads e credenciais brutas do provedor não são repassados ao cliente nem ao
logger. O cliente usa `AbortController`, limite de resposta, cache single-flight da API key e
cursor de `/v2/transactions` até o fim. Se houver cursor após `maxPages`, ele falha
explicitamente; dados nunca são truncados silenciosamente.

Os fluxos seguem os endpoints oficiais atuais da Pluggy:

- <https://docs.pluggy.ai/reference/connect-token-create>
- <https://docs.pluggy.ai/reference/transactions-list-by-cursor>
- <https://docs.pluggy.ai/docs/consent-management-delete-an-item>

## Operação e recuperação

Migrations não substituem backup. Antes de aplicar uma nova versão em produção:

1. confirme backup automático do provedor e gere um dump criptografado adicional;
2. registre versão da aplicação e última migration aplicada;
3. execute migrations em etapa única antes de liberar tráfego;
4. valide readiness do banco e smoke tests;
5. faça periodicamente uma restauração em ambiente isolado.

Defina RPO, RTO, retenção e responsável pelo restore no runbook da hospedagem.
