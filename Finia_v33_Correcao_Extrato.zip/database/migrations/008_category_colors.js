 'use strict';
const {addColumnIfMissing}=require('./helpers');
module.exports={name:'custom category colors',async up({connection}){
 await addColumnIfMissing(connection,'categorias_usuario','color',"CHAR(7) NOT NULL DEFAULT '#F2B84B'");
}};
