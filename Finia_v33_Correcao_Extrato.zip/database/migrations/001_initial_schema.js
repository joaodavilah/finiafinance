'use strict';

module.exports = {
  name: 'initial canonical schema',

  async up({ connection }) {
    await connection.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        nome_completo VARCHAR(150) NOT NULL,
        email VARCHAR(150) NOT NULL,
        senha VARCHAR(255) NOT NULL,
        plano ENUM('gratuito', 'premium') NOT NULL DEFAULT 'gratuito',
        limite_gastos_mensal DECIMAL(10,2) NOT NULL DEFAULT 0,
        reset_token VARCHAR(255) NULL,
        reset_token_expira DATETIME NULL,
        data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        atualizado_em DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        UNIQUE KEY uniq_usuarios_email (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS auth_sessions (
        id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
        usuario_id INT NOT NULL,
        jwt_jti_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
        csrf_token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
        expires_at_ms BIGINT UNSIGNED NOT NULL,
        ip_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
        user_agent_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
        created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        last_seen_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        revoked_at DATETIME(3) NULL,
        UNIQUE KEY uniq_auth_sessions_jti (jwt_jti_hash),
        KEY idx_auth_sessions_user_active (usuario_id, revoked_at, expires_at_ms),
        KEY idx_auth_sessions_expiry (expires_at_ms),
        CONSTRAINT fk_auth_sessions_user
          FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS conexoes_bancarias (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        item_id VARCHAR(150) NOT NULL,
        client_user_id VARCHAR(150) NOT NULL,
        connector_name VARCHAR(150) NULL,
        status VARCHAR(40) NOT NULL DEFAULT 'ativo',
        sync_status VARCHAR(20) NOT NULL DEFAULT 'idle',
        sync_lock_token CHAR(36) NULL,
        sync_lock_expira DATETIME(3) NULL,
        sync_cursor TEXT NULL,
        sync_erro_codigo VARCHAR(80) NULL,
        ultima_sincronizacao DATETIME(3) NULL,
        sync_iniciada_em DATETIME(3) NULL,
        revogada_em DATETIME(3) NULL,
        data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        UNIQUE KEY uniq_conexao_item (item_id),
        KEY idx_conexoes_usuario_status (usuario_id, status),
        KEY idx_conexoes_sync_lock (sync_lock_expira),
        CONSTRAINT fk_conexoes_usuario
          FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS lotes_importacao (
        id CHAR(36) NOT NULL PRIMARY KEY,
        usuario_id INT NOT NULL,
        conexao_bancaria_id INT NULL,
        idempotency_key VARCHAR(128) NOT NULL,
        request_hash CHAR(64) NOT NULL,
        origem VARCHAR(30) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'processing',
        processados INT UNSIGNED NOT NULL DEFAULT 0,
        inseridos INT UNSIGNED NOT NULL DEFAULT 0,
        atualizados INT UNSIGNED NOT NULL DEFAULT 0,
        ignorados INT UNSIGNED NOT NULL DEFAULT 0,
        ultimo_cursor TEXT NULL,
        erro_codigo VARCHAR(80) NULL,
        criado_em DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        concluido_em DATETIME(3) NULL,
        UNIQUE KEY uniq_lote_usuario_idempotency (usuario_id, idempotency_key),
        KEY idx_lotes_conexao_status (conexao_bancaria_id, status),
        CONSTRAINT fk_lotes_usuario
          FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        CONSTRAINT fk_lotes_conexao
          FOREIGN KEY (conexao_bancaria_id) REFERENCES conexoes_bancarias(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS lancamentos (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        conexao_bancaria_id INT NULL,
        lote_importacao_id CHAR(36) NULL,
        tipo ENUM('entrada', 'saida') NOT NULL,
        descricao VARCHAR(150) NOT NULL,
        valor DECIMAL(10,2) NOT NULL,
        categoria VARCHAR(100) NOT NULL,
        data_lancamento DATE NOT NULL,
        parcelado BOOLEAN NOT NULL DEFAULT FALSE,
        parcela_atual INT NULL,
        parcelas_total INT NULL,
        grupo_parcelamento VARCHAR(36) NULL,
        recorrente BOOLEAN NOT NULL DEFAULT FALSE,
        recorrencia_atual INT NULL,
        recorrencias_total INT NULL,
        grupo_recorrencia VARCHAR(36) NULL,
        origem VARCHAR(30) NOT NULL DEFAULT 'manual',
        origem_id VARCHAR(150) NULL,
        origem_conta_id VARCHAR(150) NULL,
        data_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        UNIQUE KEY uniq_lancamentos_origem (usuario_id, origem, origem_id),
        KEY idx_lancamentos_usuario_data (usuario_id, data_lancamento),
        KEY idx_lancamentos_usuario_tipo (usuario_id, tipo),
        KEY idx_lancamentos_usuario_categoria (usuario_id, categoria),
        KEY idx_lancamentos_conexao (conexao_bancaria_id),
        CONSTRAINT fk_lancamentos_usuario
          FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        CONSTRAINT fk_lancamentos_conexao
          FOREIGN KEY (conexao_bancaria_id) REFERENCES conexoes_bancarias(id) ON DELETE SET NULL,
        CONSTRAINT fk_lancamentos_lote
          FOREIGN KEY (lote_importacao_id) REFERENCES lotes_importacao(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await connection.query(`
      CREATE TABLE IF NOT EXISTS itens_lote_importacao (
        id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        lote_importacao_id CHAR(36) NOT NULL,
        lancamento_id INT NOT NULL,
        origem_id VARCHAR(150) NOT NULL,
        resultado VARCHAR(20) NOT NULL,
        processado_em DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        UNIQUE KEY uniq_item_lote_origem (lote_importacao_id, origem_id),
        KEY idx_itens_lote_lancamento (lancamento_id),
        CONSTRAINT fk_itens_lote
          FOREIGN KEY (lote_importacao_id) REFERENCES lotes_importacao(id) ON DELETE CASCADE,
        CONSTRAINT fk_itens_lancamento
          FOREIGN KEY (lancamento_id) REFERENCES lancamentos(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }
};
