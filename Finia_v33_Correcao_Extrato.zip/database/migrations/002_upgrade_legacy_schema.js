'use strict';

const { addColumnIfMissing, addForeignKeyIfMissing, addIndexIfMissing } = require('./helpers');

module.exports = {
  name: 'upgrade legacy schema with sessions, batches and sync leases',

  async up({ connection }) {
    await addColumnIfMissing(
      connection,
      'usuarios',
      'limite_gastos_mensal',
      'DECIMAL(10,2) NOT NULL DEFAULT 0'
    );
    await addColumnIfMissing(connection, 'usuarios', 'reset_token', 'VARCHAR(255) NULL');
    await addColumnIfMissing(connection, 'usuarios', 'reset_token_expira', 'DATETIME NULL');
    await addColumnIfMissing(
      connection,
      'usuarios',
      'atualizado_em',
      'DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)'
    );

    const connectionColumns = [
      ['client_user_id', 'VARCHAR(150) NULL'],
      ['sync_status', "VARCHAR(20) NOT NULL DEFAULT 'idle'"],
      ['sync_lock_token', 'CHAR(36) NULL'],
      ['sync_lock_expira', 'DATETIME(3) NULL'],
      ['sync_cursor', 'TEXT NULL'],
      ['sync_erro_codigo', 'VARCHAR(80) NULL'],
      ['ultima_sincronizacao', 'DATETIME(3) NULL'],
      ['sync_iniciada_em', 'DATETIME(3) NULL'],
      ['revogada_em', 'DATETIME(3) NULL'],
      [
        'updated_at',
        'DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)'
      ]
    ];
    for (const [column, definition] of connectionColumns) {
      await addColumnIfMissing(connection, 'conexoes_bancarias', column, definition);
    }

    const transactionColumns = [
      ['conexao_bancaria_id', 'INT NULL'],
      ['lote_importacao_id', 'CHAR(36) NULL'],
      ['parcelado', 'BOOLEAN NOT NULL DEFAULT FALSE'],
      ['parcela_atual', 'INT NULL'],
      ['parcelas_total', 'INT NULL'],
      ['grupo_parcelamento', 'VARCHAR(36) NULL'],
      ['recorrente', 'BOOLEAN NOT NULL DEFAULT FALSE'],
      ['recorrencia_atual', 'INT NULL'],
      ['recorrencias_total', 'INT NULL'],
      ['grupo_recorrencia', 'VARCHAR(36) NULL'],
      ['origem', "VARCHAR(30) NOT NULL DEFAULT 'manual'"],
      ['origem_id', 'VARCHAR(150) NULL'],
      ['origem_conta_id', 'VARCHAR(150) NULL'],
      [
        'updated_at',
        'DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)'
      ]
    ];
    for (const [column, definition] of transactionColumns) {
      await addColumnIfMissing(connection, 'lancamentos', column, definition);
    }

    await addIndexIfMissing(connection, 'conexoes_bancarias', 'idx_conexoes_usuario_status', [
      'usuario_id',
      'status'
    ]);
    await addIndexIfMissing(connection, 'conexoes_bancarias', 'idx_conexoes_sync_lock', [
      'sync_lock_expira'
    ]);
    await addIndexIfMissing(connection, 'lancamentos', 'idx_lancamentos_conexao', [
      'conexao_bancaria_id'
    ]);

    await addForeignKeyIfMissing(connection, {
      table: 'lancamentos',
      column: 'conexao_bancaria_id',
      referencedTable: 'conexoes_bancarias',
      referencedColumn: 'id',
      constraintName: 'fk_lancamentos_conexao',
      onDelete: 'SET NULL'
    });
    await addForeignKeyIfMissing(connection, {
      table: 'lancamentos',
      column: 'lote_importacao_id',
      referencedTable: 'lotes_importacao',
      referencedColumn: 'id',
      constraintName: 'fk_lancamentos_lote',
      onDelete: 'SET NULL'
    });
  }
};
