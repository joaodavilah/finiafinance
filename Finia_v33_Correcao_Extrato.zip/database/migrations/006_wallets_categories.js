'use strict';
const { addColumnIfMissing, addIndexIfMissing } = require('./helpers');
module.exports = {
  name: 'wallets, private categories and invoice payments',
  async up({ connection: c }) {
    await c.query(`CREATE TABLE IF NOT EXISTS carteiras (
      id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL,
      nome VARCHAR(60) NOT NULL, tipo ENUM('debito','credito','vr') NOT NULL,
      saldo_inicial DECIMAL(12,2) NOT NULL DEFAULT 0,
      limite DECIMAL(12,2) NOT NULL DEFAULT 0,
      divida_inicial DECIMAL(12,2) NOT NULL DEFAULT 0,
      padrao TINYINT NOT NULL DEFAULT 0,
      UNIQUE KEY uq_carteira_nome (usuario_id,nome),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
    await c.query(`CREATE TABLE IF NOT EXISTS categorias_usuario (
      usuario_id INT NOT NULL, id VARCHAR(90) NOT NULL, label VARCHAR(32) NOT NULL,
      type ENUM('entrada','saida') NOT NULL,
      PRIMARY KEY(usuario_id,id), UNIQUE KEY uq_categoria_nome(usuario_id,type,label),
      FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
    await c.query(`CREATE TABLE IF NOT EXISTS pagamentos_fatura (
      id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, usuario_id INT NOT NULL,
      origem_id INT NOT NULL, destino_id INT NOT NULL, valor DECIMAL(12,2) NOT NULL,
      data_pagamento DATE NOT NULL, chave VARCHAR(80) NOT NULL,
      UNIQUE KEY uq_pagamento_chave(usuario_id,chave),
      FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
      FOREIGN KEY(origem_id) REFERENCES carteiras(id),
      FOREIGN KEY(destino_id) REFERENCES carteiras(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
    await addColumnIfMissing(c, 'lancamentos', 'carteira_id', 'INT NULL');
    await addColumnIfMissing(c, 'lancamentos', 'data_compra', 'DATE NULL');
    await addIndexIfMissing(c, 'lancamentos', 'idx_lancamentos_carteira', [
      'usuario_id',
      'carteira_id'
    ]);
    await c.query(`INSERT INTO carteiras(usuario_id,nome,tipo,padrao)
      SELECT id,'Débito','debito',1 FROM usuarios u
      WHERE NOT EXISTS(SELECT 1 FROM carteiras w WHERE w.usuario_id=u.id AND w.padrao=1)`);
    await c.query(`UPDATE lancamentos l JOIN carteiras w ON w.usuario_id=l.usuario_id AND w.padrao=1
      SET l.carteira_id=w.id WHERE l.carteira_id IS NULL`);
  }
};
