'use strict';
const { addColumnIfMissing } = require('./helpers');
module.exports = { name: 'preserve original statement descriptions', async up({ connection }) {
  await addColumnIfMissing(connection, 'lancamentos', 'descricao_original', 'VARCHAR(1000) NULL');
}};
