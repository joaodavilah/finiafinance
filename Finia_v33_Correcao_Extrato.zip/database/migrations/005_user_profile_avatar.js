'use strict';

module.exports = {
  name: 'add private user avatars',

  async up({ connection }) {
    await connection.query(`
      CREATE TABLE IF NOT EXISTS user_avatars (
        usuario_id INT NOT NULL PRIMARY KEY,
        mime_type VARCHAR(32) NOT NULL,
        image_data MEDIUMBLOB NOT NULL,
        byte_size INT UNSIGNED NOT NULL,
        updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        CONSTRAINT fk_user_avatars_user
          FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
        CONSTRAINT chk_user_avatars_size CHECK (byte_size > 0 AND byte_size <= 1048576)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
  }
};
