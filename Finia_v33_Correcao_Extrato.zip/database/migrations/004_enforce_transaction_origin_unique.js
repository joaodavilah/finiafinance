'use strict';

const TABLE_NAME = 'lancamentos';
const INDEX_NAME = 'uniq_lancamentos_usuario_origem_id';
const INDEX_COLUMNS = Object.freeze(['usuario_id', 'origem', 'origem_id']);

function migrationConflict(code, message, cause) {
  const error = new Error(message, cause ? { cause } : undefined);
  error.code = code;
  return error;
}

function groupIndexes(rows) {
  const indexes = new Map();
  for (const row of rows) {
    const name = String(row.INDEX_NAME || row.index_name || '');
    if (!indexes.has(name)) {
      indexes.set(name, {
        name,
        unique: Number(row.NON_UNIQUE ?? row.non_unique) === 0,
        columns: []
      });
    }
    indexes.get(name).columns.push({
      name: String(row.COLUMN_NAME || row.column_name || ''),
      position: Number(row.SEQ_IN_INDEX ?? row.seq_in_index),
      prefixLength: row.SUB_PART ?? row.sub_part ?? null
    });
  }

  return [...indexes.values()].map((index) => ({
    ...index,
    columns: index.columns.sort((left, right) => left.position - right.position)
  }));
}

function isRequiredUniqueIndex(index) {
  return (
    index.unique &&
    index.columns.length === INDEX_COLUMNS.length &&
    index.columns.every(
      (column, position) => column.name === INDEX_COLUMNS[position] && column.prefixLength === null
    )
  );
}

async function findDuplicateOrigin(connection) {
  const [rows] = await connection.query(
    `SELECT usuario_id, origem, origem_id, COUNT(*) AS duplicate_count
     FROM lancamentos
     WHERE usuario_id IS NOT NULL AND origem IS NOT NULL AND origem_id IS NOT NULL
     GROUP BY usuario_id, origem, origem_id
     HAVING COUNT(*) > 1
     LIMIT 1`
  );
  return rows[0] || null;
}

async function readIndexes(connection) {
  const [rows] = await connection.execute(
    `SELECT INDEX_NAME, NON_UNIQUE, SEQ_IN_INDEX, COLUMN_NAME, SUB_PART
     FROM information_schema.statistics
     WHERE table_schema = DATABASE() AND table_name = ?
     ORDER BY INDEX_NAME, SEQ_IN_INDEX`,
    [TABLE_NAME]
  );
  return groupIndexes(rows);
}

module.exports = {
  name: 'verify transaction origin uniqueness without destructive cleanup',

  async up({ connection }) {
    const duplicate = await findDuplicateOrigin(connection);
    if (duplicate) {
      throw migrationConflict(
        'MIGRATION_DATA_CONFLICT',
        'Duplicate (usuario_id, origem, origem_id) rows must be resolved before enforcing uniqueness'
      );
    }

    const indexes = await readIndexes(connection);
    if (indexes.some(isRequiredUniqueIndex)) return;

    if (indexes.some((index) => index.name === INDEX_NAME)) {
      throw migrationConflict(
        'MIGRATION_SCHEMA_CONFLICT',
        `Index ${INDEX_NAME} exists with a different definition`
      );
    }

    try {
      await connection.query(
        `ALTER TABLE lancamentos
         ADD UNIQUE INDEX uniq_lancamentos_usuario_origem_id (usuario_id, origem, origem_id)`
      );
    } catch (error) {
      if (error?.code === 'ER_DUP_ENTRY' || Number(error?.errno) === 1062) {
        throw migrationConflict(
          'MIGRATION_DATA_CONFLICT',
          'Duplicate (usuario_id, origem, origem_id) rows appeared while enforcing uniqueness',
          error
        );
      }
      throw error;
    }
  }
};
