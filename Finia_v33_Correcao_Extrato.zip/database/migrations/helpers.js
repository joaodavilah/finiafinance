'use strict';

function quoteIdentifier(value) {
  const identifier = String(value || '');
  if (!/^[A-Za-z0-9_]+$/.test(identifier)) {
    throw new TypeError(`Unsafe SQL identifier: ${identifier}`);
  }
  return `\`${identifier}\``;
}

async function tableExists(connection, table) {
  const [rows] = await connection.execute(
    `SELECT 1
     FROM information_schema.tables
     WHERE table_schema = DATABASE() AND table_name = ?
     LIMIT 1`,
    [table]
  );
  return Boolean(rows[0]);
}

async function columnExists(connection, table, column) {
  const [rows] = await connection.execute(
    `SELECT 1
     FROM information_schema.columns
     WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?
     LIMIT 1`,
    [table, column]
  );
  return Boolean(rows[0]);
}

async function indexExists(connection, table, indexName) {
  const [rows] = await connection.execute(
    `SELECT 1
     FROM information_schema.statistics
     WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?
     LIMIT 1`,
    [table, indexName]
  );
  return Boolean(rows[0]);
}

async function foreignKeyExists(connection, table, column, referencedTable, referencedColumn) {
  const [rows] = await connection.execute(
    `SELECT 1
     FROM information_schema.key_column_usage
     WHERE table_schema = DATABASE()
       AND table_name = ?
       AND column_name = ?
       AND referenced_table_name = ?
       AND referenced_column_name = ?
     LIMIT 1`,
    [table, column, referencedTable, referencedColumn]
  );
  return Boolean(rows[0]);
}

async function addColumnIfMissing(connection, table, column, definition) {
  if (await columnExists(connection, table, column)) return false;
  await connection.query(
    `ALTER TABLE ${quoteIdentifier(table)} ADD COLUMN ${quoteIdentifier(column)} ${definition}`
  );
  return true;
}

async function addIndexIfMissing(connection, table, indexName, columns, options = {}) {
  if (await indexExists(connection, table, indexName)) return false;
  if (!Array.isArray(columns) || !columns.length) {
    throw new TypeError('Index columns are required');
  }

  const unique = options.unique ? 'UNIQUE ' : '';
  await connection.query(
    `ALTER TABLE ${quoteIdentifier(table)} ADD ${unique}INDEX ${quoteIdentifier(indexName)} (${columns
      .map(quoteIdentifier)
      .join(', ')})`
  );
  return true;
}

async function addForeignKeyIfMissing(connection, options) {
  const {
    table,
    column,
    referencedTable,
    referencedColumn,
    constraintName,
    onDelete = 'RESTRICT'
  } = options;

  if (await foreignKeyExists(connection, table, column, referencedTable, referencedColumn)) {
    return false;
  }

  const allowedDeleteActions = new Set(['RESTRICT', 'CASCADE', 'SET NULL', 'NO ACTION']);
  if (!allowedDeleteActions.has(onDelete)) {
    throw new TypeError(`Unsupported ON DELETE action: ${onDelete}`);
  }

  await connection.query(
    `ALTER TABLE ${quoteIdentifier(table)}
     ADD CONSTRAINT ${quoteIdentifier(constraintName)}
     FOREIGN KEY (${quoteIdentifier(column)})
     REFERENCES ${quoteIdentifier(referencedTable)} (${quoteIdentifier(referencedColumn)})
     ON DELETE ${onDelete}`
  );
  return true;
}

async function findDuplicate(connection, table, columns, whereSql = '1 = 1') {
  const identifiers = columns.map(quoteIdentifier).join(', ');
  const [rows] = await connection.query(
    `SELECT COUNT(*) AS duplicate_count
     FROM ${quoteIdentifier(table)}
     WHERE ${whereSql}
     GROUP BY ${identifiers}
     HAVING COUNT(*) > 1
     LIMIT 1`
  );
  return rows[0] || null;
}

module.exports = {
  addColumnIfMissing,
  addForeignKeyIfMissing,
  addIndexIfMissing,
  columnExists,
  findDuplicate,
  foreignKeyExists,
  indexExists,
  quoteIdentifier,
  tableExists
};
