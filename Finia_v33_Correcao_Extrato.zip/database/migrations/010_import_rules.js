'use strict';
module.exports={name:'user owned import classification rules',async up({connection}){
 await connection.query(`CREATE TABLE IF NOT EXISTS regras_importacao (
  usuario_id INT NOT NULL,
  chave CHAR(64) NOT NULL,
  tipo VARCHAR(7) NOT NULL,
  estabelecimento VARCHAR(220) NOT NULL,
  nome VARCHAR(150) NOT NULL,
  categoria VARCHAR(100) NOT NULL,
  PRIMARY KEY(usuario_id,chave)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
}};
