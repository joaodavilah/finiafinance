 'use strict';
const {addColumnIfMissing}=require('./helpers');
module.exports={name:'credit closing day and category icons',async up({connection:c}){
 await addColumnIfMissing(c,'carteiras','dia_fechamento','TINYINT UNSIGNED NULL');
 await addColumnIfMissing(c,'categorias_usuario','icon',"VARCHAR(32) NOT NULL DEFAULT 'Shapes'");
}};
