'use strict';

const { addIndexIfMissing, findDuplicate } = require('./helpers');

function dataConflict(message) {
  const error = new Error(message);
  error.code = 'MIGRATION_DATA_CONFLICT';
  return error;
}

module.exports = {
  name: 'enforce global bank ownership and import idempotency',

  async up({ connection }) {
    const duplicateItem = await findDuplicate(
      connection,
      'conexoes_bancarias',
      ['item_id'],
      "item_id IS NOT NULL AND item_id <> ''"
    );
    if (duplicateItem) {
      throw dataConflict(
        'Duplicate bank item ownership must be resolved before adding the global item constraint'
      );
    }

    const duplicateOrigin = await findDuplicate(
      connection,
      'lancamentos',
      ['usuario_id', 'origem', 'origem_id'],
      "origem_id IS NOT NULL AND origem_id <> ''"
    );
    if (duplicateOrigin) {
      throw dataConflict(
        'Duplicate imported transactions must be resolved before adding the idempotency constraint'
      );
    }

    await addIndexIfMissing(connection, 'conexoes_bancarias', 'uniq_conexao_item', ['item_id'], {
      unique: true
    });
    await addIndexIfMissing(
      connection,
      'lancamentos',
      'uniq_lancamentos_origem',
      ['usuario_id', 'origem', 'origem_id'],
      { unique: true }
    );
  }
};
