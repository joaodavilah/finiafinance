CREATE DATABASE IF NOT EXISTS financas_tcc;
USE financas_tcc;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_completo VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    plano ENUM('gratuito', 'premium') DEFAULT 'gratuito',
    limite_gastos_mensal DECIMAL(10,2) DEFAULT 0,
    reset_token VARCHAR(255) NULL,
    reset_token_expira DATETIME NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS lancamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('entrada', 'saida') NOT NULL,
    descricao VARCHAR(150) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    categoria VARCHAR(100) NOT NULL,
    data_lancamento DATE NOT NULL,
    parcelado BOOLEAN DEFAULT FALSE,
    parcela_atual INT NULL,
    parcelas_total INT NULL,
    grupo_parcelamento VARCHAR(36) NULL,
    recorrente BOOLEAN DEFAULT FALSE,
    recorrencia_atual INT NULL,
    recorrencias_total INT NULL,
    grupo_recorrencia VARCHAR(36) NULL,
    origem VARCHAR(30) DEFAULT 'manual',
    origem_id VARCHAR(150) NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_lancamentos_usuario_data (usuario_id, data_lancamento),
    INDEX idx_lancamentos_usuario_tipo (usuario_id, tipo),
    INDEX idx_lancamentos_usuario_categoria (usuario_id, categoria)
);

CREATE TABLE IF NOT EXISTS conexoes_bancarias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    item_id VARCHAR(150) NOT NULL,
    connector_name VARCHAR(150) NULL,
    status VARCHAR(40) DEFAULT 'ativo',
    ultima_sincronizacao DATETIME NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_conexao_usuario_item (usuario_id, item_id)
);
