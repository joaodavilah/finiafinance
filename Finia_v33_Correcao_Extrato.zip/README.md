# Finia

Aplicação de finanças pessoais com frontend React/Vite, API Express versionada e MySQL.

Projeto desenvolvido para TCC. A base foi reorganizada para separar configuração, middlewares, rotas,
serviços, repositórios, integrações e migrations.

## Requisitos

- Node.js 24 LTS
- MySQL 8 ou MariaDB compatível
- HTTPS em produção

## Execução local

1. Crie um banco vazio e um usuário próprio para a aplicação.
2. Copie `.env.example` para `.env` e preencha os valores obrigatórios.
3. Gere um segredo aleatório para `JWT_SECRET`:

   ```powershell
   node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
   ```

4. Instale as dependências e aplique o schema:

   ```powershell
   npm ci
   npm run migrate
   npm start
   ```

A aplicação fica disponível em `http://localhost:3000`. O processo também executa as
migrations pendentes antes de aceitar tráfego e encerra sem abrir a porta se banco,
configuração ou migration estiverem inválidos.

## Hospedagem

O projeto pode ser publicado como uma única aplicação Node: o Express serve o build React e a API
no mesmo domínio. Isso é necessário para os cookies seguros de sessão e para a proteção CSRF.

### Com Docker (recomendado)

```powershell
docker build -t finia .
docker run --env-file .env -p 3000:3000 finia
```

O `Dockerfile` usa Node 24, gera o frontend em uma etapa isolada, mantém somente dependências de
produção na imagem final, executa como usuário sem privilégios e inclui health check.

### Em uma plataforma Node

- Build: `npm ci && npm run build && npm prune --omit=dev`
- Start: `npm start`
- Health check: `/api/v1/health/ready`

Não publique somente a pasta `public/`: login, lançamentos e configurações dependem da API Express e
do MySQL. Consulte [docs/README_HOSPEDAGEM.txt](docs/README_HOSPEDAGEM.txt) para as variáveis e o
checklist completo de produção.

## Comandos

```text
npm start             inicia a aplicação
npm run dev           inicia com reinício automático
npm run migrate       aplica migrations pendentes
npm run migrate:status mostra migrations descobertas/aplicadas
npm run dev:frontend  inicia o frontend Vite para desenvolvimento
npm run build         gera o frontend de produção em public/
npm test              executa todos os testes
npm run test:coverage executa testes e aplica os pisos de cobertura do CI
npm run lint          verifica o JavaScript
npm run format        verifica a formatação
npm run security:audit audita dependências de produção
npm run ci            executa a validação equivalente ao CI
```

## Estrutura

```text
app.js                       ponto de entrada
src/app.js                   composição HTTP e API /api/v1
src/bootstrap.js             banco, migrations, servidor e shutdown
src/config/                  validação fail-fast do ambiente
src/middleware/              autenticação, CSRF, headers, limites e erros
src/routes/                  contratos HTTP por domínio
src/services/                regras de negócio
src/repositories/            acesso ao MySQL com ownership
src/integrations/pluggy/      cliente e mapeamento Open Finance
src/parsers/                 importações CSV e PDF
database/migrations/         fonte canônica do schema
frontend/                    código-fonte React, estilos e ativos
public/                      build de produção gerado pelo Vite
tests/                       testes unitários e de integração HTTP
.github/workflows/ci.yml      pipeline automatizado
```

Os dumps `.sql` foram mantidos somente como referência legada. Novas instalações e alterações
de schema devem usar as migrations.

## Segurança implementada

- JWT assinado sem segredo padrão, entregue apenas em cookie `HttpOnly`, `Secure` em produção e
  `SameSite=Strict`.
- Sessões persistidas no servidor, revogação individual/global e revogação no reset de senha.
- CSRF vinculado à sessão, CORS por origem exata, rate limiting global e específico de login.
- Helmet, CSP sem scripts inline, HSTS, HTTPS obrigatório e respostas sensíveis sem cache.
- Recuperação de senha com resposta não enumerável, token armazenado como hash, uso único e
  ausência de token em logs/respostas.
- Ownership local e externo obrigatório em todas as operações Pluggy.
- Upload PDF somente em memória, com tipo, assinatura, tamanho, páginas, texto e timeout
  limitados; CSV também possui limites rígidos.
- Imports transacionais, idempotentes e protegidos contra duplicidade e concorrência.
- Pool MySQL finito, TLS validado em banco remoto de produção e migrations com lock/checksum.

Detalhes e riscos residuais estão em [docs/SECURITY.md](docs/SECURITY.md). Contratos HTTP estão
em [docs/API.md](docs/API.md), e o procedimento de hospedagem está em
[docs/README_HOSPEDAGEM.txt](docs/README_HOSPEDAGEM.txt).
