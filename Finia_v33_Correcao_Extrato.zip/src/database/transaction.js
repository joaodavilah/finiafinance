'use strict';

const ISOLATION_LEVELS = new Set([
  'READ UNCOMMITTED',
  'READ COMMITTED',
  'REPEATABLE READ',
  'SERIALIZABLE'
]);

async function withTransaction(pool, work, options = {}) {
  if (!pool || typeof pool.getConnection !== 'function') {
    throw new TypeError('A database pool is required');
  }
  if (typeof work !== 'function') {
    throw new TypeError('Transaction work must be a function');
  }

  const isolationLevel = String(options.isolationLevel || 'READ COMMITTED').toUpperCase();
  if (!ISOLATION_LEVELS.has(isolationLevel)) {
    throw new TypeError(`Unsupported transaction isolation level: ${isolationLevel}`);
  }

  const connection = await pool.getConnection();
  try {
    await connection.query(`SET TRANSACTION ISOLATION LEVEL ${isolationLevel}`);
    await connection.beginTransaction();
    const result = await work(connection);
    await connection.commit();
    return result;
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      error.rollbackError = rollbackError;
    }
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  withTransaction
};
