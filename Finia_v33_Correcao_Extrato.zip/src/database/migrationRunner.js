'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

class MigrationError extends Error {
  constructor(message, code, options = {}) {
    super(message, options.cause ? { cause: options.cause } : undefined);
    this.name = 'MigrationError';
    this.code = code || 'MIGRATION_FAILED';
    this.migrationId = options.migrationId || null;
  }
}

function noop() {}

function normalizeLogger(logger) {
  return {
    info: typeof logger?.info === 'function' ? logger.info.bind(logger) : noop,
    warn: typeof logger?.warn === 'function' ? logger.warn.bind(logger) : noop,
    error: typeof logger?.error === 'function' ? logger.error.bind(logger) : noop
  };
}

function sha256File(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function discoverMigrations(migrationsDir) {
  const files = fs
    .readdirSync(migrationsDir, { withFileTypes: true })
    .filter((entry) => entry.isFile() && /^\d{3,}_[a-z0-9_-]+\.js$/i.test(entry.name))
    .map((entry) => ({
      fileName: entry.name,
      version: BigInt(entry.name.match(/^(\d+)_/)[1])
    }))
    .sort((left, right) => {
      if (left.version < right.version) return -1;
      if (left.version > right.version) return 1;
      return left.fileName.localeCompare(right.fileName, 'en');
    });

  const seenVersions = new Set();
  return files.map(({ fileName, version }) => {
    const filePath = path.join(migrationsDir, fileName);
    const id = path.basename(fileName, '.js');
    const normalizedVersion = version.toString();
    if (seenVersions.has(normalizedVersion)) {
      throw new MigrationError(
        `Duplicate migration version: ${normalizedVersion}`,
        'MIGRATION_DUPLICATE_VERSION',
        {
          migrationId: id
        }
      );
    }
    seenVersions.add(normalizedVersion);

    // Migration modules are immutable after being applied; checksum validation enforces this.
    const migration = require(filePath);
    if (!migration || typeof migration.up !== 'function') {
      throw new MigrationError(`Migration ${id} must export an up function`, 'MIGRATION_INVALID', {
        migrationId: id
      });
    }

    return {
      id,
      name: String(migration.name || id),
      checksum: sha256File(filePath),
      up: migration.up
    };
  });
}

function createMigrationRunner(options) {
  const pool = options?.pool;
  if (!pool || typeof pool.getConnection !== 'function') {
    throw new TypeError('createMigrationRunner requires a database pool');
  }

  const migrationsDir = path.resolve(
    options.migrationsDir || path.join(__dirname, '../../database/migrations')
  );
  const lockName = String(options.lockName || 'finia:schema-migrations').slice(0, 64);
  const lockTimeoutSeconds = Number.isInteger(options.lockTimeoutSeconds)
    ? options.lockTimeoutSeconds
    : 30;
  const logger = normalizeLogger(options.logger);

  if (lockTimeoutSeconds < 0 || lockTimeoutSeconds > 300) {
    throw new TypeError('lockTimeoutSeconds must be between 0 and 300');
  }

  async function run() {
    const migrations = discoverMigrations(migrationsDir);
    const connection = await pool.getConnection();
    let lockAcquired = false;
    const appliedNow = [];

    try {
      const [lockRows] = await connection.execute('SELECT GET_LOCK(?, ?) AS acquired', [
        lockName,
        lockTimeoutSeconds
      ]);
      lockAcquired = Number(lockRows[0]?.acquired) === 1;
      if (!lockAcquired) {
        throw new MigrationError(
          'Could not acquire the database migration lock',
          'MIGRATION_LOCK_TIMEOUT'
        );
      }

      await connection.query(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
          id VARCHAR(190) NOT NULL PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          checksum CHAR(64) NOT NULL,
          applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);

      const [appliedRows] = await connection.query(
        'SELECT id, checksum FROM schema_migrations ORDER BY id ASC'
      );
      const applied = new Map(appliedRows.map((row) => [String(row.id), String(row.checksum)]));
      const available = new Map(migrations.map((migration) => [migration.id, migration]));

      for (const [migrationId, storedChecksum] of applied) {
        const migration = available.get(migrationId);
        if (!migration) {
          throw new MigrationError(
            `Applied migration ${migrationId} is missing from the application`,
            'MIGRATION_FILE_MISSING',
            { migrationId }
          );
        }
        if (migration.checksum !== storedChecksum) {
          throw new MigrationError(
            `Applied migration ${migrationId} has changed`,
            'MIGRATION_CHECKSUM_MISMATCH',
            { migrationId }
          );
        }
      }

      for (const migration of migrations) {
        if (applied.has(migration.id)) continue;

        logger.info('Applying database migration', { migrationId: migration.id });
        try {
          await connection.beginTransaction();
          await migration.up({ connection, logger });
          await connection.execute(
            'INSERT INTO schema_migrations (id, name, checksum) VALUES (?, ?, ?)',
            [migration.id, migration.name, migration.checksum]
          );
          await connection.commit();
          appliedNow.push(migration.id);
        } catch (error) {
          try {
            await connection.rollback();
          } catch (rollbackError) {
            error.rollbackError = rollbackError;
          }
          throw new MigrationError(`Migration ${migration.id} failed`, 'MIGRATION_FAILED', {
            migrationId: migration.id,
            cause: error
          });
        }
      }

      return {
        applied: appliedNow,
        total: migrations.length
      };
    } finally {
      if (lockAcquired) {
        try {
          await connection.execute('SELECT RELEASE_LOCK(?) AS released', [lockName]);
        } catch (error) {
          logger.error('Failed to release database migration lock', { code: error.code });
        }
      }
      connection.release();
    }
  }

  return {
    discover: () => discoverMigrations(migrationsDir),
    run
  };
}

module.exports = {
  MigrationError,
  createMigrationRunner,
  discoverMigrations
};
