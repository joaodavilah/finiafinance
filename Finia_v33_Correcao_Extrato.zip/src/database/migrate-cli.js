'use strict';

const dotenv = require('dotenv');
const { loadConfig } = require('../config/env');
const logger = require('../lib/logger');
const {
  closeDatabasePool,
  createDatabasePool,
  createMigrationRunner,
  testDatabaseConnection
} = require('./index');

async function readAppliedMigrations(pool) {
  const [tableRows] = await pool.execute(
    `SELECT 1
     FROM information_schema.tables
     WHERE table_schema = DATABASE() AND table_name = 'schema_migrations'
     LIMIT 1`
  );
  if (!tableRows[0]) return [];

  const [rows] = await pool.execute(
    'SELECT id, name, checksum, applied_at FROM schema_migrations ORDER BY id ASC'
  );
  return rows;
}

async function migrationStatus(pool, runner) {
  const discovered = runner.discover();
  const appliedRows = await readAppliedMigrations(pool);
  const applied = new Map(appliedRows.map((row) => [row.id, row]));

  const migrations = discovered.map((migration) => {
    const stored = applied.get(migration.id);
    return {
      id: migration.id,
      name: migration.name,
      status: !stored
        ? 'pending'
        : stored.checksum === migration.checksum
          ? 'applied'
          : 'checksum-mismatch',
      appliedAt: stored?.applied_at || null
    };
  });
  const unknown = appliedRows
    .filter((row) => !discovered.some((migration) => migration.id === row.id))
    .map((row) => ({
      id: row.id,
      name: row.name,
      status: 'missing-file',
      appliedAt: row.applied_at
    }));

  return {
    migrations: [...migrations, ...unknown],
    healthy:
      !migrations.some((migration) => migration.status === 'checksum-mismatch') && !unknown.length
  };
}

async function main(argv = process.argv.slice(2)) {
  dotenv.config();
  const command = String(argv[0] || 'up').toLowerCase();
  if (!['up', 'status'].includes(command)) {
    const error = new Error('Use: node src/database/migrate-cli.js [up|status]');
    error.code = 'MIGRATION_COMMAND_INVALID';
    throw error;
  }

  const config = loadConfig(process.env);
  const pool = createDatabasePool(config.database);
  try {
    await testDatabaseConnection(pool);
    const runner = createMigrationRunner({ pool, logger });

    if (command === 'status') {
      const status = await migrationStatus(pool, runner);
      logger.info('Database migration status', status);
      if (!status.healthy) process.exitCode = 1;
      return status;
    }

    const result = await runner.run();
    logger.info('Database migrations completed', result);
    return result;
  } finally {
    await closeDatabasePool(pool);
  }
}

if (require.main === module) {
  main().catch((error) => {
    logger.error('Database migration command failed', {
      error,
      code: error.code || 'MIGRATION_COMMAND_FAILED',
      migrationId: error.migrationId || null
    });
    process.exitCode = 1;
  });
}

module.exports = {
  main,
  migrationStatus,
  readAppliedMigrations
};
