'use strict';

const mysql = require('mysql2/promise');

class DatabaseConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'DatabaseConfigError';
    this.code = 'DATABASE_CONFIG_INVALID';
  }
}

function requireString(value, name) {
  const normalized = String(value || '').trim();
  if (!normalized) {
    throw new DatabaseConfigError(`${name} is required`);
  }
  return normalized;
}

function integerOption(value, fallback, name, { min = 1, max = Number.MAX_SAFE_INTEGER } = {}) {
  const parsed = value === undefined || value === null || value === '' ? fallback : Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new DatabaseConfigError(`${name} must be an integer between ${min} and ${max}`);
  }
  return parsed;
}

function normalizeTls(config) {
  const tls = config.tls !== undefined ? config.tls : config.ssl;

  if (!tls) {
    if (config.requireTls) {
      throw new DatabaseConfigError('TLS is required but no TLS configuration was provided');
    }
    return undefined;
  }

  if (tls === true) {
    const rejectUnauthorized = config.rejectUnauthorized !== false;
    return {
      minVersion: 'TLSv1.2',
      rejectUnauthorized
    };
  }

  if (typeof tls !== 'object' || tls.enabled === false) {
    if (config.requireTls) {
      throw new DatabaseConfigError('TLS is required but disabled');
    }
    return undefined;
  }

  const rejectUnauthorized = tls.rejectUnauthorized !== false;
  const minVersion = tls.minVersion || 'TLSv1.2';
  if (!['TLSv1.2', 'TLSv1.3'].includes(minVersion)) {
    throw new DatabaseConfigError('TLS minVersion must be TLSv1.2 or TLSv1.3');
  }
  return {
    minVersion,
    rejectUnauthorized,
    ...(tls.ca ? { ca: tls.ca } : {}),
    ...(tls.cert ? { cert: tls.cert } : {}),
    ...(tls.key ? { key: tls.key } : {}),
    ...(tls.servername ? { servername: tls.servername } : {})
  };
}

function createDatabasePool(config, dependencies = {}) {
  if (!config || typeof config !== 'object') {
    throw new DatabaseConfigError('Database configuration must be injected');
  }

  const driver = dependencies.mysql || mysql;
  if (!driver || typeof driver.createPool !== 'function') {
    throw new DatabaseConfigError('A mysql2-compatible driver is required');
  }

  const database = requireString(config.database || config.name, 'database');
  const queueLimit = integerOption(config.queueLimit, 100, 'queueLimit', { min: 1, max: 10000 });
  const connectionLimit = integerOption(config.connectionLimit, 10, 'connectionLimit', {
    min: 1,
    max: 100
  });

  return driver.createPool({
    host: requireString(config.host, 'host'),
    port: integerOption(config.port, 3306, 'port', { min: 1, max: 65535 }),
    user: requireString(config.user, 'user'),
    password:
      config.password === undefined || config.password === null ? '' : String(config.password),
    database,
    waitForConnections: true,
    connectionLimit,
    queueLimit,
    connectTimeout: integerOption(config.connectTimeoutMs, 10000, 'connectTimeoutMs', {
      min: 1000,
      max: 120000
    }),
    enableKeepAlive: config.enableKeepAlive !== false,
    keepAliveInitialDelay: integerOption(
      config.keepAliveInitialDelayMs,
      0,
      'keepAliveInitialDelayMs',
      {
        min: 0,
        max: 120000
      }
    ),
    charset: config.charset || 'utf8mb4',
    timezone: config.timezone || 'Z',
    ssl: normalizeTls(config)
  });
}

async function testDatabaseConnection(pool) {
  if (!pool || typeof pool.getConnection !== 'function') {
    throw new TypeError('A database pool is required');
  }

  const connection = await pool.getConnection();
  try {
    await connection.ping();
    return true;
  } finally {
    connection.release();
  }
}

async function closeDatabasePool(pool) {
  if (pool && typeof pool.end === 'function') {
    await pool.end();
  }
}

module.exports = {
  DatabaseConfigError,
  closeDatabasePool,
  createDatabasePool,
  testDatabaseConnection
};
