'use strict';

const http = require('http');
const dotenv = require('dotenv');
const { loadConfig } = require('./config');
const {
  closeDatabasePool,
  createDatabasePool,
  createMigrationRunner,
  testDatabaseConnection
} = require('./database');
const { createReadiness } = require('./lib/readiness');
const defaultLogger = require('./lib/logger');
const { createApplication } = require('./app');

dotenv.config();

function listen(server, port) {
  return new Promise((resolve, reject) => {
    const onError = (error) => {
      server.off('listening', onListening);
      reject(error);
    };
    const onListening = () => {
      server.off('error', onError);
      resolve();
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port);
  });
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    if (!server.listening) return resolve();
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

async function start(options = {}) {
  const logger = options.logger || defaultLogger;
  const config = options.config || loadConfig(options.env || process.env);
  const readiness = options.readiness || createReadiness();
  const pool = options.pool || createDatabasePool(config.database);
  let server;
  let cleanupTimer;
  let databaseRetryTimer;
  let shuttingDown = false;
  let databaseInitializing = false;

  // Em hospedagem gerenciada, o processo HTTP deve abrir a porta primeiro.
  // Se MySQL ou migrations estiverem temporariamente indisponíveis, manter o
  // processo vivo evita 503 do proxy e permite diagnóstico pelos health checks.
  const initializeDatabase = async () => {
    if (databaseInitializing || shuttingDown) return false;
    databaseInitializing = true;

    try {
      await testDatabaseConnection(pool);
      readiness.set('database', true);

      const migrationRunner = createMigrationRunner({ pool, logger });
      const migrationResult = await migrationRunner.run();
      readiness.set('migrations', true);
      logger.info('database_migrations_ready', {
        appliedCount: migrationResult.applied.length,
        totalCount: migrationResult.total
      });
      return true;
    } catch (error) {
      readiness.set('database', false);
      readiness.set('migrations', false);
      logger.error('database_initialization_failed', {
        errorName: error?.name || 'Error',
        errorCode: error?.code || 'DATABASE_STARTUP_FAILED',
        message: error?.message || 'Falha ao inicializar banco de dados',
        migrationId: error?.migrationId || undefined
      });
      return false;
    } finally {
      databaseInitializing = false;
    }
  };

  try {
    const app = createApplication({ config, pool, readiness, logger });
    server = http.createServer(app);
    server.requestTimeout = 30_000;
    server.headersTimeout = 15_000;
    server.keepAliveTimeout = 5_000;
    server.maxHeadersCount = 100;

    await listen(server, config.port);
    logger.info('server_ready', {
      port: config.port,
      environment: config.nodeEnv
    });

    // Tenta inicializar o banco depois que a porta já está disponível.
    // Se falhar, tenta novamente sem derrubar a aplicação.
    void initializeDatabase();
    databaseRetryTimer = setInterval(() => {
      if (!readiness.snapshot().ready) void initializeDatabase();
    }, 30_000);
    databaseRetryTimer.unref();

    const sessionRepository = app.locals.finia.services.sessionRepository;
    const purgeExpiredSessions = async () => {
      if (!readiness.snapshot().ready) return;
      try {
        const deleted = await sessionRepository.deleteExpired();
        if (deleted > 0) logger.info('expired_sessions_removed', { count: deleted });
      } catch (error) {
        logger.error('expired_session_cleanup_failed', { error });
      }
    };
    cleanupTimer = setInterval(purgeExpiredSessions, 60 * 60 * 1000);
    cleanupTimer.unref();

    const shutdown = async (signal) => {
      if (shuttingDown) return;
      shuttingDown = true;
      readiness.set('database', false);
      readiness.set('migrations', false);
      if (cleanupTimer) clearInterval(cleanupTimer);
      if (databaseRetryTimer) clearInterval(databaseRetryTimer);
      logger.info('server_shutdown_started', { signal });

      const forceTimer = setTimeout(() => {
        server.closeAllConnections?.();
      }, 10_000);
      forceTimer.unref();

      try {
        await closeServer(server);
        await closeDatabasePool(pool);
        clearTimeout(forceTimer);
        logger.info('server_shutdown_complete');
      } catch (error) {
        logger.error('server_shutdown_failed', { error });
        process.exitCode = 1;
      }
    };

    if (options.registerSignalHandlers !== false) {
      process.once('SIGINT', () => void shutdown('SIGINT'));
      process.once('SIGTERM', () => void shutdown('SIGTERM'));
    }

    return Object.freeze({ app, config, pool, readiness, server, shutdown });
  } catch (error) {
    readiness.set('database', false);
    readiness.set('migrations', false);
    if (cleanupTimer) clearInterval(cleanupTimer);
    if (databaseRetryTimer) clearInterval(databaseRetryTimer);
    if (server) await closeServer(server).catch(() => {});
    await closeDatabasePool(pool).catch(() => {});
    throw error;
  }
}

module.exports = {
  closeServer,
  listen,
  start
};
