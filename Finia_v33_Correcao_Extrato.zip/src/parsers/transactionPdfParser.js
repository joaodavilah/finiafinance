'use strict';

const crypto = require('crypto');
const { parseSantanderStatement, isSantanderStatement } = require('./santanderStatementParser');
const path = require('path');
const { isValidCivilDate } = require('../utils/transactionDate');
const { clampTransactionLimit } = require('../utils/transactionLimits');
const { parseStatementMoney } = require('../utils/transactionMoney');
const {
  TransactionError,
  transactionBadRequest,
  transactionPayloadTooLarge,
  transactionTimeout
} = require('../utils/transactionErrors');

const DEFAULT_MAX_BYTES = 8 * 1024 * 1024;
const DEFAULT_MAX_PAGES = 50;
const DEFAULT_MAX_TEXT_LENGTH = 1_000_000;
const DEFAULT_MAX_TRANSACTIONS = 300;
const DEFAULT_TIMEOUT_MS = 10_000;

function validatePdfFile(file, options = {}) {
  const maxBytes = clampTransactionLimit(options.maxBytes, DEFAULT_MAX_BYTES);
  if (!file || !Buffer.isBuffer(file.buffer)) {
    throw transactionBadRequest('PDF_REQUIRED', 'Envie o arquivo PDF no campo statement');
  }
  if (file.buffer.length === 0) {
    throw transactionBadRequest('PDF_EMPTY', 'O arquivo PDF está vazio');
  }
  if (file.buffer.length > maxBytes) {
    throw transactionPayloadTooLarge('O PDF excede o limite permitido', { max_bytes: maxBytes });
  }

  const extension = path.extname(String(file.originalname || '')).toLowerCase();
  if (extension !== '.pdf') {
    throw transactionBadRequest('PDF_INVALID_EXTENSION', 'O arquivo deve usar a extensão .pdf');
  }
  if (String(file.mimetype || '').toLowerCase() !== 'application/pdf') {
    throw transactionBadRequest(
      'PDF_INVALID_MIME',
      'O tipo MIME do arquivo deve ser application/pdf'
    );
  }
  if (file.buffer.subarray(0, 5).toString('ascii') !== '%PDF-') {
    throw transactionBadRequest(
      'PDF_INVALID_SIGNATURE',
      'A assinatura do arquivo não corresponde a um PDF'
    );
  }
}

function createDeadline(timeoutMs) {
  return Date.now() + timeoutMs;
}

function withDeadline(promise, deadline) {
  const remaining = deadline - Date.now();
  if (remaining <= 0) return Promise.reject(transactionTimeout());

  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(transactionTimeout()), remaining);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function normalizePdfDescription(value) {
  return String(value || '')
    .replace(/E\s*xtrato_P\s*F[^\d]*(?:\d{2}\s*\/\s*){2}\d{4}/gi, '')
    .replace(/B\s*ALP[^\s]*/gi, '')
    .replace(/P\s*agina:\s*\d+\s*\/\s*\d+/gi, '')
    .replace(/\b\d{4,6}\b/g, '')
    .replace(/\s*-\s*$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

const BALANCE_TABLE_HEADER = /^Data[^\S\r\n]+Descri[cç][aã]o[^\S\r\n]+Valor[^\S\r\n]+Saldo[^\S\r\n]*$/im;
const FULL_DATE_ROW = /^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(.*))?$/;
const PAGE_MARKER = /^(?:\d+\/\d+|-- \d+ of \d+ --)$/;
const STATEMENT_AMOUNT = String.raw`(?:-\s*)?R\$\s*\d+(?:\.\d{3})*,\d{2}-?`;
const AMOUNT_AND_BALANCE = new RegExp(
  '\\s*(' + STATEMENT_AMOUNT + ')\\s+(' + STATEMENT_AMOUNT + ')$'
);

function parseBalanceTable(text, maxTransactions) {
  const items = new Map();
  let inTable = false;
  let pending = null;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.replace(/\s+/g, ' ').replace(/−/g, '-').trim();
    const isHeader = BALANCE_TABLE_HEADER.test(line);
    const isPageMarker = PAGE_MARKER.test(line);
    if (!line || (!inTable && !isHeader)) continue;

    const start = line.match(FULL_DATE_ROW);
    if (pending && (isHeader || isPageMarker || start)) {
      throw transactionBadRequest('INCOMPLETE_MOVEMENT', 'Um lançamento do extrato ficou sem valor ou saldo.');
    }
    if (isHeader || isPageMarker) {
      inTable = isHeader;
      continue;
    }
    if (start) {
      const date = [start[3], start[2], start[1]].join('-');
      if (!isValidCivilDate(date)) {
        throw transactionBadRequest('INVALID_MOVEMENT_DATE', 'O extrato contém uma data de lançamento inválida.');
      }
      pending = { date, descriptionParts: [] };
    }
    if (!pending) continue;

    const detail = start ? start[4] || '' : line;
    const amounts = detail.match(AMOUNT_AND_BALANCE);
    if (!amounts) {
      if (detail) pending.descriptionParts.push(detail);
      continue;
    }

    const description = [...pending.descriptionParts, detail.slice(0, amounts.index)].join(' ').trim();
    const cents = parseStatementMoney(amounts[1]);
    if (!description || cents === null) {
      throw transactionBadRequest('INVALID_MOVEMENT', 'Não foi possível ler a descrição ou o valor de um lançamento.');
    }
    const balance = amounts[2].replace(/\s+/g, '');
    const originId = crypto
      .createHash('sha256')
      .update(JSON.stringify(['pdf-balance-table', pending.date, description, cents, balance]))
      .digest('hex');
    items.set(originId, {
      tipo: cents < 0 ? 'saida' : 'entrada',
      descricao: description.slice(0, 150),
      descricao_original: description.slice(0, 1000),
      valor: Math.abs(cents) / 100,
      categoria: 'outros',
      data_lancamento: pending.date,
      parcelado: false,
      parcelas_total: null,
      recorrente: false,
      recorrencias_total: null,
      origem: 'pdf',
      origem_id: originId
    });
    pending = null;
    if (items.size > maxTransactions) {
      throw transactionPayloadTooLarge('O PDF contém lançamentos demais', {
        max_transactions: maxTransactions
      });
    }
  }

  if (pending) {
    throw transactionBadRequest('INCOMPLETE_MOVEMENT', 'Um lançamento do extrato ficou sem valor ou saldo.');
  }
  return [...items.values()];
}

function parsePdfTransactions(text, options = {}) {
  const maxTransactions = clampTransactionLimit(options.maxTransactions, DEFAULT_MAX_TRANSACTIONS);
  const currentYear = options.currentYear || new Date().getUTCFullYear();
  const normalizedText = String(text || '');
  if (isSantanderStatement(normalizedText)) return parseSantanderStatement(normalizedText, { maxTransactions, currentYear });
  if (BALANCE_TABLE_HEADER.test(normalizedText)
    && /^\d{2}\/\d{2}\/\d{4}(?:[^\S\r\n]|$)/m.test(normalizedText)) {
    return parseBalanceTable(normalizedText, maxTransactions);
  }
  const monthMatch = normalizedText.match(
    /(?:janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*\/\s*(\d{4})/i
  );
  const statementYear = monthMatch ? Number(monthMatch[1]) : currentYear;
  const movementStart = normalizedText.search(/Movi\s*m\s*enta[cç][aã]o/i);
  const balancesStart = normalizedText.search(/S\s*aldos\s+por\s+Pe/i);
  const source = normalizedText.slice(
    movementStart >= 0 ? movementStart : 0,
    balancesStart > movementStart ? balancesStart : undefined
  );
  const lines = source
    .split(/\r?\n/)
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean);

  const datePattern = /^(\d{2})\s*\/\s*(\d{2})(?:\s+|$)/;
  const valuePattern = /(?:R\$\s*)?-?\d{1,3}(?:\.\d{3})*,\d{2}-?|(?:R\$\s*)?-?\d+,\d{2}-?/g;
  const ignored =
    /^(--|pagina:|p\s*agina|ext\s*r\s*ato|e\s*xtrato|b\s*alp|m\s*aio\s*\/|janeiro\s*\/|fevereiro\s*\/|mar[çc]o\s*\/|abril\s*\/|junho\s*\/|julho\s*\/|agosto\s*\/|setembro\s*\/|outubro\s*\/|novembro\s*\/|dezembro\s*\/|s\s*aldos|prezado|central|ouvidoria|sac|loja:|dep[oó]sitos|sal[aá]\s*r\s*io|out\s*r\s*os|co\s*m\s*p\s*r\s*as|paga\s*m\s*entos|\*|se voc[eê])/i;
  const items = [];
  let currentDate = null;
  let descriptionParts = [];

  for (const originalLine of lines) {
    if (ignored.test(originalLine)) continue;

    let line = originalLine;
    const dateMatch = line.match(datePattern);
    if (dateMatch) {
      const candidate = `${statementYear}-${dateMatch[2]}-${dateMatch[1]}`;
      currentDate = isValidCivilDate(candidate) ? candidate : null;
      line = line.replace(datePattern, '').trim();
      descriptionParts = [];
    }
    if (!currentDate) continue;

    const values = [...line.matchAll(valuePattern)];
    if (!values.length) {
      const clean = normalizePdfDescription(line);
      if (clean && !/^\d+$/.test(clean)) descriptionParts.push(clean);
      continue;
    }

    const beforeValue = normalizePdfDescription(line.slice(0, values[0].index));
    const description = normalizePdfDescription(
      [...descriptionParts, beforeValue].filter(Boolean).join(' ')
    );
    descriptionParts = [];
    if (!description || description.length < 3) continue;

    const cents = parseStatementMoney(values[0][0]);
    if (cents === null || cents === 0) continue;

    const originId = crypto
      .createHash('sha256')
      .update(`${currentDate}\u0000${description}\u0000${cents}`)
      .digest('hex');
    items.push({
      tipo: cents < 0 ? 'saida' : 'entrada',
      descricao: description,
      descricao_original: description,
      valor: Math.abs(cents) / 100,
      categoria: 'outros',
      data_lancamento: currentDate,
      parcelado: false,
      parcelas_total: null,
      recorrente: false,
      recorrencias_total: null,
      origem: 'pdf',
      origem_id: originId
    });

    if (items.length > maxTransactions) {
      throw transactionPayloadTooLarge('O PDF contém lançamentos demais', {
        max_transactions: maxTransactions
      });
    }
  }

  const unique = new Map();
  for (const item of items) {
    if (!unique.has(item.origem_id)) unique.set(item.origem_id, item);
  }
  return [...unique.values()];
}

async function parsePdfFile(file, options = {}) {
  validatePdfFile(file, options);
  const timeoutMs = clampTransactionLimit(options.timeoutMs, DEFAULT_TIMEOUT_MS);
  const maxPages = clampTransactionLimit(options.maxPages, DEFAULT_MAX_PAGES);
  const maxTextLength = clampTransactionLimit(options.maxTextLength, DEFAULT_MAX_TEXT_LENGTH);
  const deadline = createDeadline(timeoutMs);
  const PDFParseClass = options.PDFParseClass || require('pdf-parse').PDFParse;
  const logger = options.logger;
  let parser = null;
  let primaryError = null;

  try {
    parser = new PDFParseClass({ data: file.buffer });
    const info = await withDeadline(parser.getInfo(), deadline);
    const totalPages = Number(info?.total || 0);
    if (!Number.isInteger(totalPages) || totalPages < 1) {
      throw transactionBadRequest('PDF_WITHOUT_PAGES', 'O PDF não contém páginas legíveis');
    }
    if (totalPages > maxPages) {
      throw transactionPayloadTooLarge('O PDF possui páginas demais', { max_pages: maxPages });
    }

    const parsed = await withDeadline(parser.getText({ first: maxPages }), deadline);
    const text = String(parsed?.text || '');
    if (!text.trim()) {
      throw transactionBadRequest('PDF_WITHOUT_TEXT', 'O PDF não contém texto extraível');
    }
    if (text.length > maxTextLength) {
      throw transactionPayloadTooLarge('O texto extraído do PDF excede o limite', {
        max_text_length: maxTextLength
      });
    }

    const items = parsePdfTransactions(text, options);
    return {
      items,
      errors: [],
      warnings: items.length
        ? []
        : [
            {
              code: 'no_transactions_found',
              message: 'Nenhum lançamento reconhecido; revise o extrato antes de continuar'
            }
          ],
      meta: {
        bytes: file.buffer.length,
        pages: totalPages,
        text_length: text.length
      }
    };
  } catch (error) {
    primaryError = error;
    if (error instanceof TransactionError) throw error;
    throw new TransactionError(
      422,
      'PDF_PARSE_FAILED',
      'Não foi possível interpretar o PDF enviado'
    );
  } finally {
    if (parser && typeof parser.destroy === 'function') {
      try {
        await parser.destroy();
      } catch (destroyError) {
        if (logger?.warn) {
          logger.warn('transaction_pdf_destroy_failed', {
            error: destroyError,
            afterParseFailure: Boolean(primaryError)
          });
        }
      }
    }
  }
}

module.exports = {
  parsePdfFile,
  parsePdfTransactions,
  validatePdfFile
};
