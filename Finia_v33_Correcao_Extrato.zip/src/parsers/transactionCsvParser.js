'use strict';

const crypto = require('crypto');
const { isValidCivilDate } = require('../utils/transactionDate');
const { clampTransactionLimit } = require('../utils/transactionLimits');
const { parseStatementMoney } = require('../utils/transactionMoney');
const { transactionBadRequest, transactionPayloadTooLarge } = require('../utils/transactionErrors');
const { MAX_BULK_ITEMS } = require('../validators/transactionValidator');

const DEFAULT_MAX_BYTES = 2 * 1024 * 1024;
const DEFAULT_MAX_FIELD_LENGTH = 2048;
const DEFAULT_MAX_COLUMNS = 32;

const HEADER_ALIASES = Object.freeze({
  data_lancamento: ['data_lancamento', 'data', 'date'],
  tipo: ['tipo', 'type', 'natureza'],
  descricao: ['descricao', 'description', 'historico', 'lancamento'],
  valor: ['valor', 'amount', 'quantia'],
  categoria: ['categoria', 'category'],
  parcelado: ['parcelado', 'installment'],
  parcelas_total: ['parcelas_total', 'parcelas', 'installments'],
  recorrente: ['recorrente', 'recurring'],
  recorrencias_total: ['recorrencias_total', 'recorrencias', 'repeticoes'],
  origem: ['origem', 'origin'],
  origem_id: ['origem_id', 'origin_id', 'external_id', 'id_externo']
});

const CATEGORY_ALIASES = Object.freeze({
  alimentacao: 'alimentacao',
  transporte: 'transporte',
  saude: 'saude',
  lazer: 'lazer',
  moradia: 'moradia',
  educacao: 'educacao',
  salario: 'salario',
  freelance: 'freelance',
  outros: 'outros'
});

function normalizeToken(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, '_')
    .replace(/[^a-z0-9_]/g, '');
}

function detectDelimiter(text) {
  const candidates = [',', ';', '\t'];
  const counts = new Map(candidates.map((candidate) => [candidate, 0]));
  let quoted = false;

  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        index++;
      } else {
        quoted = !quoted;
      }
      continue;
    }
    if (!quoted && (character === '\n' || character === '\r')) break;
    if (!quoted && counts.has(character)) counts.set(character, counts.get(character) + 1);
  }

  const ordered = [...counts.entries()].sort((left, right) => right[1] - left[1]);
  if (!ordered[0] || ordered[0][1] === 0) {
    throw transactionBadRequest(
      'CSV_DELIMITER_NOT_FOUND',
      'Não foi possível identificar o delimitador do CSV'
    );
  }
  return ordered[0][0];
}

function parseRecords(text, delimiter, limits) {
  const records = [];
  let row = [];
  let field = '';
  let quoted = false;
  let justClosedQuote = false;
  let line = 1;
  let recordLine = 1;

  function pushField() {
    if (field.length > limits.maxFieldLength) {
      throw transactionPayloadTooLarge('Um campo do CSV excede o limite permitido', {
        line,
        max_field_length: limits.maxFieldLength
      });
    }
    row.push(field);
    field = '';
    justClosedQuote = false;
    if (row.length > limits.maxColumns) {
      throw transactionBadRequest('CSV_TOO_MANY_COLUMNS', 'O CSV contém colunas demais', {
        line,
        max_columns: limits.maxColumns
      });
    }
  }

  function pushRow() {
    pushField();
    const isBlank = row.every((value) => value.trim() === '');
    if (!isBlank) records.push({ values: row, line: recordLine });
    row = [];
    recordLine = line + 1;
    if (records.length > limits.maxRows + 1) {
      throw transactionPayloadTooLarge('O CSV contém linhas demais', {
        max_rows: limits.maxRows
      });
    }
  }

  for (let index = 0; index < text.length; index++) {
    const character = text[index];

    if (quoted) {
      if (character === '"' && text[index + 1] === '"') {
        field += '"';
        index++;
      } else if (character === '"') {
        quoted = false;
        justClosedQuote = true;
      } else {
        field += character;
        if (character === '\n') line++;
      }
      continue;
    }

    if (justClosedQuote) {
      if (character === delimiter) {
        pushField();
        continue;
      }
      if (character === '\r' || character === '\n') {
        if (character === '\r' && text[index + 1] === '\n') index++;
        pushRow();
        line++;
        continue;
      }
      if ((character === ' ' || character === '\t') && character !== delimiter) continue;
      throw transactionBadRequest('CSV_INVALID_QUOTE', 'Há conteúdo inválido após aspas no CSV', {
        line
      });
    }

    if (character === '"') {
      if (field.length !== 0) {
        throw transactionBadRequest('CSV_INVALID_QUOTE', 'Aspas inválidas no CSV', { line });
      }
      quoted = true;
      continue;
    }
    if (character === delimiter) {
      pushField();
      continue;
    }
    if (character === '\r' || character === '\n') {
      if (character === '\r' && text[index + 1] === '\n') index++;
      pushRow();
      line++;
      continue;
    }

    field += character;
    if (field.length > limits.maxFieldLength) {
      throw transactionPayloadTooLarge('Um campo do CSV excede o limite permitido', {
        line,
        max_field_length: limits.maxFieldLength
      });
    }
  }

  if (quoted) {
    throw transactionBadRequest('CSV_UNCLOSED_QUOTE', 'O CSV termina com aspas não fechadas', {
      line
    });
  }
  if (field.length || row.length) pushRow();
  return records;
}

function buildHeaderIndex(headers) {
  const normalized = headers.map(normalizeToken);
  const duplicates = normalized.filter(
    (header, index) => header && normalized.indexOf(header) !== index
  );
  if (duplicates.length) {
    throw transactionBadRequest('CSV_DUPLICATE_HEADER', 'O CSV contém cabeçalhos duplicados', {
      headers: [...new Set(duplicates)]
    });
  }

  const indexes = {};
  for (const [field, aliases] of Object.entries(HEADER_ALIASES)) {
    const matches = normalized
      .map((header, index) => (aliases.includes(header) ? index : -1))
      .filter((index) => index >= 0);
    if (matches.length > 1) {
      throw transactionBadRequest(
        'CSV_AMBIGUOUS_HEADER',
        'O CSV contém mais de uma coluna para o mesmo campo',
        { field, headers: matches.map((index) => normalized[index]) }
      );
    }
    indexes[field] = matches[0] ?? -1;
  }
  const missing = ['data_lancamento', 'descricao', 'valor'].filter((field) => indexes[field] < 0);
  if (missing.length) {
    throw transactionBadRequest(
      'CSV_REQUIRED_HEADERS',
      'O CSV não contém todos os cabeçalhos obrigatórios',
      {
        missing
      }
    );
  }
  return indexes;
}

function csvDate(value) {
  const text = String(value || '').trim();
  if (isValidCivilDate(text)) return text;
  const match = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return text;
  const normalized = `${match[3]}-${match[2]}-${match[1]}`;
  return isValidCivilDate(normalized) ? normalized : text;
}

function csvType(value) {
  const normalized = normalizeToken(value);
  if (!normalized) return null;
  if (['entrada', 'credito', 'credit', 'receita'].includes(normalized)) return 'entrada';
  if (['saida', 'debito', 'debit', 'despesa'].includes(normalized)) return 'saida';
  return normalized;
}

function csvCategory(value) {
  const normalized = normalizeToken(value);
  const labels = require('../../public/transaction-catalog').labels;
  const match = Object.entries(labels).find(([, label]) => normalizeToken(label) === normalized);
  return normalized ? CATEGORY_ALIASES[normalized] || match?.[0] || normalized : 'outros';
}

function parseCsvTransactions(input, options = {}) {
  if (typeof input !== 'string' && !Buffer.isBuffer(input)) {
    throw transactionBadRequest('CSV_INVALID_BODY', 'Envie o conteúdo CSV como texto UTF-8');
  }

  const maxBytes = clampTransactionLimit(options.maxBytes, DEFAULT_MAX_BYTES);
  const maxRows = clampTransactionLimit(options.maxRows, MAX_BULK_ITEMS);
  const byteLength = Buffer.isBuffer(input) ? input.length : Buffer.byteLength(input, 'utf8');
  if (byteLength === 0) throw transactionBadRequest('CSV_EMPTY', 'O arquivo CSV está vazio');
  if (byteLength > maxBytes) {
    throw transactionPayloadTooLarge('O CSV excede o limite permitido', { max_bytes: maxBytes });
  }

  let text = Buffer.isBuffer(input) ? input.toString('utf8') : input;
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  if (text.includes('\u0000') || text.includes('\ufffd')) {
    throw transactionBadRequest(
      'CSV_INVALID_ENCODING',
      'O CSV deve estar codificado em UTF-8 válido'
    );
  }

  const limits = {
    maxRows,
    maxColumns: clampTransactionLimit(options.maxColumns, DEFAULT_MAX_COLUMNS),
    maxFieldLength: clampTransactionLimit(options.maxFieldLength, DEFAULT_MAX_FIELD_LENGTH)
  };
  const delimiter = options.delimiter || detectDelimiter(text);
  if (![',', ';', '\t'].includes(delimiter)) {
    throw transactionBadRequest('CSV_INVALID_DELIMITER', 'Delimitador CSV não permitido');
  }

  const records = parseRecords(text, delimiter, limits);
  if (records.length < 2) {
    throw transactionBadRequest('CSV_WITHOUT_DATA', 'O CSV não contém lançamentos');
  }

  const header = records[0];
  const indexes = buildHeaderIndex(header.values);
  const items = [];
  const errors = [];
  const warnings = [];

  for (const record of records.slice(1)) {
    const index = items.length;
    const get = (field) =>
      indexes[field] >= 0 ? String(record.values[indexes[field]] || '').trim() : '';
    if (record.values.length !== header.values.length) {
      errors.push({
        index,
        row: record.line,
        field: 'row',
        code: 'column_count_mismatch',
        message: `A linha possui ${record.values.length} colunas; eram esperadas ${header.values.length}`
      });
    }

    const parsedCents = parseStatementMoney(get('valor'));
    const explicitType = csvType(get('tipo'));
    const inferredType = parsedCents !== null && parsedCents < 0 ? 'saida' : 'entrada';
    if (explicitType && !['entrada', 'saida'].includes(explicitType)) {
      errors.push({
        index,
        row: record.line,
        field: 'tipo',
        code: 'invalid_type',
        message: 'Tipo não reconhecido no CSV'
      });
    }
    if (explicitType === 'entrada' && parsedCents !== null && parsedCents < 0) {
      errors.push({
        index,
        row: record.line,
        field: 'tipo',
        code: 'amount_type_conflict',
        message: 'Valor negativo conflita com o tipo entrada'
      });
    }

    const rawOriginId = get('origem_id');
    const deterministicOriginId = crypto
      .createHash('sha256')
      .update(record.values.join('\u001f'))
      .digest('hex');

    items.push({
      tipo: explicitType || inferredType,
      descricao: get('descricao'),
      valor: parsedCents === null ? get('valor') : Math.abs(parsedCents) / 100,
      categoria: csvCategory(get('categoria')),
      data_lancamento: csvDate(get('data_lancamento')),
      parcelado: get('parcelado') || false,
      parcelas_total: get('parcelas_total') || null,
      recorrente: get('recorrente') || false,
      recorrencias_total: get('recorrencias_total') || null,
      origem: get('origem') || 'csv',
      origem_id: rawOriginId || deterministicOriginId
    });
  }

  const knownHeaders = new Set(Object.values(HEADER_ALIASES).flat());
  const ignoredHeaders = header.values
    .map(normalizeToken)
    .filter((value) => value && !knownHeaders.has(value));
  if (ignoredHeaders.length) {
    warnings.push({
      code: 'ignored_headers',
      message: 'Algumas colunas não reconhecidas foram ignoradas',
      headers: ignoredHeaders
    });
  }

  return {
    items,
    errors,
    warnings,
    meta: {
      delimiter: delimiter === '\t' ? 'tab' : delimiter,
      rows: items.length,
      bytes: byteLength
    }
  };
}

module.exports = {
  parseCsvTransactions
};
