'use strict';
const crypto = require('crypto');
const {isValidCivilDate}=require('../utils/transactionDate');
const {parseStatementMoney}=require('../utils/transactionMoney');
const {transactionPayloadTooLarge,transactionBadRequest}=require('../utils/transactionErrors');
const {repairText,normalize}=require('../../public/transaction-catalog');
const compact=text=>normalize(text).replace(/\s/g,'');
function isSantanderStatement(text){return compact(text).includes('EXTRATOCONSOLIDADOINTELIGENTE') && compact(text).includes('MOVIMENTACAO');}
function parseSantanderStatement(text,{maxTransactions=300,currentYear=new Date().getUTCFullYear()}={}) {
  const repaired=repairText(text);
  const year=Number(repaired.match(/(?:janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*\/\s*(\d{4})/i)?.[1]||currentYear);
  const lines=String(text).split(/\r?\n/).map(s=>s.replace(/\s+/g,' ').trim()).filter(Boolean);
  const start=lines.findIndex(s=>compact(s)==='MOVIMENTACAO');
  if(start<0)return [];
  const money=/(?:R\$\s*)?-?\d{1,3}(?:\.\d{3})*,\d{2}-?|(?:R\$\s*)?-?\d+,\d{2}-?/g;
  const operation=/^(?:DEBITO|PIX|APLICACAO|RESGATE|IOF|REMUNERACAO|RECARGA|LIQUIDODEVENCIMENTO|PAGAMENTOCARTAO|PAGAMENTODEBOLETO|TARIFA|TED|TRANSFERENCIA|SAQUE|ESTORNO)/;
  const items=[],occurrences=new Map();let date=null,pending=null;
  function flush(){
    if(!pending)return;
    if(pending.cents==null)throw transactionBadRequest('INCOMPLETE_MOVEMENT','Um lançamento do extrato ficou sem valor. Nenhum lançamento foi salvo; revise o arquivo.');
    const raw=pending.parts.join(' ').replace(/\s+/g,' ').trim().slice(0,1000);
    const identity=[pending.date,pending.document,raw,pending.cents].join('\0');
    const occurrence=(occurrences.get(identity)||0)+1;occurrences.set(identity,occurrence);
    if(pending.cents!==0)items.push({tipo:pending.cents<0?'saida':'entrada',descricao:repairText(raw).slice(0,150),descricao_original:raw,valor:Math.abs(pending.cents)/100,categoria:'outros',data_lancamento:pending.date,parcelado:false,parcelas_total:null,recorrente:false,recorrencias_total:null,origem:'pdf',origem_id:crypto.createHash('sha256').update(`santander-v2\0${identity}\0${occurrence}`).digest('hex')});
    pending=null;if(items.length>maxTransactions)throw transactionPayloadTooLarge('O PDF contém lançamentos demais',{max_transactions:maxTransactions});
  }
  for(const raw of lines.slice(start+1)){
    const key=compact(raw);
    if(/^(SALDOSPOR|SEVOCE|COMPRASCOMCARTAO|COMPROVANTESDEPAGAMENTO|INVESTIMENTOS|RESUMO)/.test(key))break;
    if(/^(EXTRATO|BALP|PAGINA|MOVIMENTACAO|DATADESCRI|DOCUMENTO|SALDOANTERIOR|SALDOFINAL|TOTAL)/.test(key)||/^--/.test(raw)||/^(?:janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s*\//i.test(repairText(raw)))continue;
    const clean=repairText(raw), booking=clean.match(/^(\d{2})\/(\d{2})\s+/);
    const content=booking?clean.slice(booking[0].length):clean;
    const isOperation=operation.test(compact(content));
    if(isOperation){
      flush();
      if(booking){const candidate=`${year}-${booking[2]}-${booking[1]}`;date=isValidCivilDate(candidate)?candidate:null;}
      if(!date)throw transactionBadRequest('INVALID_MOVEMENT_DATE','Não foi possível identificar a data contábil de uma movimentação.');
      pending={date,document:'',cents:null,parts:[]};
    }
    if(!pending)continue;
    const values=[...clean.matchAll(money)];
    if(values.length){
      if(pending.cents!==null)throw transactionBadRequest('AMBIGUOUS_MOVEMENT','A leitura encontrou valores ambíguos. Revise o arquivo antes de importar.');
      pending.cents=parseStatementMoney(values[0][0]);
      let before=raw.slice(0,raw.search(/(?:R\$\s*)?-?\d[\d.]*,\d{2}/)).trim();
      if(isOperation&&booking)before=before.replace(/^\d{2}\s*\/\s*\d{2}\s*/,'');
      pending.document=before.match(/(?:^|\s)(\d{4,8}|-)$/)?.[1]||'';
      before=before.replace(/(?:^|\s)(\d{4,8}|-)$/,'').trim();
      if(before)pending.parts.push(before);
    }else if(!/^PERIODO/.test(key)){
      pending.parts.push(isOperation&&booking?raw.replace(/^\d{2}\s*\/\s*\d{2}\s*/,''):raw);
    }
  }
  flush();return items;
}
module.exports={parseSantanderStatement,isSantanderStatement};
