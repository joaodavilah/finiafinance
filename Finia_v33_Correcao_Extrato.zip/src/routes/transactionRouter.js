'use strict';

const express = require('express');
const multer = require('multer');
const { asyncHandler } = require('../lib/asyncHandler');
const defaultLogger = require('../lib/logger');
const { parseCsvTransactions } = require('../parsers/transactionCsvParser');
const { parsePdfFile } = require('../parsers/transactionPdfParser');
const { createTransactionRepository } = require('../repositories/transactionRepository');
const { createTransactionService } = require('../services/transactionService');
const { clampTransactionLimit } = require('../utils/transactionLimits');
const {
  TransactionError,
  transactionBadRequest,
  transactionPayloadTooLarge
} = require('../utils/transactionErrors');

const PDF_MAX_BYTES = 8 * 1024 * 1024;
const CSV_MAX_BYTES = 2 * 1024 * 1024;
const PDF_MAX_PAGES = 50;
const PDF_MAX_TEXT_LENGTH = 1_000_000;
const PDF_MAX_TRANSACTIONS = 300;
const PDF_MAX_TIMEOUT_MS = 10_000;

function requireBodyFields(body, allowedFields, message) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw transactionBadRequest('INVALID_REQUEST_BODY', message);
  }
  const unexpected = Object.keys(body).filter((field) => !allowedFields.includes(field));
  if (unexpected.length) {
    throw transactionBadRequest('INVALID_REQUEST_BODY', message, { fields: unexpected });
  }
  return body;
}

function createTransactionRouter(options) {
  const {
    pool,
    authenticate,
    requireCsrf,
    logger = defaultLogger,
    PDFParseClass,
    limits = {}
  } = options || {};

  if (!pool) throw new TypeError('createTransactionRouter requires pool');
  if (typeof authenticate !== 'function') {
    throw new TypeError('createTransactionRouter requires authenticate middleware');
  }
  if (typeof requireCsrf !== 'function') {
    throw new TypeError(
      'createTransactionRouter requires requireCsrf middleware for mutation routes'
    );
  }

  const repository = createTransactionRepository(pool);
  const service = createTransactionService(repository);
  const router = express.Router();
  const mutations = [authenticate, requireCsrf];
  const pdfMaxBytes = clampTransactionLimit(limits.pdfMaxBytes, PDF_MAX_BYTES);
  const csvMaxBytes = clampTransactionLimit(limits.csvMaxBytes, CSV_MAX_BYTES);
  const pdfMaxPages = clampTransactionLimit(limits.pdfMaxPages, PDF_MAX_PAGES);
  const pdfMaxTextLength = clampTransactionLimit(limits.pdfMaxTextLength, PDF_MAX_TEXT_LENGTH);
  const maxImportItems = clampTransactionLimit(limits.maxImportItems, PDF_MAX_TRANSACTIONS);
  const pdfTimeoutMs = clampTransactionLimit(limits.pdfTimeoutMs, PDF_MAX_TIMEOUT_MS);
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: pdfMaxBytes,
      files: 1,
      fields: 0
    }
  });
  const parseCsvBody = express.text({
    type: ['text/csv', 'text/plain'],
    limit: csvMaxBytes
  });

  router.get(
    '/lancamentos',
    authenticate,
    asyncHandler(async (req, res) => {
      res.json(await service.list(req.user?.id, req.query));
    })
  );

  router.post(
    '/lancamentos/import/preview',
    ...mutations,
    asyncHandler(async (req, res) => {
      const body = requireBodyFields(
        req.body,
        ['items', 'origem'],
        'Envie items e, opcionalmente, origem'
      );
      const preview = await service.previewImport(req.user?.id, body.items, {
        defaultOrigin: body.origem || 'import'
      });
      res.json(preview);
    })
  );

  router.post(
    '/lancamentos/import',
    ...mutations,
    asyncHandler(async (req, res) => {
      const result = await service.importBulk(req.user?.id, req.body, req.get('Idempotency-Key'));
      res.status(result.replayed ? 200 : 201).json(result);
    })
  );

  router.post(
    '/lancamentos/import/csv/preview',
    ...mutations,
    parseCsvBody,
    asyncHandler(async (req, res) => {
      const csv =
        typeof req.body === 'string'
          ? req.body
          : requireBodyFields(req.body, ['csv'], 'Envie somente o campo csv').csv;
      const parsed = parseCsvTransactions(csv, {
        maxBytes: csvMaxBytes,
        maxRows: maxImportItems
      });
      const preview = await service.previewImport(req.user?.id, parsed.items, {
        defaultOrigin: 'csv',
        preErrors: parsed.errors,
        warnings: parsed.warnings
      });
      res.json({
        ...preview,
        transactions: preview.items,
        parser: parsed.meta
      });
    })
  );

  const pdfPreviewHandler = asyncHandler(async (req, res) => {
    const parsed = await parsePdfFile(req.file, {
      PDFParseClass,
      logger,
      maxBytes: pdfMaxBytes,
      maxPages: pdfMaxPages,
      maxTextLength: pdfMaxTextLength,
      maxTransactions: maxImportItems,
      timeoutMs: pdfTimeoutMs
    });
    const preview = await service.previewImport(req.user?.id, parsed.items, {
      defaultOrigin: 'pdf',
      preErrors: parsed.errors,
      warnings: parsed.warnings
    });
    res.json({
      ...preview,
      transactions: preview.items,
      count: preview.items.length,
      parser: parsed.meta
    });
  });

  router.post('/import/pdf', ...mutations, upload.single('statement'), pdfPreviewHandler);
  router.post(
    '/lancamentos/import/pdf/preview',
    ...mutations,
    upload.single('statement'),
    pdfPreviewHandler
  );

  router.post(
    '/lancamentos',
    ...mutations,
    asyncHandler(async (req, res) => {
      res.status(201).json(await service.create(req.user?.id, req.body));
    })
  );

  router.put(
    '/lancamentos/:id',
    ...mutations,
    asyncHandler(async (req, res) => {
      res.json(await service.update(req.user?.id, req.params.id, req.body));
    })
  );

  router.delete(
    '/lancamentos/:id',
    ...mutations,
    asyncHandler(async (req, res) => {
      res.json(await service.remove(req.user?.id, req.params.id));
    })
  );

  router.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(
          transactionPayloadTooLarge('O PDF excede o limite permitido', {
            max_bytes: pdfMaxBytes
          })
        );
        return;
      }
      next(new TransactionError(400, 'INVALID_PDF_UPLOAD', 'Não foi possível receber o PDF'));
      return;
    }
    if (error?.type === 'entity.too.large') {
      next(transactionPayloadTooLarge('O conteúdo enviado excede o limite permitido'));
      return;
    }
    next(error);
  });

  return router;
}

module.exports = {
  createTransactionRouter
};
