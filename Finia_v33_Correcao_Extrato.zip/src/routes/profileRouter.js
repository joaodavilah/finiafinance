'use strict';

const express = require('express');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const { asyncHandler } = require('../lib/asyncHandler');
const { badRequest } = require('../lib/httpError');
const { MAX_AVATAR_BYTES } = require('../services/profileService');

function createProfileRouter({ service, authenticate, requireCsrf }) {
  if (
    !service?.getForUser ||
    typeof authenticate !== 'function' ||
    typeof requireCsrf !== 'function'
  ) {
    throw new TypeError('Dependencias obrigatorias ausentes ao criar profile router');
  }

  const router = express.Router();
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_AVATAR_BYTES, files: 1, fields: 0 }
  });
  const avatarLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    limit: 20,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: {
      erro: 'Muitas alteracoes de foto. Tente novamente mais tarde.',
      codigo: 'RATE_LIMITED'
    }
  });

  router.get(
    '/',
    authenticate,
    asyncHandler(async (req, res) => res.json(await service.getForUser(req.user.id)))
  );

  router.put(
    '/',
    authenticate,
    requireCsrf,
    asyncHandler(async (req, res) => {
      const fields = Object.keys(req.body || {});
      if (fields.length !== 1 || fields[0] !== 'nome_completo') {
        throw badRequest('INVALID_PROFILE', 'Envie somente o nome completo');
      }
      res.json(await service.updateName(req.user.id, req.body.nome_completo));
    })
  );

  router.get(
    '/avatar',
    authenticate,
    asyncHandler(async (req, res) => {
      const avatar = await service.getAvatar(req.user.id);
      res.setHeader('Cache-Control', 'private, no-store, max-age=0');
      res.setHeader('Content-Type', avatar.mimeType);
      res.setHeader('Content-Length', avatar.byteSize);
      res.send(avatar.data);
    })
  );

  router.put(
    '/avatar',
    avatarLimiter,
    authenticate,
    requireCsrf,
    upload.single('avatar'),
    asyncHandler(async (req, res) => res.json(await service.saveAvatar(req.user.id, req.file)))
  );

  router.delete(
    '/avatar',
    avatarLimiter,
    authenticate,
    requireCsrf,
    asyncHandler(async (req, res) => res.json(await service.removeAvatar(req.user.id)))
  );

  router.use((error, _req, _res, next) => {
    if (error instanceof multer.MulterError) {
      if (error.code === 'LIMIT_FILE_SIZE') {
        next(badRequest('INVALID_AVATAR', 'Escolha uma imagem de ate 1 MB'));
        return;
      }
      next(badRequest('INVALID_AVATAR', 'Nao foi possivel receber a imagem'));
      return;
    }
    next(error);
  });

  return router;
}

module.exports = { createProfileRouter };
