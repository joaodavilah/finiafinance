'use strict';
const express = require('express');
const { asyncHandler } = require('../lib/asyncHandler');
const { createWalletService } = require('../services/walletService');
function createWalletRouter({ pool, authenticate, requireCsrf }) {
  const r = express.Router(),
    s = createWalletService(pool);
  r.use(authenticate);
  const rules = require('../services/importRuleService').createImportRuleService(pool);
  r.get('/regras-importacao',asyncHandler(async(req,res)=>res.json(await rules.list(req.user.id))));
  r.put('/regras-importacao',requireCsrf,asyncHandler(async(req,res)=>res.json(await rules.save(req.user.id,req.body))));
  r.delete('/regras-importacao/:key',requireCsrf,asyncHandler(async(req,res)=>res.json(await rules.remove(req.user.id,req.params.key))));
  r.get(
    '/carteiras',
    asyncHandler(async (req, res) => res.json(await s.list(req.user.id)))
  );
  r.post(
    '/carteiras',
    requireCsrf,
    asyncHandler(async (req, res) => res.status(201).json(await s.create(req.user.id, req.body)))
  );
  r.get(
    '/categorias',
    asyncHandler(async (req, res) => res.json(await s.categories(req.user.id)))
  );
  r.post(
    '/categorias',
    requireCsrf,
    asyncHandler(async (req, res) => res.status(201).json(await s.category(req.user.id, req.body)))
  );
  r.delete('/carteiras/:id', requireCsrf,
    asyncHandler(async (req,res)=>res.json(await s.remove(req.user.id,req.params.id))));
  r.delete('/categorias/:id', requireCsrf,
    asyncHandler(async (req,res)=>res.json(await s.removeCategory(req.user.id,req.params.id))));
  r.patch('/carteiras/:id/fechamento',requireCsrf,asyncHandler(async(req,res)=>res.json(await s.setClosing(req.user.id,req.params.id,req.body))));
  return r;
}
module.exports = { createWalletRouter };
