'use strict';

const express = require('express');
const { AuthError } = require('../services/authService');
const { clearAuthCookies, setAuthCookies } = require('../middleware/authentication');

function asyncRoute(handler) {
  return function wrappedRoute(req, res, next) {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
}

function requestMetadata(req) {
  return {
    ip: req.ip,
    userAgent: req.get('user-agent') || ''
  };
}

function trustedOrigin(config) {
  const allowedOrigins = new Set(config.cors?.allowedOrigins || [config.appOrigin]);
  return function trustedOriginMiddleware(req, res, next) {
    const origin = req.get('origin');
    const fetchSite = req.get('sec-fetch-site');
    if ((origin && !allowedOrigins.has(origin)) || fetchSite === 'cross-site') {
      return res.status(403).json({
        erro: 'Requisicao nao autorizada',
        codigo: 'ORIGIN_NOT_ALLOWED',
        requestId: req.id
      });
    }
    next();
  };
}

function createAuthRouter({
  config,
  authService,
  authenticationMiddleware,
  csrfProtection,
  rateLimiters
} = {}) {
  if (
    !config?.cookies ||
    !authService ||
    typeof authenticationMiddleware !== 'function' ||
    typeof csrfProtection !== 'function' ||
    !rateLimiters
  ) {
    throw new TypeError('Dependencias obrigatorias ausentes ao criar auth router');
  }

  const router = express.Router();
  const originGuard = trustedOrigin(config);

  router.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    next();
  });

  router.post(
    '/register',
    originGuard,
    rateLimiters.register,
    asyncRoute(async (req, res) => {
      await authService.register({
        name: req.body?.nome_completo,
        email: req.body?.email,
        password: req.body?.senha
      });
      res.status(201).json({ ok: true });
    })
  );

  router.post(
    '/login',
    originGuard,
    rateLimiters.login,
    asyncRoute(async (req, res) => {
      const authenticated = await authService.login({
        email: req.body?.email,
        password: req.body?.senha,
        ...requestMetadata(req)
      });

      setAuthCookies(res, config, authenticated);
      res.setHeader('Cache-Control', 'no-store');
      res.json({ usuario: authenticated.user });
    })
  );

  router.post(
    '/forgot-password',
    originGuard,
    rateLimiters.forgotPassword,
    asyncRoute(async (req, res) => {
      await authService.requestPasswordReset(req.body?.email);
      res.status(202).json({
        ok: true,
        mensagem: 'Se o e-mail estiver cadastrado, as instrucoes serao enviadas.'
      });
    })
  );

  router.post(
    '/reset-password',
    originGuard,
    rateLimiters.resetPassword,
    asyncRoute(async (req, res) => {
      await authService.resetPassword({
        token: req.body?.token,
        newPassword: req.body?.novaSenha
      });
      clearAuthCookies(res, config);
      res.json({ ok: true });
    })
  );

  router.post(
    '/change-password',
    originGuard,
    rateLimiters.changePassword,
    authenticationMiddleware,
    csrfProtection,
    asyncRoute(async (req, res) => {
      await authService.changePassword({
        userId: req.user.id,
        currentPassword: req.body?.senha_atual,
        newPassword: req.body?.nova_senha
      });
      clearAuthCookies(res, config);
      res.status(204).end();
    })
  );

  router.get(
    '/session',
    rateLimiters.session,
    authenticationMiddleware,
    asyncRoute(async (req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.json({ usuario: req.user });
    })
  );

  router.post(
    '/logout',
    originGuard,
    rateLimiters.logout,
    authenticationMiddleware,
    csrfProtection,
    asyncRoute(async (req, res) => {
      await authService.logout({
        sessionId: req.authSession.id,
        userId: req.user.id
      });
      clearAuthCookies(res, config);
      res.status(204).end();
    })
  );

  router.post(
    '/logout-all',
    originGuard,
    rateLimiters.logout,
    authenticationMiddleware,
    csrfProtection,
    asyncRoute(async (req, res) => {
      await authService.logoutAll(req.user.id);
      clearAuthCookies(res, config);
      res.status(204).end();
    })
  );

  router.use((error, req, res, next) => {
    if (error instanceof AuthError) {
      return res.status(error.status).json({
        erro: error.publicMessage,
        codigo: error.code,
        requestId: req.id
      });
    }
    return next(error);
  });

  return router;
}

module.exports = {
  createAuthRouter
};
