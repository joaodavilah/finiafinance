'use strict';

const express = require('express');
const { asyncHandler } = require('../lib/asyncHandler');

function createSettingsRouter({ service, authenticate, requireCsrf }) {
  const router = express.Router();

  router.get(
    '/',
    authenticate,
    asyncHandler(async (req, res) => {
      res.json(await service.getForUser(req.user.id));
    })
  );

  router.put(
    '/',
    authenticate,
    requireCsrf,
    asyncHandler(async (req, res) => {
      res.json(await service.updateMonthlyLimit(req.user.id, req.body?.limite_gastos_mensal));
    })
  );

  return router;
}

module.exports = { createSettingsRouter };
