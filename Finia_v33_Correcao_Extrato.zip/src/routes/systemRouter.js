'use strict';

const express = require('express');

function createSystemRouter({ readiness }) {
  const router = express.Router();

  router.get('/health/live', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, service: 'finia-api' });
  });

  router.get('/health/ready', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    const snapshot = readiness.snapshot();
    res.status(snapshot.ready ? 200 : 503).json({
      ok: snapshot.ready,
      service: 'finia-api',
      checks: snapshot.checks
    });
  });

  return router;
}

module.exports = { createSystemRouter };
