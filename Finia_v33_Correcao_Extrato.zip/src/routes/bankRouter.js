'use strict';

const express = require('express');

function noop() {}

function createBankRouter(options) {
  const bankService = options?.bankService;
  const authenticate = options?.authenticate;
  const requireCsrf = options?.requireCsrf;
  const logger = {
    error:
      typeof options?.logger?.error === 'function'
        ? options.logger.error.bind(options.logger)
        : noop
  };

  if (!bankService || typeof bankService.getStatus !== 'function') {
    throw new TypeError('createBankRouter requires a bankService');
  }
  if (typeof authenticate !== 'function') {
    throw new TypeError('createBankRouter requires an authenticate middleware');
  }
  if (typeof requireCsrf !== 'function') {
    throw new TypeError('createBankRouter requires a requireCsrf middleware');
  }

  const router = express.Router();
  const asyncRoute = (handler) => (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
  };
  const userId = (req) => req.auth?.userId ?? req.user?.id;

  router.get(
    '/status',
    authenticate,
    asyncRoute(async (req, res) => {
      const result = await bankService.getStatus({ userId: userId(req) });
      res.json(result);
    })
  );

  router.post(
    '/connect-token',
    authenticate,
    requireCsrf,
    asyncRoute(async (req, res) => {
      const result = await bankService.createConnectToken({
        userId: userId(req),
        itemId: req.body?.itemId || null
      });
      res.json(result);
    })
  );

  router.post(
    '/connection',
    authenticate,
    requireCsrf,
    asyncRoute(async (req, res) => {
      const result = await bankService.associateConnection({
        userId: userId(req),
        itemId: req.body?.itemId
      });
      res.status(201).json(result);
    })
  );

  router.post(
    '/sync',
    authenticate,
    requireCsrf,
    asyncRoute(async (req, res) => {
      const result = await bankService.syncConnection({
        userId: userId(req),
        itemId: req.body?.itemId,
        idempotencyKey: req.get('Idempotency-Key'),
        dateFrom: req.body?.dateFrom,
        dateTo: req.body?.dateTo
      });
      res.json(result);
    })
  );

  router.delete(
    '/connection/:itemId',
    authenticate,
    requireCsrf,
    asyncRoute(async (req, res) => {
      const result = await bankService.disconnectConnection({
        userId: userId(req),
        itemId: req.params.itemId,
        purgeImportedTransactions: req.query.purgeImportedData === 'true'
      });
      res.json(result);
    })
  );

  router.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    const exposed = error?.expose === true;
    const statusCode = Number(error?.statusCode);
    const safeStatus =
      exposed && Number.isInteger(statusCode) && statusCode >= 400 && statusCode <= 599
        ? statusCode
        : 500;
    const internalCode = String(error?.code || 'BANK_OPERATION_FAILED').slice(0, 80);
    const code = exposed ? internalCode : 'BANK_OPERATION_FAILED';
    const message =
      exposed && error?.publicMessage
        ? error.publicMessage
        : 'Nao foi possivel concluir a operacao bancaria';

    logger.error('Bank API request failed', {
      code: internalCode,
      method: req.method,
      path: req.baseUrl + req.path,
      statusCode: safeStatus
    });
    return res.status(safeStatus).json({
      erro: message,
      codigo: code,
      requestId: req.id
    });
  });

  return router;
}

module.exports = {
  createBankRouter
};
