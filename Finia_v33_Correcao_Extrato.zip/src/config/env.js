'use strict';

const { URL } = require('url');

class ConfigError extends Error {
  constructor(message, variables = []) {
    super(message);
    this.name = 'ConfigError';
    this.code = 'INVALID_CONFIGURATION';
    this.variables = [...new Set(variables)];
  }
}

function own(env, name) {
  return Object.prototype.hasOwnProperty.call(env, name);
}

function readRequired(env, name, { allowEmpty = false } = {}) {
  if (!own(env, name)) {
    throw new ConfigError(`Variavel de ambiente obrigatoria ausente: ${name}`, [name]);
  }

  const value = String(env[name] ?? '').trim();
  if (!allowEmpty && !value) {
    throw new ConfigError(`Variavel de ambiente obrigatoria vazia: ${name}`, [name]);
  }

  return value;
}

function readOptional(env, name, fallback = '') {
  if (!own(env, name)) return fallback;
  return String(env[name] ?? '').trim();
}

function readBoolean(env, name, fallback) {
  if (!own(env, name) || String(env[name]).trim() === '') return fallback;
  const normalized = String(env[name]).trim().toLowerCase();
  if (normalized === 'true') return true;
  if (normalized === 'false') return false;
  throw new ConfigError(`${name} deve ser "true" ou "false"`, [name]);
}

function readInteger(env, name, fallback, { min, max } = {}) {
  const raw =
    own(env, name) && String(env[name]).trim() !== '' ? String(env[name]).trim() : String(fallback);
  const value = Number(raw);

  if (
    !Number.isSafeInteger(value) ||
    (min !== undefined && value < min) ||
    (max !== undefined && value > max)
  ) {
    throw new ConfigError(
      `${name} deve ser um inteiro entre ${min ?? '-infinito'} e ${max ?? 'infinito'}`,
      [name]
    );
  }

  return value;
}

function parseUrl(name, value, { requireHttps = false } = {}) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new ConfigError(`${name} deve ser uma URL absoluta valida`, [name]);
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new ConfigError(`${name} deve usar HTTP ou HTTPS`, [name]);
  }
  if (requireHttps && parsed.protocol !== 'https:') {
    throw new ConfigError(`${name} deve usar HTTPS em producao`, [name]);
  }
  if (parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new ConfigError(`${name} nao pode conter credenciais, query string ou fragmento`, [name]);
  }

  return parsed;
}

function validateJwtSecret(secret) {
  const byteLength = Buffer.byteLength(secret, 'utf8');
  const distinctCharacters = new Set(secret).size;
  const looksLikePlaceholder =
    /(?:change|changeme|replace|troque|example|placeholder|dev[-_ ]?secret|jwt[-_ ]?secret|your[-_ ]?secret)/i.test(
      secret
    );

  if (byteLength < 32 || distinctCharacters < 10 || looksLikePlaceholder) {
    throw new ConfigError(
      'JWT_SECRET deve ter pelo menos 32 bytes, boa diversidade e nao pode ser um placeholder',
      ['JWT_SECRET']
    );
  }
}

function validateDatabaseName(name) {
  if (name.length > 128 || /[\0\r\n]/.test(name)) {
    throw new ConfigError('DB_NAME invalido', ['DB_NAME']);
  }
}

function isLoopbackHost(host) {
  const normalized = host.toLowerCase();
  return (
    normalized === 'localhost' ||
    normalized === '127.0.0.1' ||
    normalized === '::1' ||
    normalized === '[::1]'
  );
}

function parseTrustProxy(env) {
  const raw = readOptional(env, 'TRUST_PROXY', 'false').toLowerCase();

  if (raw === 'false' || raw === '0') return false;
  if (raw === 'true') {
    throw new ConfigError(
      'TRUST_PROXY nao pode ser "true"; informe false ou a quantidade exata de proxies',
      ['TRUST_PROXY']
    );
  }

  const hops = Number(raw);
  if (!Number.isSafeInteger(hops) || hops < 1 || hops > 5) {
    throw new ConfigError('TRUST_PROXY deve ser false ou um inteiro entre 1 e 5', ['TRUST_PROXY']);
  }

  return hops;
}

function parseCorsAllowedOrigins(env, appOrigin, isProduction) {
  const raw = readOptional(env, 'CORS_ALLOWED_ORIGINS', appOrigin);
  if (raw.length > 2048) {
    throw new ConfigError('CORS_ALLOWED_ORIGINS excede o tamanho permitido', [
      'CORS_ALLOWED_ORIGINS'
    ]);
  }

  const candidates = raw
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);

  if (!candidates.length || candidates.length > 20) {
    throw new ConfigError('CORS_ALLOWED_ORIGINS deve conter entre 1 e 20 origens', [
      'CORS_ALLOWED_ORIGINS'
    ]);
  }

  const origins = candidates.map((value) => {
    if (value === '*' || value.toLowerCase() === 'null' || value.includes('*')) {
      throw new ConfigError('CORS_ALLOWED_ORIGINS deve conter apenas origens exatas', [
        'CORS_ALLOWED_ORIGINS'
      ]);
    }

    const parsed = parseUrl('CORS_ALLOWED_ORIGINS', value, { requireHttps: isProduction });
    if (parsed.pathname !== '/') {
      throw new ConfigError('CORS_ALLOWED_ORIGINS nao pode conter caminhos', [
        'CORS_ALLOWED_ORIGINS'
      ]);
    }
    if (isProduction && isLoopbackHost(parsed.hostname)) {
      throw new ConfigError('CORS_ALLOWED_ORIGINS nao pode usar loopback em producao', [
        'CORS_ALLOWED_ORIGINS'
      ]);
    }

    return parsed.origin;
  });

  return [...new Set(origins)];
}

function readBoundedList(env, name, fallback, { pattern, normalize = (value) => value, maxItems }) {
  const raw = readOptional(env, name, fallback.join(','));
  if (raw.length > 512) {
    throw new ConfigError(`${name} excede o tamanho permitido`, [name]);
  }

  const values = [
    ...new Set(
      raw
        .split(',')
        .map((value) => normalize(value.trim()))
        .filter(Boolean)
    )
  ];

  if (!values.length || values.length > maxItems || values.some((value) => !pattern.test(value))) {
    throw new ConfigError(`${name} contem valores invalidos`, [name]);
  }

  return values;
}

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.values(value).forEach(deepFreeze);
  return Object.freeze(value);
}

function loadConfig(env = process.env) {
  const nodeEnv = readRequired(env, 'NODE_ENV');
  if (!['development', 'test', 'production'].includes(nodeEnv)) {
    throw new ConfigError('NODE_ENV deve ser development, test ou production', ['NODE_ENV']);
  }

  const isProduction = nodeEnv === 'production';
  const appUrlObject = parseUrl('APP_URL', readRequired(env, 'APP_URL'), {
    requireHttps: isProduction
  });
  if (appUrlObject.pathname !== '/') {
    throw new ConfigError('APP_URL deve conter somente a origem, sem caminho', ['APP_URL']);
  }
  // Hostinger executa aplicações Node.js atrás de proxy reverso.
  // Quando TRUST_PROXY não for informado, use 1 em produção para que req.secure
  // reconheça corretamente X-Forwarded-Proto e evite redirecionamento HTTPS em loop.
  const trustProxy = own(env, 'TRUST_PROXY')
    ? parseTrustProxy(env)
    : isProduction
      ? 1
      : false;
  const corsAllowedOrigins = parseCorsAllowedOrigins(env, appUrlObject.origin, isProduction);
  const jwtSecret = readRequired(env, 'JWT_SECRET');
  validateJwtSecret(jwtSecret);

  const dbHost = readRequired(env, 'DB_HOST');
  const dbUser = readRequired(env, 'DB_USER');
  const dbPassword = readRequired(env, 'DB_PASSWORD', { allowEmpty: !isProduction });
  const dbName = readRequired(env, 'DB_NAME');
  const dbSsl = readBoolean(env, 'DB_SSL', false);
  const dbRejectUnauthorized = readBoolean(env, 'DB_SSL_REJECT_UNAUTHORIZED', true);
  validateDatabaseName(dbName);

  if (isProduction && dbUser.toLowerCase() === 'root') {
    throw new ConfigError('DB_USER nao pode ser root em producao', ['DB_USER']);
  }
  if (isProduction && !dbPassword) {
    throw new ConfigError('DB_PASSWORD nao pode ser vazia em producao', ['DB_PASSWORD']);
  }
  if (isProduction && !isLoopbackHost(dbHost) && !dbSsl) {
    throw new ConfigError('DB_SSL deve estar ativo para banco remoto em producao', [
      'DB_SSL',
      'DB_HOST'
    ]);
  }
  if (isProduction && dbSsl && !dbRejectUnauthorized) {
    throw new ConfigError('DB_SSL_REJECT_UNAUTHORIZED deve permanecer ativo em producao', [
      'DB_SSL_REJECT_UNAUTHORIZED'
    ]);
  }

  const smtpFields = ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'EMAIL_FROM'];
  const smtpRequested = smtpFields.some((name) => readOptional(env, name) !== '');
  let smtp;

  if (smtpRequested) {
    const smtpHost = readRequired(env, 'SMTP_HOST');
    const smtpPort = readInteger(env, 'SMTP_PORT', '', { min: 1, max: 65535 });
    const smtpUser = readOptional(env, 'SMTP_USER');
    const smtpPass = readOptional(env, 'SMTP_PASS');
    const emailFrom = readRequired(env, 'EMAIL_FROM');

    if (Boolean(smtpUser) !== Boolean(smtpPass)) {
      throw new ConfigError('SMTP_USER e SMTP_PASS devem ser informados juntos', [
        'SMTP_USER',
        'SMTP_PASS'
      ]);
    }
    if (
      !/^.+<[^<>\s@]+@[^<>\s@]+\.[^<>\s@]+>$/.test(emailFrom) &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailFrom)
    ) {
      throw new ConfigError('EMAIL_FROM deve conter um endereco de e-mail valido', ['EMAIL_FROM']);
    }

    const secure = readBoolean(env, 'SMTP_SECURE', smtpPort === 465);
    smtp = {
      enabled: true,
      host: smtpHost,
      port: smtpPort,
      secure,
      requireTls: isProduction && !secure,
      user: smtpUser || null,
      password: smtpPass || null,
      from: emailFrom
    };
  } else {
    smtp = { enabled: false };
  }

  const pluggyClientId = readOptional(env, 'PLUGGY_CLIENT_ID');
  const pluggyClientSecret = readOptional(env, 'PLUGGY_CLIENT_SECRET');
  if (Boolean(pluggyClientId) !== Boolean(pluggyClientSecret)) {
    throw new ConfigError('PLUGGY_CLIENT_ID e PLUGGY_CLIENT_SECRET devem ser informados juntos', [
      'PLUGGY_CLIENT_ID',
      'PLUGGY_CLIENT_SECRET'
    ]);
  }

  const pluggyUrl = parseUrl(
    'PLUGGY_API_URL',
    readOptional(env, 'PLUGGY_API_URL', 'https://api.pluggy.ai'),
    { requireHttps: isProduction }
  );

  if (
    isProduction &&
    (pluggyUrl.hostname !== 'api.pluggy.ai' || pluggyUrl.port || pluggyUrl.pathname !== '/')
  ) {
    throw new ConfigError('PLUGGY_API_URL deve apontar para https://api.pluggy.ai em producao', [
      'PLUGGY_API_URL'
    ]);
  }

  const pluggyIncludeSandbox = readBoolean(env, 'PLUGGY_INCLUDE_SANDBOX', false);
  if (isProduction && pluggyIncludeSandbox) {
    throw new ConfigError('PLUGGY_INCLUDE_SANDBOX deve permanecer desativado em producao', [
      'PLUGGY_INCLUDE_SANDBOX'
    ]);
  }

  const pluggyCountries = readBoundedList(env, 'PLUGGY_COUNTRIES', ['BR'], {
    pattern: /^[A-Z]{2}$/,
    normalize: (value) => value.toUpperCase(),
    maxItems: 10
  });
  const pluggyProducts = readBoundedList(env, 'PLUGGY_PRODUCTS', ['ACCOUNTS', 'TRANSACTIONS'], {
    pattern: /^[A-Z][A-Z0-9_]{0,31}$/,
    normalize: (value) => value.toUpperCase(),
    maxItems: 10
  });
  const pluggyConnectorTypes = readBoundedList(env, 'PLUGGY_CONNECTOR_TYPES', ['PERSONAL_BANK'], {
    pattern: /^[A-Z][A-Z0-9_]{0,31}$/,
    normalize: (value) => value.toUpperCase(),
    maxItems: 10
  });
  const pluggyLanguage = readOptional(env, 'PLUGGY_LANGUAGE', 'pt');
  if (!/^[a-z]{2}(?:-[A-Z]{2})?$/.test(pluggyLanguage)) {
    throw new ConfigError('PLUGGY_LANGUAGE deve ser um codigo de idioma valido', [
      'PLUGGY_LANGUAGE'
    ]);
  }

  const sessionTtlSeconds = readInteger(env, 'AUTH_SESSION_TTL_SECONDS', 8 * 60 * 60, {
    min: 5 * 60,
    max: 7 * 24 * 60 * 60
  });

  const resetTokenTtlMinutes = readInteger(env, 'RESET_TOKEN_TTL_MINUTES', 60, {
    min: 10,
    max: 120
  });

  const normalizedAppUrl = appUrlObject.toString().replace(/\/$/, '');
  const jwtIssuer = readOptional(env, 'JWT_ISSUER', 'finia-api');
  const jwtAudience = readOptional(env, 'JWT_AUDIENCE', 'finia-web');
  if (!jwtIssuer || jwtIssuer.length > 100 || !jwtAudience || jwtAudience.length > 100) {
    throw new ConfigError('JWT_ISSUER e JWT_AUDIENCE devem ter entre 1 e 100 caracteres', [
      'JWT_ISSUER',
      'JWT_AUDIENCE'
    ]);
  }

  return deepFreeze({
    nodeEnv,
    isProduction,
    port: readInteger(env, 'PORT', 3000, { min: 1, max: 65535 }),
    appUrl: normalizedAppUrl,
    appOrigin: appUrlObject.origin,
    trustProxy,
    cors: {
      allowedOrigins: corsAllowedOrigins,
      credentials: true,
      methods: ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Accept', 'Content-Type', 'Idempotency-Key', 'X-CSRF-Token', 'X-Request-Id'],
      exposedHeaders: ['RateLimit', 'RateLimit-Policy', 'X-Request-Id'],
      maxAgeSeconds: 600
    },
    jwt: {
      secret: jwtSecret,
      algorithm: 'HS256',
      issuer: jwtIssuer,
      audience: jwtAudience,
      sessionTtlSeconds
    },
    cookies: {
      authName: 'finia_session',
      csrfName: 'finia_csrf',
      secure: isProduction,
      sameSite: 'strict',
      path: '/',
      maxAgeMs: sessionTtlSeconds * 1000
    },
    auth: {
      bcryptCost: 12,
      passwordMinCharacters: 8,
      passwordMaxBytes: 72,
      resetTokenTtlMinutes
    },
    database: {
      host: dbHost,
      port: readInteger(env, 'DB_PORT', 3306, { min: 1, max: 65535 }),
      user: dbUser,
      password: dbPassword,
      name: dbName,
      ssl: dbSsl,
      rejectUnauthorized: dbRejectUnauthorized,
      requireTls: isProduction && !isLoopbackHost(dbHost),
      connectionLimit: readInteger(env, 'DB_CONNECTION_LIMIT', 10, { min: 1, max: 50 }),
      queueLimit: readInteger(env, 'DB_QUEUE_LIMIT', 100, { min: 1, max: 1000 }),
      connectTimeoutMs: readInteger(env, 'DB_CONNECT_TIMEOUT_MS', 10000, {
        min: 1000,
        max: 30000
      }),
      enableKeepAlive: readBoolean(env, 'DB_KEEP_ALIVE', true),
      keepAliveInitialDelayMs: readInteger(env, 'DB_KEEP_ALIVE_INITIAL_DELAY_MS', 0, {
        min: 0,
        max: 30000
      }),
      charset: 'utf8mb4',
      timezone: 'Z'
    },
    smtp,
    pluggy: {
      enabled: Boolean(pluggyClientId && pluggyClientSecret),
      baseUrl: pluggyUrl.toString().replace(/\/$/, ''),
      apiUrl: pluggyUrl.toString().replace(/\/$/, ''),
      clientId: pluggyClientId || null,
      clientSecret: pluggyClientSecret || null,
      timeoutMs: readInteger(env, 'PLUGGY_TIMEOUT_MS', 12000, { min: 1000, max: 30000 }),
      maxPages: readInteger(env, 'PLUGGY_MAX_PAGES', 50, { min: 1, max: 200 }),
      maxResponseBytes: readInteger(env, 'PLUGGY_MAX_RESPONSE_BYTES', 2 * 1024 * 1024, {
        min: 64 * 1024,
        max: 10 * 1024 * 1024
      }),
      apiKeyTtlMs: readInteger(env, 'PLUGGY_API_KEY_TTL_MS', 110 * 60 * 1000, {
        min: 60 * 1000,
        max: 115 * 60 * 1000
      }),
      allowInsecureForTests: nodeEnv === 'test' && pluggyUrl.protocol === 'http:',
      connectOptions: {
        includeSandbox: pluggyIncludeSandbox,
        countries: pluggyCountries,
        language: pluggyLanguage,
        products: pluggyProducts,
        connectorTypes: pluggyConnectorTypes
      }
    }
  });
}

module.exports = {
  ConfigError,
  loadConfig
};
