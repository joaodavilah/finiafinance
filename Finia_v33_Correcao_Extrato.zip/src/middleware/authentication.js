'use strict';

function cookieBaseOptions(config, httpOnly) {
  return {
    httpOnly,
    secure: config.cookies.secure,
    sameSite: config.cookies.sameSite,
    path: config.cookies.path
  };
}

function clearAuthCookies(res, config) {
  res.clearCookie(config.cookies.authName, cookieBaseOptions(config, true));
  res.clearCookie(config.cookies.csrfName, cookieBaseOptions(config, false));
}

function setAuthCookies(res, config, { token, csrfToken, expiresAtMs }) {
  const maxAge = Math.max(0, Math.min(config.cookies.maxAgeMs, expiresAtMs - Date.now()));
  res.cookie(config.cookies.authName, token, {
    ...cookieBaseOptions(config, true),
    maxAge
  });
  res.cookie(config.cookies.csrfName, csrfToken, {
    ...cookieBaseOptions(config, false),
    maxAge
  });
}

function createAuthenticationMiddleware({ config, authService } = {}) {
  if (!config?.cookies?.authName || !authService?.authenticate) {
    throw new TypeError('config e authService validos sao obrigatorios');
  }

  return async function authenticationMiddleware(req, res, next) {
    try {
      const token = req.cookies?.[config.cookies.authName];
      const authenticated = await authService.authenticate(token);
      req.user = authenticated.user;
      req.authSession = authenticated.session;
      next();
    } catch (error) {
      if (error?.status === 401) {
        clearAuthCookies(res, config);
        res.setHeader('Cache-Control', 'no-store');
        return res.status(401).json({
          erro: 'Sessao invalida ou expirada',
          codigo: 'UNAUTHENTICATED',
          requestId: req.id
        });
      }
      return next(error);
    }
  };
}

module.exports = {
  clearAuthCookies,
  cookieBaseOptions,
  createAuthenticationMiddleware,
  setAuthCookies
};
