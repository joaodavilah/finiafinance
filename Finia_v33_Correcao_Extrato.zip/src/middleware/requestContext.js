'use strict';

const crypto = require('crypto');

function requestContext(req, res, next) {
  const provided = req.get('x-request-id');
  req.id = provided && /^[A-Za-z0-9._:-]{1,100}$/.test(provided) ? provided : crypto.randomUUID();
  res.setHeader('X-Request-Id', req.id);
  next();
}

module.exports = { requestContext };
