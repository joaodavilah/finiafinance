'use strict';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function createCsrfProtection({ config, authService } = {}) {
  if (!config?.cookies?.csrfName || !config.appOrigin || !authService?.verifyCsrf) {
    throw new TypeError('config e authService validos sao obrigatorios');
  }

  return function csrfProtection(req, res, next) {
    if (SAFE_METHODS.has(req.method)) return next();

    const origin = req.get('origin');
    const allowedOrigins = config.cors?.allowedOrigins || [config.appOrigin];
    if (origin && !allowedOrigins.includes(origin)) {
      return res.status(403).json({
        erro: 'Requisicao nao autorizada',
        codigo: 'CSRF_REJECTED',
        requestId: req.id
      });
    }

    const cookieToken = req.cookies?.[config.cookies.csrfName];
    const headerToken = req.get('x-csrf-token');
    const valid = authService.verifyCsrf({
      session: req.authSession,
      cookieToken,
      headerToken
    });

    if (!valid) {
      return res.status(403).json({
        erro: 'Requisicao nao autorizada',
        codigo: 'CSRF_REJECTED',
        requestId: req.id
      });
    }

    next();
  };
}

module.exports = {
  createCsrfProtection
};
