'use strict';

const rateLimit = require('express-rate-limit');

function buildLimiter({ windowMs, limit, message, skipSuccessfulRequests = false }) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests,
    message: { erro: message, codigo: 'RATE_LIMITED' },
    handler(req, res, next, options) {
      res.status(options.statusCode).json({ ...options.message, requestId: req.id });
    }
  });
}

function createAuthRateLimiters() {
  return {
    register: buildLimiter({
      windowMs: 60 * 60 * 1000,
      limit: 5,
      message: 'Muitas tentativas. Tente novamente mais tarde.'
    }),
    login: buildLimiter({
      windowMs: 15 * 60 * 1000,
      limit: 45,
      skipSuccessfulRequests: true,
      message: 'Muitas tentativas. Tente novamente mais tarde.'
    }),
    forgotPassword: buildLimiter({
      windowMs: 60 * 60 * 1000,
      limit: 5,
      message: 'Se o e-mail estiver cadastrado, as instrucoes serao enviadas.'
    }),
    resetPassword: buildLimiter({
      windowMs: 60 * 60 * 1000,
      limit: 10,
      message: 'Muitas tentativas. Solicite um novo link mais tarde.'
    }),
    changePassword: buildLimiter({
      windowMs: 60 * 60 * 1000,
      limit: 10,
      message: 'Muitas tentativas. Tente novamente mais tarde.'
    }),
    session: buildLimiter({
      windowMs: 15 * 60 * 1000,
      limit: 120,
      message: 'Muitas requisicoes. Tente novamente em instantes.'
    }),
    logout: buildLimiter({
      windowMs: 15 * 60 * 1000,
      limit: 30,
      message: 'Muitas requisicoes. Tente novamente em instantes.'
    })
  };
}

module.exports = {
  createAuthRateLimiters
};
