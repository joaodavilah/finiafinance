'use strict';

const logger = require('../lib/logger');

function notFoundHandler(req, res) {
  res.status(404).json({
    erro: 'Rota da API nao encontrada',
    codigo: 'NOT_FOUND',
    requestId: req.id
  });
}

function errorHandler(error, req, res, _next) {
  let normalizedError = error;
  if (error?.type === 'entity.parse.failed') {
    normalizedError = {
      name: 'HttpError',
      status: 400,
      code: 'INVALID_JSON',
      message: 'Corpo JSON invalido',
      expose: true
    };
  } else if (error?.type === 'entity.too.large') {
    normalizedError = {
      name: 'HttpError',
      status: 413,
      code: 'PAYLOAD_TOO_LARGE',
      message: 'Conteudo enviado excede o limite permitido',
      expose: true
    };
  }

  const status = Number.isInteger(normalizedError.status) ? normalizedError.status : 500;
  const expose = normalizedError.expose === true || status < 500;

  logger.error('request_failed', {
    requestId: req.id,
    method: req.method,
    path: req.originalUrl,
    status,
    error: normalizedError
  });

  if (res.headersSent) return;

  res.status(status).json({
    erro: expose ? normalizedError.message : 'Erro interno no servidor',
    codigo: expose && normalizedError.code ? normalizedError.code : 'INTERNAL_ERROR',
    requestId: req.id,
    detalhes: expose ? normalizedError.details : undefined
  });
}

module.exports = { notFoundHandler, errorHandler };
