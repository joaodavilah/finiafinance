'use strict';

const helmet = require('helmet');

function createSecurityHeaders(config, options = {}) {
  if (!config || typeof config.isProduction !== 'boolean') {
    throw new TypeError('config valida e obrigatoria para criar os headers de seguranca');
  }

  const allowLegacyInlineStyles = options.allowLegacyInlineStyles !== false;
  const scriptSources = ["'self'", 'https://cdn.pluggy.ai'];
  const styleSources = ["'self'", 'https://fonts.googleapis.com'];

  if (allowLegacyInlineStyles) styleSources.push("'unsafe-inline'");

  const directives = {
    defaultSrc: ["'self'"],
    baseUri: ["'self'"],
    objectSrc: ["'none'"],
    frameAncestors: ["'none'"],
    formAction: ["'self'"],
    scriptSrc: scriptSources,
    scriptSrcAttr: ["'none'"],
    styleSrc: styleSources,
    fontSrc: ["'self'", 'https://fonts.gstatic.com'],
    imgSrc: ["'self'", 'data:', 'blob:'],
    connectSrc: ["'self'", 'https://api.pluggy.ai', 'https://*.pluggy.ai'],
    frameSrc: ['https://connect.pluggy.ai', 'https://*.pluggy.ai'],
    workerSrc: ["'self'", 'blob:'],
    manifestSrc: ["'self'"]
  };

  directives.upgradeInsecureRequests = config.isProduction ? [] : null;

  const helmetMiddleware = helmet({
    contentSecurityPolicy: { directives },
    crossOriginEmbedderPolicy: false,
    crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
    crossOriginResourcePolicy: { policy: 'same-site' },
    hsts: config.isProduction
      ? { maxAge: 31536000, includeSubDomains: true, preload: true }
      : false,
    referrerPolicy: { policy: 'no-referrer' },
    xFrameOptions: { action: 'deny' },
    xContentTypeOptions: true,
    permittedCrossDomainPolicies: { permittedPolicies: 'none' }
  });

  return function securityHeaders(req, res, next) {
    res.setHeader(
      'Permissions-Policy',
      'camera=(), microphone=(), geolocation=(), payment=(), usb=(), browsing-topics=()'
    );
    helmetMiddleware(req, res, next);
  };
}

function sensitiveResponseHeaders(req, res, next) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
}

module.exports = {
  createSecurityHeaders,
  sensitiveResponseHeaders
};
