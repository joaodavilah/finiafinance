'use strict';

const crypto = require('crypto');
const { withTransaction } = require('../database/transaction');

class BankRepositoryError extends Error {
  constructor(code, publicMessage, statusCode = 500, options = {}) {
    super(
      options.internalMessage || publicMessage,
      options.cause ? { cause: options.cause } : undefined
    );
    this.name = 'BankRepositoryError';
    this.code = code;
    this.publicMessage = publicMessage;
    this.statusCode = statusCode;
    this.status = statusCode;
    this.expose = true;
  }
}

function userIdValue(value) {
  const userId = Number(value);
  if (!Number.isSafeInteger(userId) || userId < 1)
    throw new TypeError('userId must be a positive integer');
  return userId;
}

function connectionIdValue(value) {
  const connectionId = Number(value);
  if (!Number.isSafeInteger(connectionId) || connectionId < 1) {
    throw new TypeError('connectionId must be a positive integer');
  }
  return connectionId;
}

function requiredText(value, name, maxLength) {
  const normalized = String(value || '').trim();
  if (!normalized || normalized.length > maxLength) {
    throw new TypeError(`${name} is required and must have at most ${maxLength} characters`);
  }
  return normalized;
}

function errorCode(value) {
  return String(value || 'BANK_SYNC_FAILED')
    .replace(/[^A-Z0-9_-]/gi, '_')
    .slice(0, 80);
}

function createBankRepository(options) {
  const pool = options?.pool;
  if (!pool || typeof pool.execute !== 'function' || typeof pool.getConnection !== 'function') {
    throw new TypeError('createBankRepository requires a database pool');
  }

  const randomUUID = options.randomUUID || crypto.randomUUID;

  async function listConnections(userId) {
    const [rows] = await pool.execute(
      `SELECT id, item_id, client_user_id, connector_name, status, sync_status,
              sync_lock_expira, ultima_sincronizacao, sync_iniciada_em,
              sync_erro_codigo, data_criacao, updated_at
       FROM conexoes_bancarias
       WHERE usuario_id = ?
       ORDER BY data_criacao DESC`,
      [userIdValue(userId)]
    );
    return rows;
  }

  async function getOwnedConnection(userId, itemId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, usuario_id, item_id, client_user_id, connector_name, status,
              sync_status, sync_lock_token, sync_lock_expira, sync_cursor,
              ultima_sincronizacao, sync_iniciada_em, sync_erro_codigo
       FROM conexoes_bancarias
       WHERE usuario_id = ? AND item_id = ?
       LIMIT 1`,
      [userIdValue(userId), requiredText(itemId, 'itemId', 150)]
    );
    return rows[0] || null;
  }

  async function getConnectionByItem(itemId, executor = pool, forUpdate = false) {
    const [rows] = await executor.execute(
      `SELECT id, usuario_id, item_id, client_user_id, connector_name, status,
              sync_status, sync_lock_token, sync_lock_expira
       FROM conexoes_bancarias
       WHERE item_id = ?
       LIMIT 1${forUpdate ? ' FOR UPDATE' : ''}`,
      [requiredText(itemId, 'itemId', 150)]
    );
    return rows[0] || null;
  }

  async function associateVerifiedItem(input) {
    const userId = userIdValue(input.userId);
    const itemId = requiredText(input.itemId, 'itemId', 150);
    const clientUserId = requiredText(input.clientUserId, 'clientUserId', 150);
    const connectorName = input.connectorName
      ? String(input.connectorName).trim().slice(0, 150)
      : null;

    try {
      return await withTransaction(pool, async (connection) => {
        const existing = await getConnectionByItem(itemId, connection, true);
        if (existing && Number(existing.usuario_id) !== userId) {
          throw new BankRepositoryError(
            'BANK_ITEM_ALREADY_LINKED',
            'Esta conexao bancaria ja pertence a outro usuario',
            409
          );
        }

        if (existing) {
          await connection.execute(
            `UPDATE conexoes_bancarias
             SET client_user_id = ?, connector_name = ?, status = 'ativo',
                 revogada_em = NULL, sync_erro_codigo = NULL
             WHERE id = ? AND usuario_id = ?`,
            [clientUserId, connectorName, existing.id, userId]
          );
          return getOwnedConnection(userId, itemId, connection);
        }

        const [result] = await connection.execute(
          `INSERT INTO conexoes_bancarias (
            usuario_id, item_id, client_user_id, connector_name, status, sync_status
          ) VALUES (?, ?, ?, ?, 'ativo', 'idle')`,
          [userId, itemId, clientUserId, connectorName]
        );
        const [rows] = await connection.execute(
          `SELECT id, usuario_id, item_id, client_user_id, connector_name, status,
                  sync_status, sync_lock_token, sync_lock_expira, sync_cursor,
                  ultima_sincronizacao, sync_iniciada_em, sync_erro_codigo
           FROM conexoes_bancarias WHERE id = ? LIMIT 1`,
          [result.insertId]
        );
        return rows[0];
      });
    } catch (error) {
      if (error instanceof BankRepositoryError) throw error;
      if (error.code === 'ER_DUP_ENTRY') {
        const existing = await getConnectionByItem(itemId);
        if (existing && Number(existing.usuario_id) !== userId) {
          throw new BankRepositoryError(
            'BANK_ITEM_ALREADY_LINKED',
            'Esta conexao bancaria ja pertence a outro usuario',
            409,
            { cause: error }
          );
        }
      }
      throw error;
    }
  }

  async function claimSync(input) {
    const userId = userIdValue(input.userId);
    const itemId = requiredText(input.itemId, 'itemId', 150);
    const lockToken = requiredText(input.lockToken, 'lockToken', 36);
    const leaseSeconds = Number(input.leaseSeconds || 180);
    if (!Number.isInteger(leaseSeconds) || leaseSeconds < 30 || leaseSeconds > 3600) {
      throw new TypeError('leaseSeconds must be between 30 and 3600');
    }

    const [result] = await pool.execute(
      `UPDATE conexoes_bancarias
       SET sync_lock_token = ?,
           sync_lock_expira = DATE_ADD(NOW(3), INTERVAL ? SECOND),
           sync_status = 'running',
           sync_iniciada_em = NOW(3),
           sync_erro_codigo = NULL
       WHERE usuario_id = ? AND item_id = ? AND status = 'ativo'
         AND (sync_lock_token IS NULL OR sync_lock_expira IS NULL OR sync_lock_expira <= NOW(3))`,
      [lockToken, leaseSeconds, userId, itemId]
    );

    if (result.affectedRows) return getOwnedConnection(userId, itemId);

    const existing = await getOwnedConnection(userId, itemId);
    if (!existing) {
      throw new BankRepositoryError(
        'BANK_CONNECTION_NOT_FOUND',
        'Conexao bancaria nao encontrada',
        404
      );
    }
    if (existing.status !== 'ativo') {
      throw new BankRepositoryError(
        'BANK_CONNECTION_INACTIVE',
        'A conexao bancaria nao esta ativa',
        409
      );
    }
    throw new BankRepositoryError(
      'BANK_SYNC_ALREADY_RUNNING',
      'Esta conexao bancaria ja esta sendo sincronizada',
      409
    );
  }

  async function heartbeatSync(input) {
    const leaseSeconds = Number(input.leaseSeconds || 180);
    const [result] = await pool.execute(
      `UPDATE conexoes_bancarias
       SET sync_lock_expira = DATE_ADD(NOW(3), INTERVAL ? SECOND)
       WHERE id = ? AND usuario_id = ? AND sync_lock_token = ? AND sync_status = 'running'`,
      [
        leaseSeconds,
        connectionIdValue(input.connectionId),
        userIdValue(input.userId),
        requiredText(input.lockToken, 'lockToken', 36)
      ]
    );
    if (!result.affectedRows) {
      throw new BankRepositoryError(
        'BANK_SYNC_LOCK_LOST',
        'A sincronizacao perdeu seu bloqueio exclusivo',
        409
      );
    }
    return true;
  }

  async function completeSync(input) {
    const [result] = await pool.execute(
      `UPDATE conexoes_bancarias
       SET sync_status = 'idle', sync_lock_token = NULL, sync_lock_expira = NULL,
           sync_cursor = ?, sync_erro_codigo = NULL, ultima_sincronizacao = NOW(3)
       WHERE id = ? AND usuario_id = ? AND sync_lock_token = ?`,
      [
        input.cursor ? String(input.cursor).slice(0, 65535) : null,
        connectionIdValue(input.connectionId),
        userIdValue(input.userId),
        requiredText(input.lockToken, 'lockToken', 36)
      ]
    );
    if (!result.affectedRows) {
      throw new BankRepositoryError(
        'BANK_SYNC_LOCK_LOST',
        'A sincronizacao perdeu seu bloqueio exclusivo',
        409
      );
    }
    return true;
  }

  async function failSync(input) {
    const [result] = await pool.execute(
      `UPDATE conexoes_bancarias
       SET sync_status = 'failed', sync_lock_token = NULL, sync_lock_expira = NULL,
           sync_erro_codigo = ?
       WHERE id = ? AND usuario_id = ? AND sync_lock_token = ?`,
      [
        errorCode(input.errorCode),
        connectionIdValue(input.connectionId),
        userIdValue(input.userId),
        requiredText(input.lockToken, 'lockToken', 36)
      ]
    );
    return Boolean(result.affectedRows);
  }

  async function getImportBatch(userId, idempotencyKey, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, usuario_id, conexao_bancaria_id, idempotency_key, request_hash,
              origem, status, processados, inseridos, atualizados, ignorados,
              ultimo_cursor, erro_codigo, criado_em, concluido_em
       FROM lotes_importacao
       WHERE usuario_id = ? AND idempotency_key = ?
       LIMIT 1`,
      [userIdValue(userId), requiredText(idempotencyKey, 'idempotencyKey', 128)]
    );
    return rows[0] || null;
  }

  async function beginImportBatch(input) {
    const userId = userIdValue(input.userId);
    const connectionId = connectionIdValue(input.connectionId);
    const idempotencyKey = requiredText(input.idempotencyKey, 'idempotencyKey', 128);
    const requestHash = requiredText(input.requestHash, 'requestHash', 64);

    return withTransaction(pool, async (connection) => {
      const [existingRows] = await connection.execute(
        `SELECT id, usuario_id, conexao_bancaria_id, idempotency_key, request_hash,
                origem, status, processados, inseridos, atualizados, ignorados,
                ultimo_cursor, erro_codigo, criado_em, concluido_em
         FROM lotes_importacao
         WHERE usuario_id = ? AND idempotency_key = ?
         LIMIT 1 FOR UPDATE`,
        [userId, idempotencyKey]
      );
      const existing = existingRows[0];
      if (existing) {
        if (
          existing.request_hash !== requestHash ||
          Number(existing.conexao_bancaria_id) !== connectionId
        ) {
          throw new BankRepositoryError(
            'BANK_IDEMPOTENCY_CONFLICT',
            'A chave de idempotencia ja foi usada para outra operacao',
            409
          );
        }
        if (existing.status === 'completed') return { ...existing, reused: true };

        await connection.execute(
          `UPDATE lotes_importacao
           SET status = 'processing', processados = 0, inseridos = 0,
               atualizados = 0, ignorados = 0, ultimo_cursor = NULL,
               erro_codigo = NULL, concluido_em = NULL
           WHERE id = ?`,
          [existing.id]
        );
        const resumed = await getImportBatch(userId, idempotencyKey, connection);
        return { ...resumed, reused: false, resumed: true };
      }

      const id = input.batchId || randomUUID();
      await connection.execute(
        `INSERT INTO lotes_importacao (
          id, usuario_id, conexao_bancaria_id, idempotency_key,
          request_hash, origem, status
        ) VALUES (?, ?, ?, ?, ?, 'pluggy', 'processing')`,
        [id, userId, connectionId, idempotencyKey, requestHash]
      );
      const created = await getImportBatch(userId, idempotencyKey, connection);
      return { ...created, reused: false, resumed: false };
    });
  }

  function validateImportedTransactions(transactions, connectionId) {
    if (!Array.isArray(transactions) || transactions.length > 500) {
      throw new TypeError('transactions must be an array with at most 500 items');
    }
    return transactions.map((transaction) => {
      if (Number(transaction.conexao_bancaria_id) !== connectionId) {
        throw new TypeError('transaction connection does not match the claimed connection');
      }
      return {
        tipo: ['entrada', 'saida'].includes(transaction.tipo) ? transaction.tipo : null,
        descricao: requiredText(transaction.descricao, 'transaction.descricao', 150),
        valor: requiredText(transaction.valor, 'transaction.valor', 30),
        categoria: requiredText(transaction.categoria, 'transaction.categoria', 100),
        data_lancamento: requiredText(
          transaction.data_lancamento,
          'transaction.data_lancamento',
          10
        ),
        origem: requiredText(transaction.origem, 'transaction.origem', 30),
        origem_id: requiredText(transaction.origem_id, 'transaction.origem_id', 150),
        origem_conta_id: transaction.origem_conta_id
          ? String(transaction.origem_conta_id).slice(0, 150)
          : null
      };
    });
  }

  async function upsertTransactionsPage(input) {
    const userId = userIdValue(input.userId);
    const connectionId = connectionIdValue(input.connectionId);
    const batchId = requiredText(input.batchId, 'batchId', 36);
    const skipped = Number(input.skipped || 0);
    if (!Number.isInteger(skipped) || skipped < 0 || skipped > 500) {
      throw new TypeError('skipped must be an integer between 0 and 500');
    }
    const transactions = validateImportedTransactions(input.transactions || [], connectionId);

    return withTransaction(pool, async (connection) => {
      const [batchRows] = await connection.execute(
        `SELECT id FROM lotes_importacao
         WHERE id = ? AND usuario_id = ? AND conexao_bancaria_id = ? AND status = 'processing'
         LIMIT 1 FOR UPDATE`,
        [batchId, userId, connectionId]
      );
      if (!batchRows[0]) {
        throw new BankRepositoryError(
          'BANK_IMPORT_BATCH_NOT_ACTIVE',
          'O lote de sincronizacao nao esta ativo',
          409
        );
      }

      let inserted = 0;
      let updated = 0;
      if (transactions.length) {
        const originIds = transactions.map((transaction) => transaction.origem_id);
        const originPlaceholders = originIds.map(() => '?').join(', ');
        const [existingRows] = await connection.execute(
          `SELECT origem_id FROM lancamentos
           WHERE usuario_id = ? AND origem = 'pluggy' AND origem_id IN (${originPlaceholders})
           FOR UPDATE`,
          [userId, ...originIds]
        );
        const existingOriginIds = new Set(existingRows.map((row) => row.origem_id));
        inserted = transactions.filter(
          (transaction) => !existingOriginIds.has(transaction.origem_id)
        ).length;
        updated = transactions.length - inserted;

        const placeholders = transactions
          .map(
            () =>
              '(?, ?, ?, ?, ?, ?, FALSE, NULL, NULL, NULL, FALSE, NULL, NULL, NULL, ?, ?, ?, ?, ?)'
          )
          .join(', ');
        const values = transactions.flatMap((transaction) => [
          userId,
          connectionId,
          batchId,
          transaction.tipo,
          transaction.descricao,
          transaction.valor,
          transaction.categoria,
          transaction.data_lancamento,
          transaction.origem,
          transaction.origem_id,
          transaction.origem_conta_id
        ]);

        await connection.execute(
          `INSERT INTO lancamentos (
            usuario_id, conexao_bancaria_id, lote_importacao_id, tipo, descricao, valor,
            parcelado, parcela_atual, parcelas_total, grupo_parcelamento,
            recorrente, recorrencia_atual, recorrencias_total, grupo_recorrencia,
            categoria, data_lancamento, origem, origem_id, origem_conta_id
          ) VALUES ${placeholders}
          ON DUPLICATE KEY UPDATE
            conexao_bancaria_id = VALUES(conexao_bancaria_id),
            lote_importacao_id = VALUES(lote_importacao_id),
            tipo = VALUES(tipo),
            descricao = VALUES(descricao),
            valor = VALUES(valor),
            categoria = VALUES(categoria),
            data_lancamento = VALUES(data_lancamento),
            origem_conta_id = VALUES(origem_conta_id),
            updated_at = CURRENT_TIMESTAMP(3)`,
          values
        );

        const [persistedRows] = await connection.execute(
          `SELECT id, origem_id FROM lancamentos
           WHERE usuario_id = ? AND origem = 'pluggy' AND origem_id IN (${originPlaceholders})`,
          [userId, ...originIds]
        );
        const persistedByOrigin = new Map(persistedRows.map((row) => [row.origem_id, row.id]));
        const itemPlaceholders = transactions.map(() => '(?, ?, ?, ?)').join(', ');
        const itemValues = transactions.flatMap((transaction) => [
          batchId,
          persistedByOrigin.get(transaction.origem_id),
          transaction.origem_id,
          existingOriginIds.has(transaction.origem_id) ? 'updated' : 'inserted'
        ]);
        await connection.execute(
          `INSERT INTO itens_lote_importacao (
            lote_importacao_id, lancamento_id, origem_id, resultado
          ) VALUES ${itemPlaceholders}
          ON DUPLICATE KEY UPDATE
            lancamento_id = VALUES(lancamento_id),
            resultado = VALUES(resultado),
            processado_em = CURRENT_TIMESTAMP(3)`,
          itemValues
        );
      }

      await connection.execute(
        `UPDATE lotes_importacao
         SET processados = processados + ?, inseridos = inseridos + ?,
             atualizados = atualizados + ?, ignorados = ignorados + ?,
             ultimo_cursor = ?
         WHERE id = ? AND usuario_id = ?`,
        [
          transactions.length + skipped,
          inserted,
          updated,
          skipped,
          input.cursor ? String(input.cursor).slice(0, 65535) : null,
          batchId,
          userId
        ]
      );

      return { processed: transactions.length + skipped, inserted, updated, skipped };
    });
  }

  async function completeImportBatch(userId, batchId) {
    const [result] = await pool.execute(
      `UPDATE lotes_importacao
       SET status = 'completed', erro_codigo = NULL, concluido_em = NOW(3)
       WHERE id = ? AND usuario_id = ? AND status = 'processing'`,
      [requiredText(batchId, 'batchId', 36), userIdValue(userId)]
    );
    if (!result.affectedRows) {
      throw new BankRepositoryError(
        'BANK_IMPORT_BATCH_NOT_ACTIVE',
        'O lote de sincronizacao nao esta ativo',
        409
      );
    }
    const [rows] = await pool.execute(
      `SELECT id, status, processados, inseridos, atualizados, ignorados,
              ultimo_cursor, criado_em, concluido_em
       FROM lotes_importacao WHERE id = ? AND usuario_id = ? LIMIT 1`,
      [batchId, userIdValue(userId)]
    );
    return rows[0];
  }

  async function failImportBatch(userId, batchId, failureCode) {
    const [result] = await pool.execute(
      `UPDATE lotes_importacao
       SET status = 'failed', erro_codigo = ?, concluido_em = NOW(3)
       WHERE id = ? AND usuario_id = ? AND status = 'processing'`,
      [errorCode(failureCode), requiredText(batchId, 'batchId', 36), userIdValue(userId)]
    );
    return Boolean(result.affectedRows);
  }

  async function markDisconnecting(userId, itemId) {
    return withTransaction(pool, async (connection) => {
      const bankConnection = await getConnectionByItem(itemId, connection, true);
      if (!bankConnection || Number(bankConnection.usuario_id) !== userIdValue(userId)) {
        throw new BankRepositoryError(
          'BANK_CONNECTION_NOT_FOUND',
          'Conexao bancaria nao encontrada',
          404
        );
      }
      if (
        bankConnection.sync_lock_token &&
        bankConnection.sync_lock_expira &&
        new Date(bankConnection.sync_lock_expira).getTime() > Date.now()
      ) {
        throw new BankRepositoryError(
          'BANK_SYNC_ALREADY_RUNNING',
          'Aguarde a sincronizacao terminar antes de desconectar',
          409
        );
      }
      await connection.execute(
        `UPDATE conexoes_bancarias
         SET status = 'revogando', sync_status = 'idle',
             sync_lock_token = NULL, sync_lock_expira = NULL
         WHERE id = ? AND usuario_id = ?`,
        [bankConnection.id, userIdValue(userId)]
      );
      return { ...bankConnection, status: 'revogando' };
    });
  }

  async function restoreAfterDisconnectFailure(userId, itemId, failureCode) {
    const [result] = await pool.execute(
      `UPDATE conexoes_bancarias
       SET status = 'ativo', sync_erro_codigo = ?
       WHERE usuario_id = ? AND item_id = ? AND status = 'revogando'`,
      [errorCode(failureCode), userIdValue(userId), requiredText(itemId, 'itemId', 150)]
    );
    return Boolean(result.affectedRows);
  }

  async function removeConnection(input) {
    const userId = userIdValue(input.userId);
    const itemId = requiredText(input.itemId, 'itemId', 150);
    return withTransaction(pool, async (connection) => {
      const bankConnection = await getConnectionByItem(itemId, connection, true);
      if (!bankConnection || Number(bankConnection.usuario_id) !== userId) return false;

      if (input.purgeImportedTransactions === true) {
        await connection.execute(
          `DELETE FROM lancamentos
           WHERE usuario_id = ? AND conexao_bancaria_id = ? AND origem = 'pluggy'`,
          [userId, bankConnection.id]
        );
      }
      await connection.execute('DELETE FROM conexoes_bancarias WHERE id = ? AND usuario_id = ?', [
        bankConnection.id,
        userId
      ]);
      return true;
    });
  }

  return {
    associateVerifiedItem,
    beginImportBatch,
    claimSync,
    completeImportBatch,
    completeSync,
    failImportBatch,
    failSync,
    getImportBatch,
    getOwnedConnection,
    heartbeatSync,
    listConnections,
    markDisconnecting,
    removeConnection,
    restoreAfterDisconnectFailure,
    upsertTransactionsPage
  };
}

module.exports = {
  BankRepositoryError,
  createBankRepository
};
