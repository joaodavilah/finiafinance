'use strict';

function assertPool(pool) {
  if (!pool || typeof pool.execute !== 'function' || typeof pool.getConnection !== 'function') {
    throw new TypeError('Um pool mysql2/promise valido e obrigatorio');
  }
}

function publicUser(row) {
  if (!row) return null;
  return {
    id: Number(row.id),
    nome_completo: row.nome_completo,
    email: row.email,
    plano: row.plano,
    limite_gastos_mensal: Number(row.limite_gastos_mensal || 0)
  };
}

function createUserRepository(pool) {
  assertPool(pool);

  async function findAuthByEmail(email, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, nome_completo, email, senha AS password_hash, plano, limite_gastos_mensal
       FROM usuarios
       WHERE email = ?
       LIMIT 1`,
      [email]
    );
    return rows[0] || null;
  }

  async function findAuthById(userId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, nome_completo, email, senha AS password_hash, plano, limite_gastos_mensal
       FROM usuarios
       WHERE id = ?
       LIMIT 1`,
      [userId]
    );
    return rows[0] || null;
  }

  async function findResetTargetByEmail(email, executor = pool) {
    const [rows] = await executor.execute(
      'SELECT id, email FROM usuarios WHERE email = ? LIMIT 1',
      [email]
    );
    return rows[0] || null;
  }

  async function findPublicById(userId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, nome_completo, email, plano, limite_gastos_mensal
       FROM usuarios
       WHERE id = ?
       LIMIT 1`,
      [userId]
    );
    return publicUser(rows[0]);
  }

  async function createUser({ name, email, passwordHash }, executor = pool) {
    const [result] = await executor.execute(
      'INSERT INTO usuarios (nome_completo, email, senha) VALUES (?, ?, ?)',
      [name, email, passwordHash]
    );
    return findPublicById(result.insertId, executor);
  }

  async function setResetToken({ userId, tokenHash, ttlMinutes }, executor = pool) {
    await executor.execute(
      `UPDATE usuarios
       SET reset_token = ?, reset_token_expira = DATE_ADD(UTC_TIMESTAMP(3), INTERVAL ? MINUTE)
       WHERE id = ?`,
      [tokenHash, ttlMinutes, userId]
    );
  }

  async function clearResetToken({ userId, tokenHash }, executor = pool) {
    const [result] = await executor.execute(
      `UPDATE usuarios
       SET reset_token = NULL, reset_token_expira = NULL
       WHERE id = ? AND reset_token = ?`,
      [userId, tokenHash]
    );
    return result.affectedRows > 0;
  }

  async function findValidResetTokenForUpdate(tokenHash, executor) {
    if (!executor || typeof executor.execute !== 'function') {
      throw new TypeError('Uma conexao transacional e obrigatoria');
    }
    const [rows] = await executor.execute(
      `SELECT id
       FROM usuarios
       WHERE reset_token = ? AND reset_token_expira > UTC_TIMESTAMP(3)
       LIMIT 1
       FOR UPDATE`,
      [tokenHash]
    );
    return rows[0] || null;
  }

  async function updatePasswordAndClearReset({ userId, passwordHash }, executor) {
    if (!executor || typeof executor.execute !== 'function') {
      throw new TypeError('Uma conexao transacional e obrigatoria');
    }
    const [result] = await executor.execute(
      `UPDATE usuarios
       SET senha = ?, reset_token = NULL, reset_token_expira = NULL
       WHERE id = ?`,
      [passwordHash, userId]
    );
    return result.affectedRows > 0;
  }

  async function updatePasswordForUser({ userId, passwordHash }, executor) {
    if (!executor || typeof executor.execute !== 'function') {
      throw new TypeError('Uma conexao transacional e obrigatoria');
    }
    const [result] = await executor.execute(
      `UPDATE usuarios
       SET senha = ?, reset_token = NULL, reset_token_expira = NULL,
           atualizado_em = UTC_TIMESTAMP(3)
       WHERE id = ?`,
      [passwordHash, userId]
    );
    return result.affectedRows > 0;
  }

  async function withTransaction(callback) {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      const value = await callback(connection);
      await connection.commit();
      return value;
    } catch (error) {
      try {
        await connection.rollback();
      } catch {
        // Mantem o erro original.
      }
      throw error;
    } finally {
      connection.release();
    }
  }

  return Object.freeze({
    publicUser,
    findAuthByEmail,
    findAuthById,
    findResetTargetByEmail,
    findPublicById,
    createUser,
    setResetToken,
    clearResetToken,
    findValidResetTokenForUpdate,
    updatePasswordAndClearReset,
    updatePasswordForUser,
    withTransaction
  });
}

module.exports = {
  createUserRepository,
  publicUser
};
