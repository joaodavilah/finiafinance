'use strict';

const { validateWallet, validateCategory, checkCreditDebt } = require('../services/walletService');
const { parseEncodedOriginId } = require('../utils/transactionImportIdentity');

const SELECT_COLUMNS = `
  id,
  usuario_id,
  carteira_id,
  DATE_FORMAT(data_compra, '%Y-%m-%d') AS data_compra,
  tipo,
  descricao,
  descricao_original,
  valor,
  categoria,
  DATE_FORMAT(data_lancamento, '%Y-%m-%d') AS data_lancamento,
  data_criacao,
  parcelado,
  parcela_atual,
  parcelas_total,
  grupo_parcelamento,
  recorrente,
  recorrencia_atual,
  recorrencias_total,
  grupo_recorrencia,
  origem,
  origem_id
`;

function mapTransactionRow(row) {
  return {
    id: Number(row.id),
    usuario_id: Number(row.usuario_id),
    carteira_id: row.carteira_id ? Number(row.carteira_id) : null,
    data_compra: row.data_compra,
    tipo: row.tipo,
    descricao: row.descricao,
    descricao_original: row.descricao_original || null,
    valor: Number(row.valor),
    categoria: row.categoria,
    data_lancamento: row.data_lancamento,
    data_criacao: row.data_criacao,
    parcelado: Boolean(row.parcelado),
    parcela_atual: row.parcela_atual === null ? null : Number(row.parcela_atual),
    parcelas_total: row.parcelas_total === null ? null : Number(row.parcelas_total),
    grupo_parcelamento: row.grupo_parcelamento,
    recorrente: Boolean(row.recorrente),
    recorrencia_atual: row.recorrencia_atual === null ? null : Number(row.recorrencia_atual),
    recorrencias_total: row.recorrencias_total === null ? null : Number(row.recorrencias_total),
    grupo_recorrencia: row.grupo_recorrencia,
    origem: row.origem,
    origem_id: row.origem_id
  };
}

function storedSourceDigest(originId) {
  const encoded = parseEncodedOriginId(originId);
  if (encoded) return encoded.sourceDigest;
  const series =
    typeof originId === 'string' ? originId.match(/^s\.([a-f0-9]{32})\.\d{1,3}$/) : null;
  return series ? series[1] : null;
}

function createTransactionRepository(pool) {
  if (!pool || typeof pool.execute !== 'function' || typeof pool.getConnection !== 'function') {
    throw new TypeError('createTransactionRepository requires a mysql2 promise pool');
  }

  async function withTransaction(callback) {
    const connection = await pool.getConnection();
    let committed = false;
    try {
      await connection.beginTransaction();
      const result = await callback(connection);
      await connection.commit();
      committed = true;
      return result;
    } catch (error) {
      if (!committed) {
        try {
          await connection.rollback();
        } catch (rollbackError) {
          error.rollbackError = rollbackError;
        }
      }
      throw error;
    } finally {
      connection.release();
    }
  }

  async function lockUser(connection, userId) {
    const [rows] = await connection.execute(
      'SELECT id FROM usuarios WHERE id = ? LIMIT 1 FOR UPDATE',
      [userId]
    );
    return Boolean(rows[0]);
  }

  async function listByUser({ userId, limit, filters, cursor }) {
    const where = ['usuario_id = ?'];
    const params = [userId];

    if (filters.tipo) {
      where.push('tipo = ?');
      params.push(filters.tipo);
    }
    if (filters.categoria) {
      where.push('categoria = ?');
      params.push(filters.categoria);
    }
    if (filters.data_inicio) {
      where.push('data_lancamento >= ?');
      params.push(filters.data_inicio);
    }
    if (filters.data_fim) {
      where.push('data_lancamento <= ?');
      params.push(filters.data_fim);
    }
    if (filters.origem) {
      where.push('origem = ?');
      params.push(filters.origem);
    }
    if (cursor) {
      where.push('(data_lancamento < ? OR (data_lancamento = ? AND id < ?))');
      params.push(cursor.data_lancamento, cursor.data_lancamento, cursor.id);
    }

    const safeLimit = Number(limit) + 1;
    const [rows] = await pool.execute(
      `SELECT ${SELECT_COLUMNS}
       FROM lancamentos
       WHERE ${where.join(' AND ')}
       ORDER BY data_lancamento DESC, id DESC
       LIMIT ${safeLimit}`,
      params
    );

    return rows.map(mapTransactionRow);
  }

  async function findById(userId, transactionId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT ${SELECT_COLUMNS}
       FROM lancamentos
       WHERE id = ? AND usuario_id = ?
       LIMIT 1`,
      [transactionId, userId]
    );
    return rows[0] ? mapTransactionRow(rows[0]) : null;
  }

  async function insertRows(connection, rows) {
    if (!rows.length) return { insertId: null, affectedRows: 0 };
    for (const row of rows) {
      row.carteira_id = await validateWallet(connection, row.usuario_id, row.carteira_id, row.tipo);
      await validateCategory(connection, row.usuario_id, row.categoria);
    }
    const placeholders = rows
      .map(() => '(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .join(', ');
    const params = rows.flatMap((row) => [
      row.usuario_id,
      row.tipo,
      row.descricao,
      row.valor,
      row.categoria,
      row.data_lancamento,
      row.parcelado ? 1 : 0,
      row.parcela_atual,
      row.parcelas_total,
      row.grupo_parcelamento,
      row.recorrente ? 1 : 0,
      row.recorrencia_atual,
      row.recorrencias_total,
      row.grupo_recorrencia,
      row.origem,
      row.origem_id,
      row.carteira_id,
      row.data_compra || row.data_lancamento,
      row.descricao_original || null
    ]);

    const [result] = await connection.execute(
      `INSERT INTO lancamentos (
        usuario_id, tipo, descricao, valor, categoria, data_lancamento,
        parcelado, parcela_atual, parcelas_total, grupo_parcelamento,
        recorrente, recorrencia_atual, recorrencias_total, grupo_recorrencia,
        origem, origem_id, carteira_id, data_compra, descricao_original
      ) VALUES ${placeholders}`,
      params
    );
    return {
      insertId: Number(result.insertId),
      affectedRows: Number(result.affectedRows)
    };
  }

  async function updateById(userId, transactionId, transaction) {
    return withTransaction(async (c) => {
      await lockUser(c, userId);
      const old = await findById(userId, transactionId, c);
      if (!old) return false;
      const walletId = await validateWallet(
        c,
        userId,
        transaction.carteira_id || old.carteira_id,
        transaction.tipo
      );
      await validateCategory(c, userId, transaction.categoria);
      if (old.parcelado && walletId !== old.carteira_id) {
        throw require('../utils/transactionErrors').transactionBadRequest(
          'INSTALLMENT_WALLET',
          'Para mover uma compra parcelada, recrie a série na carteira correta.'
        );
      }
      const [r] = await c.execute(
        `UPDATE lancamentos SET tipo=?,descricao=?,valor=?,categoria=?,data_lancamento=?,carteira_id=?,data_compra=? WHERE id=? AND usuario_id=?`,
        [
          transaction.tipo,
          transaction.descricao,
          transaction.valor,
          transaction.categoria,
          transaction.data_lancamento,
          walletId,
          old.parcelado ? old.data_compra : transaction.data_lancamento,
          transactionId,
          userId
        ]
      );
      await checkCreditDebt(c, userId);
      return Number(r.affectedRows) > 0;
    });
  }
  async function deleteById(userId, transactionId) {
    return withTransaction(async (c) => {
      await lockUser(c, userId);
      const [r] = await c.execute('DELETE FROM lancamentos WHERE id=? AND usuario_id=?', [
        transactionId,
        userId
      ]);
      await checkCreditDebt(c, userId);
      return Number(r.affectedRows) > 0;
    });
  }

  async function findOriginMatches(executor, userId, keys) {
    if (!keys.length) return [];
    const where = keys
      .map(() => '(origem = ? AND (origem_id = ? OR origem_id LIKE ? OR origem_id LIKE ?))')
      .join(' OR ');
    const params = [userId];
    for (const key of keys) {
      params.push(
        key.origem,
        key.rawOriginId,
        `i.%.%.${key.sourceDigest}.%`,
        `s.${key.sourceDigest}.%`
      );
    }
    const [rows] = await executor.execute(
      `SELECT id, origem, origem_id
       FROM lancamentos
       WHERE usuario_id = ? AND (${where})`,
      params
    );

    return rows.map((row) => ({
      id: Number(row.id),
      origem: row.origem,
      origem_id: row.origem_id,
      encoded: parseEncodedOriginId(row.origem_id),
      sourceDigest: storedSourceDigest(row.origem_id)
    }));
  }

  async function findOriginMatchesByUser(userId, keys) {
    return findOriginMatches(pool, userId, keys);
  }

  async function findIdempotencyRecords(executor, userId, digest) {
    const [rows] = await executor.execute(
      `SELECT id, origem, origem_id
       FROM lancamentos
       WHERE usuario_id = ? AND origem_id LIKE ?
       ORDER BY id ASC`,
      [userId, `i.${digest}.%`]
    );
    return rows.map((row) => ({
      id: Number(row.id),
      origem: row.origem,
      origem_id: row.origem_id,
      encoded: parseEncodedOriginId(row.origem_id)
    }));
  }

  return {
    deleteById,
    findById,
    findIdempotencyRecords,
    findOriginMatches,
    findOriginMatchesByUser,
    insertRows,
    listByUser,
    lockUser,
    updateById,
    withTransaction
  };
}

module.exports = {
  createTransactionRepository,
  mapTransactionRow
};
