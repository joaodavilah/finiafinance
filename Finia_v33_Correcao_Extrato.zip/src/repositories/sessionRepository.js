'use strict';

function assertPool(pool) {
  if (!pool || typeof pool.execute !== 'function') {
    throw new TypeError('Um pool mysql2/promise valido e obrigatorio');
  }
}

function createSessionRepository(pool) {
  assertPool(pool);

  async function createSession(session, executor = pool) {
    await executor.execute(
      `INSERT INTO auth_sessions (
         id, usuario_id, jwt_jti_hash, csrf_token_hash, expires_at_ms,
         ip_hash, user_agent_hash
       ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        session.id,
        session.userId,
        session.jwtJtiHash,
        session.csrfTokenHash,
        session.expiresAtMs,
        session.ipHash || null,
        session.userAgentHash || null
      ]
    );
  }

  async function findActiveById(sessionId, nowMs = Date.now(), executor = pool) {
    const [rows] = await executor.execute(
      `SELECT id, usuario_id AS user_id, jwt_jti_hash, csrf_token_hash,
              expires_at_ms, created_at, last_seen_at
       FROM auth_sessions
       WHERE id = ? AND revoked_at IS NULL AND expires_at_ms > ?
       LIMIT 1`,
      [sessionId, nowMs]
    );

    if (!rows[0]) return null;
    return {
      id: rows[0].id,
      userId: Number(rows[0].user_id),
      jwtJtiHash: rows[0].jwt_jti_hash,
      csrfTokenHash: rows[0].csrf_token_hash,
      expiresAtMs: Number(rows[0].expires_at_ms),
      createdAt: rows[0].created_at,
      lastSeenAt: rows[0].last_seen_at
    };
  }

  async function revokeSession({ sessionId, userId }, executor = pool) {
    const [result] = await executor.execute(
      `UPDATE auth_sessions
       SET revoked_at = COALESCE(revoked_at, UTC_TIMESTAMP(3))
       WHERE id = ? AND usuario_id = ? AND revoked_at IS NULL`,
      [sessionId, userId]
    );
    return result.affectedRows > 0;
  }

  async function revokeAllForUser(userId, executor = pool) {
    const [result] = await executor.execute(
      `UPDATE auth_sessions
       SET revoked_at = COALESCE(revoked_at, UTC_TIMESTAMP(3))
       WHERE usuario_id = ? AND revoked_at IS NULL`,
      [userId]
    );
    return result.affectedRows;
  }

  async function touchSession({ sessionId, userId }, executor = pool) {
    await executor.execute(
      `UPDATE auth_sessions
       SET last_seen_at = UTC_TIMESTAMP(3)
       WHERE id = ? AND usuario_id = ? AND revoked_at IS NULL`,
      [sessionId, userId]
    );
  }

  async function deleteExpired(beforeMs = Date.now(), executor = pool) {
    const [result] = await executor.execute(
      'DELETE FROM auth_sessions WHERE expires_at_ms <= ? OR revoked_at < DATE_SUB(UTC_TIMESTAMP(3), INTERVAL 30 DAY)',
      [beforeMs]
    );
    return result.affectedRows;
  }

  return Object.freeze({
    createSession,
    findActiveById,
    revokeSession,
    revokeAllForUser,
    touchSession,
    deleteExpired
  });
}

module.exports = {
  createSessionRepository
};
