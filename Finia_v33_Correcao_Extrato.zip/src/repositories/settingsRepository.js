'use strict';

function createSettingsRepository(pool) {
  return {
    async findByUserId(userId) {
      const [rows] = await pool.execute(
        'SELECT limite_gastos_mensal FROM usuarios WHERE id = ? LIMIT 1',
        [userId]
      );
      return rows[0] || null;
    },

    async updateMonthlyLimit(userId, monthlyLimit) {
      const [result] = await pool.execute(
        'UPDATE usuarios SET limite_gastos_mensal = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?',
        [monthlyLimit, userId]
      );
      return result.affectedRows > 0;
    }
  };
}

module.exports = { createSettingsRepository };
