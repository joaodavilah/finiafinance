'use strict';

function createProfileRepository(pool) {
  if (!pool || typeof pool.execute !== 'function') {
    throw new TypeError('Um pool mysql2/promise valido e obrigatorio');
  }

  async function findByUserId(userId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT u.id, u.nome_completo, u.email, u.plano,
              a.updated_at AS avatar_updated_at
       FROM usuarios u
       LEFT JOIN user_avatars a ON a.usuario_id = u.id
       WHERE u.id = ?
       LIMIT 1`,
      [userId]
    );
    return rows[0] || null;
  }

  async function updateName(userId, name, executor = pool) {
    const [result] = await executor.execute(
      `UPDATE usuarios
       SET nome_completo = ?, atualizado_em = UTC_TIMESTAMP(3)
       WHERE id = ?`,
      [name, userId]
    );
    return result.affectedRows > 0;
  }

  async function getAvatar(userId, executor = pool) {
    const [rows] = await executor.execute(
      `SELECT mime_type, image_data, byte_size, updated_at
       FROM user_avatars
       WHERE usuario_id = ?
       LIMIT 1`,
      [userId]
    );
    return rows[0] || null;
  }

  async function upsertAvatar({ userId, mimeType, imageData }, executor = pool) {
    await executor.execute(
      `INSERT INTO user_avatars (usuario_id, mime_type, image_data, byte_size)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         mime_type = VALUES(mime_type),
         image_data = VALUES(image_data),
         byte_size = VALUES(byte_size),
         updated_at = UTC_TIMESTAMP(3)`,
      [userId, mimeType, imageData, imageData.length]
    );
    return findByUserId(userId, executor);
  }

  async function deleteAvatar(userId, executor = pool) {
    const [result] = await executor.execute('DELETE FROM user_avatars WHERE usuario_id = ?', [
      userId
    ]);
    return result.affectedRows > 0;
  }

  return Object.freeze({
    findByUserId,
    updateName,
    getAvatar,
    upsertAvatar,
    deleteAvatar
  });
}

module.exports = { createProfileRepository };
