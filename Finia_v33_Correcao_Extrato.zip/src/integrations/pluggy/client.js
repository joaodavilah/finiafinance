'use strict';

const { PluggyClientError, errorFromResponse, timeoutError } = require('./errors');

function requiredString(value, name) {
  const normalized = String(value || '').trim();
  if (!normalized) throw new TypeError(`${name} is required`);
  return normalized;
}

function positiveInteger(value, fallback, name, max) {
  const parsed = value === undefined ? fallback : Number(value);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > max) {
    throw new TypeError(`${name} must be an integer between 1 and ${max}`);
  }
  return parsed;
}

function normalizeBaseUrl(value, allowInsecureForTests) {
  const url = new URL(value || 'https://api.pluggy.ai');
  if (url.protocol !== 'https:' && !allowInsecureForTests) {
    throw new TypeError('Pluggy baseUrl must use HTTPS');
  }
  url.pathname = url.pathname.replace(/\/$/, '');
  url.search = '';
  url.hash = '';
  return url;
}

function createAbortContext(externalSignal, timeoutMs) {
  const controller = new AbortController();
  let timedOut = false;

  const abortFromExternal = () => controller.abort(externalSignal.reason);
  if (externalSignal) {
    if (externalSignal.aborted) abortFromExternal();
    else externalSignal.addEventListener('abort', abortFromExternal, { once: true });
  }

  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort(new Error('Pluggy request timeout'));
  }, timeoutMs);

  return {
    signal: controller.signal,
    didTimeout: () => timedOut,
    cleanup() {
      clearTimeout(timeout);
      externalSignal?.removeEventListener?.('abort', abortFromExternal);
    }
  };
}

async function readResponseBody(response, maxBytes) {
  if (response.status === 204) return null;

  const contentLength = Number(response.headers?.get?.('content-length') || 0);
  if (contentLength > maxBytes) {
    throw new PluggyClientError({
      code: 'BANK_PROVIDER_RESPONSE_TOO_LARGE',
      publicMessage: 'O provedor bancario retornou uma resposta maior que o permitido',
      statusCode: 502
    });
  }

  let text;
  const reader = response.body?.getReader?.();
  if (reader) {
    const chunks = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        throw new PluggyClientError({
          code: 'BANK_PROVIDER_RESPONSE_TOO_LARGE',
          publicMessage: 'O provedor bancario retornou uma resposta maior que o permitido',
          statusCode: 502
        });
      }
      chunks.push(Buffer.from(value));
    }
    text = Buffer.concat(chunks, size).toString('utf8');
  } else {
    text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > maxBytes) {
      throw new PluggyClientError({
        code: 'BANK_PROVIDER_RESPONSE_TOO_LARGE',
        publicMessage: 'O provedor bancario retornou uma resposta maior que o permitido',
        statusCode: 502
      });
    }
  }

  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new PluggyClientError({
      code: 'BANK_PROVIDER_INVALID_RESPONSE',
      publicMessage: 'O provedor bancario retornou uma resposta invalida',
      statusCode: 502,
      cause
    });
  }
}

function extractNextCursor(nextValue, baseUrl) {
  if (!nextValue) return null;
  const next = String(nextValue).trim();
  if (!next || next.length > 4096) {
    throw new PluggyClientError({
      code: 'BANK_PROVIDER_INVALID_PAGINATION',
      publicMessage: 'O provedor bancario retornou uma paginacao invalida',
      statusCode: 502
    });
  }

  if (!next.includes('?') && !next.includes('=') && !next.includes('/')) return next;

  try {
    const url = new URL(next, baseUrl);
    const cursor = url.searchParams.get('after');
    if (!cursor) throw new Error('Missing cursor');
    return cursor;
  } catch (cause) {
    throw new PluggyClientError({
      code: 'BANK_PROVIDER_INVALID_PAGINATION',
      publicMessage: 'O provedor bancario retornou uma paginacao invalida',
      statusCode: 502,
      cause
    });
  }
}

function createPluggyClient(config, dependencies = {}) {
  if (!config || typeof config !== 'object') {
    throw new TypeError('Pluggy configuration must be injected');
  }

  const fetchImpl = dependencies.fetch || globalThis.fetch;
  if (typeof fetchImpl !== 'function') {
    throw new TypeError('A Fetch API implementation is required');
  }

  const baseUrl = normalizeBaseUrl(
    config.baseUrl || config.apiUrl,
    config.allowInsecureForTests === true
  );
  const clientId = requiredString(config.clientId, 'clientId');
  const clientSecret = requiredString(config.clientSecret, 'clientSecret');
  const timeoutMs = positiveInteger(config.timeoutMs, 12000, 'timeoutMs', 120000);
  const maxPages = positiveInteger(config.maxPages, 1000, 'maxPages', 10000);
  const maxResponseBytes = positiveInteger(
    config.maxResponseBytes,
    10 * 1024 * 1024,
    'maxResponseBytes',
    50 * 1024 * 1024
  );
  const apiKeyTtlMs = positiveInteger(
    config.apiKeyTtlMs,
    110 * 60 * 1000,
    'apiKeyTtlMs',
    2 * 60 * 60 * 1000
  );

  let apiKeyCache = null;
  let apiKeyPromise = null;

  function buildUrl(pathname, query) {
    if (!String(pathname).startsWith('/')) {
      throw new TypeError('Pluggy path must start with /');
    }
    const url = new URL(pathname, `${baseUrl.toString().replace(/\/$/, '')}/`);
    if (url.origin !== baseUrl.origin) {
      throw new TypeError('Pluggy request cannot target another origin');
    }
    for (const [key, value] of Object.entries(query || {})) {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.set(key, String(value));
      }
    }
    return url;
  }

  async function rawRequest(pathname, options = {}) {
    const abortContext = createAbortContext(options.signal, options.timeoutMs || timeoutMs);
    try {
      const response = await fetchImpl(buildUrl(pathname, options.query), {
        method: options.method || 'GET',
        headers: {
          Accept: 'application/json',
          ...(options.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
          ...(options.apiKey ? { 'X-API-KEY': options.apiKey } : {}),
          ...(options.headers || {})
        },
        body: options.body === undefined ? undefined : JSON.stringify(options.body),
        signal: abortContext.signal
      });

      const body = await readResponseBody(response, maxResponseBytes);
      if (!response.ok) throw errorFromResponse(response, body);
      return body;
    } catch (error) {
      if (abortContext.didTimeout()) throw timeoutError(error);
      if (error instanceof PluggyClientError) throw error;
      if (options.signal?.aborted) throw error;
      throw new PluggyClientError({
        code: 'BANK_PROVIDER_NETWORK_ERROR',
        publicMessage: 'Nao foi possivel comunicar com o provedor bancario',
        statusCode: 502,
        retryable: true,
        cause: error
      });
    } finally {
      abortContext.cleanup();
    }
  }

  async function authenticate() {
    if (apiKeyCache && apiKeyCache.expiresAt > Date.now() + 60_000) {
      return apiKeyCache.value;
    }
    if (apiKeyPromise) return apiKeyPromise;

    apiKeyPromise = (async () => {
      const response = await rawRequest('/auth', {
        method: 'POST',
        body: { clientId, clientSecret }
      });
      const apiKey = requiredString(response?.apiKey, 'Pluggy apiKey');
      apiKeyCache = { value: apiKey, expiresAt: Date.now() + apiKeyTtlMs };
      return apiKey;
    })();

    try {
      return await apiKeyPromise;
    } finally {
      apiKeyPromise = null;
    }
  }

  async function request(pathname, options = {}) {
    const apiKey = await authenticate();
    try {
      return await rawRequest(pathname, { ...options, apiKey });
    } catch (error) {
      if (
        error instanceof PluggyClientError &&
        error.upstreamStatus === 401 &&
        !options.authRetried
      ) {
        apiKeyCache = null;
        const refreshedApiKey = await authenticate();
        return rawRequest(pathname, {
          ...options,
          apiKey: refreshedApiKey,
          authRetried: true
        });
      }
      throw error;
    }
  }

  async function createConnectToken(input) {
    const clientUserId = requiredString(input?.clientUserId, 'clientUserId');
    const options = {
      clientUserId,
      avoidDuplicates: input.avoidDuplicates !== false,
      ...(input.webhookUrl ? { webhookUrl: String(input.webhookUrl) } : {}),
      ...(input.oauthRedirectUri ? { oauthRedirectUri: String(input.oauthRedirectUri) } : {}),
      ...(Array.isArray(input.products) ? { products: input.products.map(String) } : {})
    };
    const body = {
      ...(input.itemId ? { itemId: requiredString(input.itemId, 'itemId') } : {}),
      options
    };
    return request('/connect_token', { method: 'POST', body, signal: input.signal });
  }

  async function getItem(itemId, options = {}) {
    return request(`/items/${encodeURIComponent(requiredString(itemId, 'itemId'))}`, {
      signal: options.signal
    });
  }

  async function deleteItem(itemId, options = {}) {
    return request(`/items/${encodeURIComponent(requiredString(itemId, 'itemId'))}`, {
      method: 'DELETE',
      signal: options.signal
    });
  }

  async function listAccounts(itemId, options = {}) {
    const data = await request('/accounts', {
      query: { itemId: requiredString(itemId, 'itemId') },
      signal: options.signal
    });
    const accounts = Array.isArray(data?.results)
      ? data.results
      : Array.isArray(data)
        ? data
        : null;
    if (!accounts) {
      throw new PluggyClientError({
        code: 'BANK_PROVIDER_INVALID_RESPONSE',
        publicMessage: 'O provedor bancario retornou contas em formato invalido',
        statusCode: 502
      });
    }
    return accounts;
  }

  async function getTransactionsPage(input) {
    const data = await request('/v2/transactions', {
      query: {
        accountId: requiredString(input?.accountId, 'accountId'),
        dateFrom: input.dateFrom,
        dateTo: input.dateTo,
        createdAtFrom: input.createdAtFrom,
        after: input.after
      },
      signal: input.signal
    });
    if (!Array.isArray(data?.results)) {
      throw new PluggyClientError({
        code: 'BANK_PROVIDER_INVALID_RESPONSE',
        publicMessage: 'O provedor bancario retornou transacoes em formato invalido',
        statusCode: 502
      });
    }
    return {
      results: data.results,
      nextCursor: extractNextCursor(data.next, baseUrl)
    };
  }

  async function* paginateTransactions(input) {
    const seenCursors = new Set();
    let after = input.after || null;
    if (after) seenCursors.add(String(after));

    for (let page = 1; page <= maxPages; page += 1) {
      const result = await getTransactionsPage({ ...input, after });
      yield { page, results: result.results, nextCursor: result.nextCursor };

      if (!result.nextCursor) return;
      if (seenCursors.has(result.nextCursor)) {
        throw new PluggyClientError({
          code: 'BANK_PROVIDER_PAGINATION_LOOP',
          publicMessage: 'O provedor bancario repetiu uma pagina de transacoes',
          statusCode: 502
        });
      }
      seenCursors.add(result.nextCursor);
      after = result.nextCursor;

      if (page === maxPages) {
        throw new PluggyClientError({
          code: 'BANK_PROVIDER_PAGINATION_LIMIT',
          publicMessage: 'A sincronizacao excedeu o limite seguro de paginas e nao foi truncada',
          statusCode: 502
        });
      }
    }
  }

  return {
    authenticate,
    createConnectToken,
    deleteItem,
    getItem,
    getTransactionsPage,
    listAccounts,
    paginateTransactions
  };
}

module.exports = {
  createPluggyClient,
  extractNextCursor,
  readResponseBody
};
