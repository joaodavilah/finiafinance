'use strict';

class PluggyMappingError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'PluggyMappingError';
    this.code = code;
  }
}

function categoryFor(transaction, tipo) {
  const text = [
    transaction.description,
    transaction.descriptionRaw,
    transaction.category,
    transaction.merchant?.name,
    transaction.merchant?.businessName
  ]
    .filter(Boolean)
    .join(' ')
    .toLocaleLowerCase('pt-BR');

  if (tipo === 'entrada') {
    if (/sal[aá]rio|pagamento|pix recebido|transfer[eê]ncia recebida|recebido/.test(text)) {
      return 'salario';
    }
    if (/freela|freelance|servi[cç]o/.test(text)) return 'freelance';
    return 'outros';
  }

  if (/mercado|supermercado|restaurante|ifood|padaria|alimenta/.test(text)) return 'alimentacao';
  if (/uber|\b99\b|posto|combust[ií]vel|metr[oô]|[oô]nibus|transporte/.test(text))
    return 'transporte';
  if (/farm[aá]cia|hospital|cl[ií]nica|sa[uú]de|medic/.test(text)) return 'saude';
  if (/netflix|spotify|cinema|lazer|show|jogo/.test(text)) return 'lazer';
  if (/aluguel|condom[ií]nio|energia|[aá]gua|internet|moradia/.test(text)) return 'moradia';
  if (/curso|faculdade|escola|livro|educa/.test(text)) return 'educacao';
  return 'outros';
}

function transactionType(transaction, accountType) {
  const rawType = String(transaction.type || '').toUpperCase();
  if (rawType === 'DEBIT') return 'saida';
  if (rawType === 'CREDIT') return 'entrada';

  const amount = Number(transaction.amount);
  if (String(accountType || '').toUpperCase() === 'CREDIT') {
    return amount >= 0 ? 'saida' : 'entrada';
  }
  return amount < 0 ? 'saida' : 'entrada';
}

function transactionDate(value) {
  const date = new Date(value);
  if (!value || Number.isNaN(date.getTime())) {
    throw new PluggyMappingError('BANK_TRANSACTION_INVALID_DATE', 'Invalid transaction date');
  }
  return date.toISOString().slice(0, 10);
}

function normalizeDescription(transaction) {
  const value = String(
    transaction.description ||
      transaction.descriptionRaw ||
      transaction.merchant?.name ||
      'Lancamento bancario'
  )
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return (value || 'Lancamento bancario').slice(0, 150);
}

function mapPluggyTransaction(transaction, context) {
  if (!transaction || typeof transaction !== 'object') {
    throw new PluggyMappingError('BANK_TRANSACTION_INVALID', 'Transaction must be an object');
  }

  const originId = String(transaction.id || '').trim();
  if (!originId || originId.length > 150) {
    throw new PluggyMappingError(
      'BANK_TRANSACTION_INVALID_ID',
      'Transaction id is missing or too long'
    );
  }

  const amount = Number(transaction.amount);
  const absoluteAmount = Math.abs(amount);
  if (!Number.isFinite(amount) || absoluteAmount <= 0 || absoluteAmount > 99_999_999.99) {
    throw new PluggyMappingError(
      'BANK_TRANSACTION_INVALID_AMOUNT',
      'Transaction amount is invalid'
    );
  }

  const tipo = transactionType(transaction, context?.accountType);
  return {
    conexao_bancaria_id: Number(context?.connectionId),
    tipo,
    descricao: normalizeDescription(transaction),
    valor: absoluteAmount.toFixed(2),
    categoria: categoryFor(transaction, tipo),
    data_lancamento: transactionDate(
      transaction.date || transaction.createdAt || transaction.updatedAt
    ),
    origem: 'pluggy',
    origem_id: originId,
    origem_conta_id: String(context?.accountId || transaction.accountId || '').slice(0, 150) || null
  };
}

function tryMapPluggyTransaction(transaction, context) {
  try {
    return { value: mapPluggyTransaction(transaction, context), error: null };
  } catch (error) {
    if (!(error instanceof PluggyMappingError)) throw error;
    return { value: null, error };
  }
}

module.exports = {
  PluggyMappingError,
  mapPluggyTransaction,
  tryMapPluggyTransaction
};
