'use strict';

class PluggyClientError extends Error {
  constructor(options) {
    super(options.internalMessage || options.publicMessage || 'Pluggy request failed', {
      cause: options.cause
    });
    this.name = 'PluggyClientError';
    this.code = options.code || 'BANK_PROVIDER_ERROR';
    this.publicMessage = options.publicMessage || 'O provedor bancario nao respondeu como esperado';
    this.statusCode = options.statusCode || 502;
    this.status = this.statusCode;
    this.expose = true;
    this.upstreamStatus = options.upstreamStatus || null;
    this.upstreamCode = options.upstreamCode || null;
    this.retryable = Boolean(options.retryable);
  }

  toPublic() {
    return {
      code: this.code,
      message: this.publicMessage
    };
  }
}

function errorFromResponse(response, body) {
  const upstreamStatus = Number(response?.status || 0);
  const upstreamCode =
    String(body?.codeDescription || body?.code || body?.error || '')
      .trim()
      .slice(0, 100) || null;

  if (upstreamStatus === 404) {
    return new PluggyClientError({
      code: 'BANK_ITEM_NOT_FOUND',
      publicMessage: 'A conexao bancaria nao foi encontrada no provedor',
      statusCode: 404,
      upstreamCode,
      upstreamStatus
    });
  }

  if (upstreamStatus === 409) {
    return new PluggyClientError({
      code: 'BANK_PROVIDER_CONFLICT',
      publicMessage: 'A conexao bancaria esta ocupada ou em conflito. Tente novamente mais tarde',
      statusCode: 409,
      upstreamCode,
      upstreamStatus,
      retryable: true
    });
  }

  if (upstreamStatus === 429) {
    return new PluggyClientError({
      code: 'BANK_PROVIDER_RATE_LIMITED',
      publicMessage: 'O provedor bancario esta temporariamente ocupado',
      statusCode: 503,
      upstreamCode,
      upstreamStatus,
      retryable: true
    });
  }

  if (upstreamStatus === 400 || upstreamStatus === 422) {
    return new PluggyClientError({
      code: 'BANK_PROVIDER_REJECTED',
      publicMessage: 'O provedor bancario rejeitou a operacao solicitada',
      statusCode: 422,
      upstreamCode,
      upstreamStatus
    });
  }

  if (upstreamStatus === 401 || upstreamStatus === 403) {
    return new PluggyClientError({
      code: 'BANK_PROVIDER_AUTH_ERROR',
      publicMessage: 'A integracao bancaria esta temporariamente indisponivel',
      statusCode: 503,
      upstreamCode,
      upstreamStatus
    });
  }

  return new PluggyClientError({
    code: upstreamStatus >= 500 ? 'BANK_PROVIDER_UNAVAILABLE' : 'BANK_PROVIDER_ERROR',
    publicMessage: 'O provedor bancario esta temporariamente indisponivel',
    statusCode: 502,
    upstreamCode,
    upstreamStatus,
    retryable: upstreamStatus >= 500
  });
}

function timeoutError(cause) {
  return new PluggyClientError({
    code: 'BANK_PROVIDER_TIMEOUT',
    publicMessage: 'O provedor bancario demorou para responder. Tente novamente',
    statusCode: 504,
    retryable: true,
    cause
  });
}

module.exports = {
  PluggyClientError,
  errorFromResponse,
  timeoutError
};
