'use strict';

const path = require('path');
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const defaultLogger = require('./lib/logger');
const { requestContext } = require('./middleware/requestContext');
const { createSecurityHeaders, sensitiveResponseHeaders } = require('./middleware/securityHeaders');
const { createAuthRateLimiters } = require('./middleware/rateLimiters');
const { createAuthenticationMiddleware } = require('./middleware/authentication');
const { createCsrfProtection } = require('./middleware/csrfProtection');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
const { createUserRepository } = require('./repositories/userRepository');
const { createSessionRepository } = require('./repositories/sessionRepository');
const { createSettingsRepository } = require('./repositories/settingsRepository');
const { createProfileRepository } = require('./repositories/profileRepository');
const { createBankRepository } = require('./repositories/bankRepository');
const { createAuthService } = require('./services/authService');
const { createMailService } = require('./services/mailService');
const { createSettingsService } = require('./services/settingsService');
const { createProfileService } = require('./services/profileService');
const { BankServiceError, createBankService } = require('./services/bankService');
const { createPluggyClient } = require('./integrations/pluggy');
const { createAuthRouter } = require('./routes/authRouter');
const { createSettingsRouter } = require('./routes/settingsRouter');
const { createProfileRouter } = require('./routes/profileRouter');
const { createSystemRouter } = require('./routes/systemRouter');
const { createTransactionRouter } = require('./routes/transactionRouter');
const { createWalletRouter } = require('./routes/walletRouter');
const { createBankRouter } = require('./routes/bankRouter');

const API_PREFIX = '/api/v1';

function createApiLimiter() {
  return rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 600,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skip: (req) => req.path === '/health/live' || req.path === '/health/ready',
    message: {
      erro: 'Muitas requisicoes. Tente novamente em instantes.',
      codigo: 'RATE_LIMITED'
    },
    handler(req, res, _next, options) {
      res.status(options.statusCode).json({
        ...options.message,
        requestId: req.id
      });
    }
  });
}

function createCorsMiddleware(config) {
  const allowedOrigins = new Set(config.cors?.allowedOrigins || [config.appOrigin]);
  return cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.has(origin)) return callback(null, true);
      const error = new Error('Origem nao autorizada');
      error.status = 403;
      error.code = 'ORIGIN_NOT_ALLOWED';
      error.expose = true;
      return callback(error);
    },
    credentials: config.cors?.credentials ?? true,
    methods: config.cors?.methods,
    allowedHeaders: config.cors?.allowedHeaders,
    exposedHeaders: config.cors?.exposedHeaders,
    maxAge: config.cors?.maxAgeSeconds ?? 600,
    optionsSuccessStatus: 204
  });
}

function enforceHttps(config) {
  return function httpsOnly(req, res, next) {
    if (!config.isProduction || req.secure) return next();

    if (req.originalUrl.startsWith(API_PREFIX) || req.originalUrl.startsWith('/health')) {
      return res.status(426).json({
        erro: 'HTTPS obrigatorio',
        codigo: 'HTTPS_REQUIRED',
        requestId: req.id
      });
    }

    const requestPath = req.originalUrl.startsWith('/') ? req.originalUrl : '/';
    return res.redirect(308, `${config.appUrl}${requestPath}`);
  };
}

function createUnavailableBankService() {
  function unavailable() {
    throw new BankServiceError(
      'BANK_INTEGRATION_DISABLED',
      'A integracao bancaria nao esta configurada',
      503
    );
  }

  return Object.freeze({
    async getStatus() {
      return { configured: false, connections: [] };
    },
    createConnectToken: unavailable,
    associateConnection: unavailable,
    syncConnection: unavailable,
    disconnectConnection: unavailable
  });
}

function buildServices({ config, pool, logger, overrides = {} }) {
  const userRepository = overrides.userRepository || createUserRepository(pool);
  const sessionRepository = overrides.sessionRepository || createSessionRepository(pool);
  const mailService = overrides.mailService || createMailService({ config });
  const authService =
    overrides.authService ||
    createAuthService({
      config,
      userRepository,
      sessionRepository,
      mailService,
      logger
    });

  const settingsRepository = overrides.settingsRepository || createSettingsRepository(pool);
  const settingsService = overrides.settingsService || createSettingsService(settingsRepository);
  const profileRepository = overrides.profileRepository || createProfileRepository(pool);
  const profileService = overrides.profileService || createProfileService(profileRepository);

  let bankService = overrides.bankService;
  if (!bankService && config.pluggy.enabled) {
    const pluggyClient = overrides.pluggyClient || createPluggyClient(config.pluggy);
    const bankRepository = overrides.bankRepository || createBankRepository({ pool });
    bankService = createBankService({
      repository: bankRepository,
      pluggyClient,
      logger,
      connectTokenOptions: config.pluggy.connectOptions
    });
  }
  bankService ||= createUnavailableBankService();

  return Object.freeze({
    authService,
    bankService,
    mailService,
    sessionRepository,
    settingsService,
    profileService
  });
}

function createApplication({
  config,
  pool,
  readiness,
  logger = defaultLogger,
  overrides = {}
} = {}) {
  if (!config?.appOrigin || !config?.cookies || !pool || !readiness?.snapshot) {
    throw new TypeError('config, pool e readiness validos sao obrigatorios');
  }

  const app = express();
  const publicDirectory = path.join(__dirname, '../public');
  const services = buildServices({ config, pool, logger, overrides });

  app.disable('x-powered-by');
  app.set('etag', 'strong');
  if (config.trustProxy !== false) app.set('trust proxy', config.trustProxy);

  app.use(requestContext);
  app.use(createSecurityHeaders(config));
  app.use(enforceHttps(config));
  app.use(createCorsMiddleware(config));
  app.use(cookieParser());

  app.get('/health', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({ ok: true, service: 'finia-api' });
  });

  app.use(API_PREFIX, sensitiveResponseHeaders);
  app.use(API_PREFIX, createApiLimiter());
  app.use(
    express.json({
      limit: '512kb',
      strict: true,
      type: ['application/json', 'application/*+json']
    })
  );
  app.use(
    express.urlencoded({
      extended: false,
      limit: '32kb',
      parameterLimit: 50
    })
  );

  const authenticate = createAuthenticationMiddleware({
    config,
    authService: services.authService
  });
  const requireCsrf = createCsrfProtection({
    config,
    authService: services.authService
  });

  const api = express.Router();
  api.use(createSystemRouter({ readiness }));
  api.use(
    createAuthRouter({
      config,
      authService: services.authService,
      authenticationMiddleware: authenticate,
      csrfProtection: requireCsrf,
      rateLimiters: createAuthRateLimiters()
    })
  );
  api.use(
    '/user/settings',
    createSettingsRouter({
      service: services.settingsService,
      authenticate,
      requireCsrf
    })
  );
  api.use(
    '/user/profile',
    createProfileRouter({
      service: services.profileService,
      authenticate,
      requireCsrf
    })
  );
  api.use(
    createTransactionRouter({
      pool,
      authenticate,
      requireCsrf,
      logger
    })
  );
  api.use(
    '/bank',
    createBankRouter({
      bankService: services.bankService,
      authenticate,
      requireCsrf,
      logger
    })
  );
  api.use(createWalletRouter({ pool, authenticate, requireCsrf }));
  api.use(notFoundHandler);
  app.use(API_PREFIX, api);

  app.use(
    express.static(publicDirectory, {
      index: false,
      fallthrough: true,
      maxAge: 0,
      setHeaders(res, filePath) {
        if (path.extname(filePath).toLowerCase() === '.html') {
          res.setHeader('Cache-Control', 'no-store');
        } else if (filePath.includes(`${path.sep}assets${path.sep}`)) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
      }
    })
  );

  app.get(['/', '/app'], (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(path.join(publicDirectory, 'index.html'));
  });

  app.use((req, res) => {
    if (req.accepts('html')) {
      return res.status(404).type('text').send('Pagina nao encontrada');
    }
    return notFoundHandler(req, res);
  });
  app.use(errorHandler);

  app.locals.finia = Object.freeze({
    apiPrefix: API_PREFIX,
    services
  });

  return app;
}

module.exports = {
  API_PREFIX,
  createApplication,
  createUnavailableBankService
};
