'use strict';

const CIVIL_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

function parseCivilDate(value) {
  if (typeof value !== 'string') return null;
  const match = value.match(CIVIL_DATE_PATTERN);
  if (!match) return null;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);

  if (year < 1000 || year > 9999 || month < 1 || month > 12) return null;
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  if (day < 1 || day > daysInMonth) return null;

  return { year, month, day, value };
}

function isValidCivilDate(value) {
  return parseCivilDate(value) !== null;
}

function formatCivilDate(year, month, day) {
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

function addMonthsCivil(value, amount) {
  const parsed = parseCivilDate(value);
  if (!parsed || !Number.isInteger(amount)) return null;

  const absoluteMonth = parsed.year * 12 + (parsed.month - 1) + amount;
  const year = Math.floor(absoluteMonth / 12);
  const monthIndex = ((absoluteMonth % 12) + 12) % 12;
  const month = monthIndex + 1;
  if (year < 1000 || year > 9999) return null;

  const daysInTargetMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return formatCivilDate(year, month, Math.min(parsed.day, daysInTargetMonth));
}

function compareCivilDates(left, right) {
  if (!isValidCivilDate(left) || !isValidCivilDate(right)) return null;
  return left === right ? 0 : left < right ? -1 : 1;
}

function dateFromDatabase(value) {
  if (typeof value === 'string') {
    const civil = value.slice(0, 10);
    return isValidCivilDate(civil) ? civil : null;
  }

  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return formatCivilDate(value.getUTCFullYear(), value.getUTCMonth() + 1, value.getUTCDate());
  }

  return null;
}

module.exports = {
  addMonthsCivil,
  compareCivilDates,
  dateFromDatabase,
  formatCivilDate,
  isValidCivilDate,
  parseCivilDate
};
