'use strict';

const MAX_TRANSACTION_CENTS = 9_999_999_999;

function centsToDecimal(cents) {
  if (!Number.isSafeInteger(cents)) return null;
  const sign = cents < 0 ? '-' : '';
  const absolute = Math.abs(cents);
  return `${sign}${Math.floor(absolute / 100)}.${String(absolute % 100).padStart(2, '0')}`;
}

function parseDecimalString(value) {
  const text = value.trim();
  if (!/^\d{1,8}(?:[.,]\d{1,2})?$/.test(text)) return null;
  const [whole, fraction = ''] = text.replace(',', '.').split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  return Number.isSafeInteger(cents) ? cents : null;
}

function parseMoneyToCents(value, options = {}) {
  const { allowZero = false, allowNegative = false } = options;
  let cents = null;

  if (typeof value === 'string') {
    const trimmed = value.trim();
    const negative = trimmed.startsWith('-');
    if (negative && !allowNegative) return null;
    cents = parseDecimalString(negative ? trimmed.slice(1) : trimmed);
    if (cents !== null && negative) cents *= -1;
  } else if (typeof value === 'number' && Number.isFinite(value)) {
    const scaled = value * 100;
    const rounded = Math.round(scaled);
    const tolerance = Number.EPSILON * Math.max(1, Math.abs(scaled)) * 4;
    if (Math.abs(scaled - rounded) > tolerance) return null;
    cents = rounded;
  }

  if (!Number.isSafeInteger(cents)) return null;
  if (!allowNegative && cents < 0) return null;
  if (!allowZero && cents === 0) return null;
  if (Math.abs(cents) > MAX_TRANSACTION_CENTS) return null;
  return cents;
}

function parseStatementMoney(value) {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  let text = String(value).trim();
  if (!text) return null;

  let negative = false;
  if (/^\(.*\)$/.test(text)) {
    negative = true;
    text = text.slice(1, -1);
  }
  if (text.startsWith('-') || text.endsWith('-')) negative = true;

  text = text
    .replace(/\u00a0/g, ' ')
    .replace(/(?:R\$|BRL)/gi, '')
    .replace(/[+\s-]/g, '');

  if (!/^\d[\d.,]*$/.test(text)) return null;

  const lastComma = text.lastIndexOf(',');
  const lastDot = text.lastIndexOf('.');
  let decimalSeparator = null;

  if (lastComma >= 0 && lastDot >= 0) {
    decimalSeparator = lastComma > lastDot ? ',' : '.';
  } else if (lastComma >= 0) {
    const digitsAfter = text.length - lastComma - 1;
    decimalSeparator = digitsAfter === 1 || digitsAfter === 2 ? ',' : null;
  } else if (lastDot >= 0) {
    const digitsAfter = text.length - lastDot - 1;
    decimalSeparator = digitsAfter === 1 || digitsAfter === 2 ? '.' : null;
  }

  let normalized;
  if (decimalSeparator) {
    const decimalIndex = text.lastIndexOf(decimalSeparator);
    const whole = text.slice(0, decimalIndex).replace(/[.,]/g, '');
    const fraction = text.slice(decimalIndex + 1);
    if (!/^\d+$/.test(whole) || !/^\d{1,2}$/.test(fraction)) return null;
    normalized = `${whole}.${fraction}`;
  } else {
    normalized = text.replace(/[.,]/g, '');
  }

  const cents = parseMoneyToCents(normalized, { allowNegative: false });
  if (cents === null) return null;
  return negative ? -cents : cents;
}

function splitCents(totalCents, parts) {
  if (!Number.isSafeInteger(totalCents) || totalCents <= 0) return null;
  if (!Number.isInteger(parts) || parts < 1) return null;

  const base = Math.floor(totalCents / parts);
  const remainder = totalCents % parts;
  return Array.from({ length: parts }, (_, index) => base + (index < remainder ? 1 : 0));
}

module.exports = {
  MAX_TRANSACTION_CENTS,
  centsToDecimal,
  parseMoneyToCents,
  parseStatementMoney,
  splitCents
};
