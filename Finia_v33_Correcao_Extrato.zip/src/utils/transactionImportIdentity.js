'use strict';

const crypto = require('crypto');
const { sha256, stableJson } = require('./transactionCursor');

const ENCODED_ORIGIN_PATTERN = /^i\.([a-f0-9]{24})\.([a-f0-9]{24})\.([a-f0-9]{32})\.(\d{1,3})$/;

function publicTransactionShape(transaction) {
  return {
    tipo: transaction.tipo,
    carteira_id: transaction.carteira_id || null,
    descricao: transaction.descricao,
    ...(transaction.descricao_original ? { descricao_original: transaction.descricao_original } : {}),
    valor: transaction.valor,
    categoria: transaction.categoria,
    data_lancamento: transaction.data_lancamento,
    parcelado: Boolean(transaction.parcelado),
    parcelas_total: transaction.parcelas_total || null,
    recorrente: Boolean(transaction.recorrente),
    recorrencias_total: transaction.recorrencias_total || null,
    origem: transaction.origem,
    origem_id: transaction.origem_id || null
  };
}

function createPreviewHash(transactions) {
  return sha256(stableJson(transactions.map(publicTransactionShape)));
}

function keyDigest(idempotencyKey) {
  return sha256(idempotencyKey).slice(0, 24);
}

function sourceDigest(transaction, itemIndex) {
  if (transaction.origem_id) {
    return sha256(`${transaction.origem}\u0000${transaction.origem_id}`).slice(0, 32);
  }
  return sha256(`${itemIndex}\u0000${stableJson(publicTransactionShape(transaction))}`).slice(
    0,
    32
  );
}

function buildEncodedOriginId({ idempotencyKey, previewHash, source, occurrence }) {
  const normalizedOccurrence = Number(occurrence);
  if (
    !Number.isInteger(normalizedOccurrence) ||
    normalizedOccurrence < 1 ||
    normalizedOccurrence > 999
  ) {
    throw new TypeError('Invalid import occurrence');
  }
  return `i.${keyDigest(idempotencyKey)}.${previewHash.slice(0, 24)}.${source}.${normalizedOccurrence}`;
}

function parseEncodedOriginId(value) {
  if (typeof value !== 'string') return null;
  const match = value.match(ENCODED_ORIGIN_PATTERN);
  if (!match) return null;
  return {
    keyDigest: match[1],
    previewDigest: match[2],
    sourceDigest: match[3],
    occurrence: Number(match[4])
  };
}

function safeHashEqual(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string') return false;
  const leftBuffer = Buffer.from(left, 'utf8');
  const rightBuffer = Buffer.from(right, 'utf8');
  return (
    leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer)
  );
}

module.exports = {
  buildEncodedOriginId,
  createPreviewHash,
  keyDigest,
  parseEncodedOriginId,
  publicTransactionShape,
  safeHashEqual,
  sourceDigest
};
