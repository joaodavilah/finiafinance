'use strict';

function clampTransactionLimit(value, ceiling) {
  if (!Number.isSafeInteger(ceiling) || ceiling <= 0) {
    throw new TypeError('Transaction limit ceiling must be a positive safe integer');
  }
  if (!Number.isSafeInteger(value) || value <= 0) return ceiling;
  return Math.min(value, ceiling);
}

module.exports = {
  clampTransactionLimit
};
