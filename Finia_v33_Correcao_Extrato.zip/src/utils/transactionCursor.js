'use strict';

const crypto = require('crypto');
const { isValidCivilDate } = require('./transactionDate');
const { transactionBadRequest } = require('./transactionErrors');

function stableObject(value) {
  if (Array.isArray(value)) return value.map(stableObject);
  if (!value || typeof value !== 'object') return value;

  return Object.fromEntries(
    Object.keys(value)
      .sort()
      .map((key) => [key, stableObject(value[key])])
  );
}

function stableJson(value) {
  return JSON.stringify(stableObject(value));
}

function sha256(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function transactionFilterHash(filters) {
  return sha256(stableJson(filters)).slice(0, 24);
}

function encodeTransactionCursor({ data_lancamento, id, filterHash }) {
  const payload = {
    v: 1,
    d: data_lancamento,
    i: Number(id),
    f: filterHash
  };
  return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
}

function decodeTransactionCursor(cursor, expectedFilterHash) {
  if (typeof cursor !== 'string' || cursor.length < 8 || cursor.length > 512) {
    throw transactionBadRequest('INVALID_CURSOR', 'Cursor de paginação inválido');
  }

  let payload;
  try {
    const json = Buffer.from(cursor, 'base64url').toString('utf8');
    payload = JSON.parse(json);
  } catch {
    throw transactionBadRequest('INVALID_CURSOR', 'Cursor de paginação inválido');
  }

  if (
    !payload ||
    payload.v !== 1 ||
    !isValidCivilDate(payload.d) ||
    !Number.isSafeInteger(payload.i) ||
    payload.i <= 0 ||
    typeof payload.f !== 'string' ||
    payload.f !== expectedFilterHash
  ) {
    throw transactionBadRequest(
      'INVALID_CURSOR',
      'Cursor de paginação inválido ou incompatível com os filtros'
    );
  }

  return {
    data_lancamento: payload.d,
    id: payload.i
  };
}

module.exports = {
  decodeTransactionCursor,
  encodeTransactionCursor,
  sha256,
  stableJson,
  transactionFilterHash
};
