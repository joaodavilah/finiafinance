'use strict';

const { HttpError } = require('../lib/httpError');

class TransactionError extends HttpError {
  constructor(status, code, message, details) {
    super(status, code, message, {
      expose: status < 500,
      details
    });
    this.name = 'TransactionError';
  }
}

function transactionValidationError(details, message = 'Dados do lançamento inválidos') {
  return new TransactionError(422, 'TRANSACTION_VALIDATION_FAILED', message, details);
}

function transactionBadRequest(code, message, details) {
  return new TransactionError(400, code, message, details);
}

function transactionConflict(code, message, details) {
  return new TransactionError(409, code, message, details);
}

function transactionNotFound(message = 'Lançamento não encontrado') {
  return new TransactionError(404, 'TRANSACTION_NOT_FOUND', message);
}

function transactionPrecondition(message, details) {
  return new TransactionError(428, 'IMPORT_PREVIEW_REQUIRED', message, details);
}

function transactionPayloadTooLarge(message, details) {
  return new TransactionError(413, 'IMPORT_PAYLOAD_TOO_LARGE', message, details);
}

function transactionTimeout(message = 'O processamento do arquivo excedeu o tempo permitido') {
  return new TransactionError(408, 'IMPORT_TIMEOUT', message);
}

module.exports = {
  TransactionError,
  transactionBadRequest,
  transactionConflict,
  transactionNotFound,
  transactionPayloadTooLarge,
  transactionPrecondition,
  transactionTimeout,
  transactionValidationError
};
