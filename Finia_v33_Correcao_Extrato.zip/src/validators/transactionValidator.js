'use strict';

const { compareCivilDates, isValidCivilDate } = require('../utils/transactionDate');
const { parseMoneyToCents } = require('../utils/transactionMoney');

const MAX_BULK_ITEMS = 300;
const MAX_DESCRIPTION_LENGTH = 150;
const MAX_ORIGIN_LENGTH = 30;
const MAX_ORIGIN_ID_LENGTH = 150;
const MAX_PAGE_SIZE = 100;

function currentCivilDate() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

const CATEGORIES_BY_TYPE = require('../../public/transaction-catalog').types;

const ALL_CATEGORIES = new Set(Object.values(CATEGORIES_BY_TYPE).flat());
const CUSTOM_CATEGORY_PATTERN = /^custom_(entrada|saida)_[a-z0-9_]{1,70}$/;
const ALLOWED_TRANSACTION_FIELDS = new Set([
  'carteira_id',
  'tipo',
  'descricao',
  'descricao_original',
  'valor',
  'categoria',
  'data_lancamento',
  'parcelado',
  'parcelas_total',
  'recorrente',
  'recorrencias_total',
  'origem',
  'origem_id'
]);
const ALLOWED_LIST_FIELDS = new Set([
  'limit',
  'cursor',
  'tipo',
  'categoria',
  'data_inicio',
  'data_fim',
  'origem'
]);

function isPlainObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function fieldError(field, code, message) {
  return { field, code, message };
}

function customCategoryType(category) {
  return typeof category === 'string' ? category.match(CUSTOM_CATEGORY_PATTERN)?.[1] || null : null;
}

function parsePositiveInteger(value) {
  if (typeof value === 'number') {
    return Number.isSafeInteger(value) && value > 0 ? value : null;
  }
  if (typeof value === 'string' && /^[1-9]\d*$/.test(value.trim())) {
    const parsed = Number(value.trim());
    return Number.isSafeInteger(parsed) ? parsed : null;
  }
  return null;
}

function validateUserId(value) {
  return parsePositiveInteger(value);
}

function parseStrictBoolean(value, defaultValue = false) {
  if (value === undefined || value === null || value === '')
    return { ok: true, value: defaultValue };
  if (value === true || value === false) return { ok: true, value };
  if (value === 1 || value === '1' || value === 'true') return { ok: true, value: true };
  if (value === 0 || value === '0' || value === 'false') return { ok: true, value: false };
  return { ok: false, value: defaultValue };
}

function normalizeDescription(value) {
  if (typeof value !== 'string') return null;
  const normalized = value
    .replace(/[\u0000-\u001f\u007f]+/g, ' ')
    .replace(/\s+/gu, ' ')
    .trim();
  return normalized || null;
}

function normalizeOrigin(value, fallback = 'manual') {
  const candidate = value === undefined || value === null || value === '' ? fallback : value;
  if (typeof candidate !== 'string') return null;
  const normalized = candidate.trim().toLowerCase();
  if (!/^[a-z][a-z0-9_-]{0,29}$/.test(normalized)) return null;
  return normalized;
}

function normalizeOriginId(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string') return null;
  const normalized = value.trim();
  if (
    !normalized ||
    normalized.length > MAX_ORIGIN_ID_LENGTH ||
    /[\u0000-\u001f\u007f]/.test(normalized)
  ) {
    return null;
  }
  return normalized;
}

function validateOptionalInteger(raw, field, min, max, errors) {
  if (raw === undefined || raw === null || raw === '') return null;
  const value = parsePositiveInteger(raw);
  if (value === null || value < min || value > max) {
    errors.push(fieldError(field, 'invalid_integer', `Use um inteiro entre ${min} e ${max}`));
    return null;
  }
  return value;
}

function validateTransactionInput(input, options = {}) {
  const { mode = 'create', defaultOrigin = 'manual' } = options;
  const errors = [];

  if (!isPlainObject(input)) {
    return {
      ok: false,
      errors: [fieldError('body', 'invalid_object', 'Envie um objeto JSON válido')]
    };
  }

  for (const key of Object.keys(input)) {
    if (!ALLOWED_TRANSACTION_FIELDS.has(key)) {
      errors.push(fieldError(key, 'unexpected_field', 'Campo não permitido'));
    }
  }

  if (mode === 'update') {
    for (const field of ['origem', 'origem_id', 'descricao_original']) {
      if (Object.hasOwn(input, field)) {
        errors.push(
          fieldError(
            field,
            'immutable_field',
            'A origem do lançamento não pode ser alterada nesta rota'
          )
        );
      }
    }
  }

  const tipo = typeof input.tipo === 'string' ? input.tipo.trim().toLowerCase() : '';
  if (!Object.hasOwn(CATEGORIES_BY_TYPE, tipo)) {
    errors.push(fieldError('tipo', 'invalid_type', 'Use entrada ou saida'));
  }

  const descricao = normalizeDescription(input.descricao);
  if (!descricao) {
    errors.push(fieldError('descricao', 'required', 'Informe a descrição'));
  } else if (descricao.length > MAX_DESCRIPTION_LENGTH) {
    errors.push(
      fieldError(
        'descricao',
        'too_long',
        `A descrição deve ter no máximo ${MAX_DESCRIPTION_LENGTH} caracteres`
      )
    );
  }

  const valorCentavos = parseMoneyToCents(input.valor);
  if (valorCentavos === null) {
    errors.push(
      fieldError(
        'valor',
        'invalid_money',
        'Informe um valor positivo, com até 2 casas decimais e dentro do limite do banco'
      )
    );
  }

  const categoria = typeof input.categoria === 'string' ? input.categoria.trim().toLowerCase() : '';
  const customType = customCategoryType(categoria);
  if (!ALL_CATEGORIES.has(categoria) && !customType) {
    errors.push(fieldError('categoria', 'invalid_category', 'Categoria inválida'));
  } else if (
    Object.hasOwn(CATEGORIES_BY_TYPE, tipo) &&
    !CATEGORIES_BY_TYPE[tipo].includes(categoria) &&
    customType !== tipo
  ) {
    errors.push(
      fieldError('categoria', 'category_type_mismatch', 'Categoria incompatível com o tipo')
    );
  }

  const dataLancamento =
    typeof input.data_lancamento === 'string' ? input.data_lancamento.trim() : '';
  if (!isValidCivilDate(dataLancamento)) {
    errors.push(
      fieldError('data_lancamento', 'invalid_civil_date', 'Use uma data civil válida em AAAA-MM-DD')
    );
  } else if (
    (mode === 'create' || mode === 'update') &&
    compareCivilDates(dataLancamento, currentCivilDate()) > 0
  ) {
    errors.push(
      fieldError(
        'data_lancamento',
        'future_date',
        'A data do lançamento não pode ser posterior a hoje'
      )
    );
  }

  const parsedParcelado = parseStrictBoolean(input.parcelado, false);
  const parsedRecorrente = parseStrictBoolean(input.recorrente, false);
  if (!parsedParcelado.ok) {
    errors.push(fieldError('parcelado', 'invalid_boolean', 'Use true ou false'));
  }
  if (!parsedRecorrente.ok) {
    errors.push(fieldError('recorrente', 'invalid_boolean', 'Use true ou false'));
  }

  const parcelado = parsedParcelado.value;
  const recorrente = parsedRecorrente.value;
  const parcelasInformadas = validateOptionalInteger(
    input.parcelas_total,
    'parcelas_total',
    1,
    60,
    errors
  );
  const recorrenciasInformadas = validateOptionalInteger(
    input.recorrencias_total,
    'recorrencias_total',
    1,
    120,
    errors
  );

  let parcelasTotal = null;
  let recorrenciasTotal = null;

  if (parcelado) {
    if (parcelasInformadas === null || parcelasInformadas < 2) {
      errors.push(
        fieldError('parcelas_total', 'invalid_installments', 'Use entre 2 e 60 parcelas')
      );
    } else {
      parcelasTotal = parcelasInformadas;
    }
  }

  if (recorrente) {
    if (recorrenciasInformadas === null || recorrenciasInformadas < 2) {
      errors.push(
        fieldError('recorrencias_total', 'invalid_recurrences', 'Use entre 2 e 120 recorrências')
      );
    } else {
      recorrenciasTotal = recorrenciasInformadas;
    }
  }

  if (parcelado && recorrente) {
    errors.push(
      fieldError('recorrente', 'mutually_exclusive', 'Use parcelamento ou recorrência, não ambos')
    );
  }

  if (mode === 'update' && (parcelado || recorrente)) {
    errors.push(
      fieldError(
        parcelado ? 'parcelado' : 'recorrente',
        'series_update_not_supported',
        'Edite apenas um lançamento existente; séries não podem ser recriadas nesta rota'
      )
    );
  }

  const repeatCount = parcelado ? parcelasTotal : recorrente ? recorrenciasTotal : 1;
  if (descricao && Number.isInteger(repeatCount) && repeatCount > 1) {
    const suffix = ` (${repeatCount}/${repeatCount})`;
    if (descricao.length + suffix.length > MAX_DESCRIPTION_LENGTH) {
      errors.push(
        fieldError(
          'descricao',
          'series_description_too_long',
          `Reduza a descrição para no máximo ${MAX_DESCRIPTION_LENGTH - suffix.length} caracteres`
        )
      );
    }
  }

  const origem = normalizeOrigin(input.origem, defaultOrigin);
  if (!origem || origem.length > MAX_ORIGIN_LENGTH) {
    errors.push(fieldError('origem', 'invalid_origin', 'Origem inválida'));
  }

  const origemId = normalizeOriginId(input.origem_id);
  if (
    input.origem_id !== undefined &&
    input.origem_id !== null &&
    input.origem_id !== '' &&
    !origemId
  ) {
    errors.push(
      fieldError(
        'origem_id',
        'invalid_origin_id',
        `O identificador da origem deve ter no máximo ${MAX_ORIGIN_ID_LENGTH} caracteres e não conter controles`
      )
    );
  }

  const descricaoOriginal = input.descricao_original == null ? null : normalizeDescription(input.descricao_original);
  if (input.descricao_original != null && (!descricaoOriginal || descricaoOriginal.length > 1000)) errors.push(fieldError('descricao_original', 'invalid_original', 'Descrição original inválida (máximo 1000 caracteres)'));
  const carteiraId = input.carteira_id == null ? null : validateUserId(input.carteira_id);
  if (input.carteira_id != null && !carteiraId)
    errors.push(fieldError('carteira_id', 'invalid_wallet', 'Carteira inválida'));
  if (errors.length) return { ok: false, errors };

  return {
    ok: true,
    value: {
      tipo,
      descricao,
      descricao_original: descricaoOriginal,
      valor: valorCentavos / 100,
      valor_centavos: valorCentavos,
      carteira_id: carteiraId,
      categoria,
      data_lancamento: dataLancamento,
      parcelado,
      parcelas_total: parcelasTotal,
      recorrente,
      recorrencias_total: recorrenciasTotal,
      origem,
      origem_id: origemId
    },
    errors: []
  };
}

function oneQueryValue(query, field, errors) {
  const value = query[field];
  if (Array.isArray(value) || (value !== undefined && typeof value !== 'string')) {
    errors.push(fieldError(field, 'invalid_query_value', 'Use um único valor textual'));
    return undefined;
  }
  return value;
}

function validateTransactionListQuery(query) {
  const errors = [];
  if (!isPlainObject(query)) {
    return { ok: false, errors: [fieldError('query', 'invalid_object', 'Filtros inválidos')] };
  }

  for (const key of Object.keys(query)) {
    if (!ALLOWED_LIST_FIELDS.has(key)) {
      errors.push(fieldError(key, 'unexpected_filter', 'Filtro não permitido'));
    }
  }

  const rawLimit = oneQueryValue(query, 'limit', errors);
  let limit = 50;
  if (rawLimit !== undefined && rawLimit !== '') {
    const parsedLimit = parsePositiveInteger(rawLimit);
    if (parsedLimit === null || parsedLimit > MAX_PAGE_SIZE) {
      errors.push(fieldError('limit', 'invalid_limit', `Use um limite entre 1 e ${MAX_PAGE_SIZE}`));
    } else {
      limit = parsedLimit;
    }
  }

  const rawTipo = oneQueryValue(query, 'tipo', errors);
  const tipo = rawTipo ? rawTipo.trim().toLowerCase() : null;
  if (tipo && !Object.hasOwn(CATEGORIES_BY_TYPE, tipo)) {
    errors.push(fieldError('tipo', 'invalid_type', 'Use entrada ou saida'));
  }

  const rawCategoria = oneQueryValue(query, 'categoria', errors);
  const categoria = rawCategoria ? rawCategoria.trim().toLowerCase() : null;
  const customType = customCategoryType(categoria);
  if (categoria && !ALL_CATEGORIES.has(categoria) && !customType) {
    errors.push(fieldError('categoria', 'invalid_category', 'Categoria inválida'));
  } else if (
    categoria &&
    tipo &&
    Object.hasOwn(CATEGORIES_BY_TYPE, tipo) &&
    !CATEGORIES_BY_TYPE[tipo].includes(categoria) &&
    customType !== tipo
  ) {
    errors.push(
      fieldError('categoria', 'category_type_mismatch', 'Categoria incompatível com o tipo')
    );
  }

  const rawStart = oneQueryValue(query, 'data_inicio', errors);
  const rawEnd = oneQueryValue(query, 'data_fim', errors);
  const dataInicio = rawStart ? rawStart.trim() : null;
  const dataFim = rawEnd ? rawEnd.trim() : null;
  if (dataInicio && !isValidCivilDate(dataInicio)) {
    errors.push(fieldError('data_inicio', 'invalid_civil_date', 'Use AAAA-MM-DD'));
  }
  if (dataFim && !isValidCivilDate(dataFim)) {
    errors.push(fieldError('data_fim', 'invalid_civil_date', 'Use AAAA-MM-DD'));
  }
  if (dataInicio && dataFim && isValidCivilDate(dataInicio) && isValidCivilDate(dataFim)) {
    if (compareCivilDates(dataInicio, dataFim) > 0) {
      errors.push(
        fieldError('data_fim', 'invalid_date_range', 'A data final deve ser posterior à inicial')
      );
    }
  }

  const rawOrigin = oneQueryValue(query, 'origem', errors);
  const origem = rawOrigin ? normalizeOrigin(rawOrigin, null) : null;
  if (rawOrigin && !origem) {
    errors.push(fieldError('origem', 'invalid_origin', 'Origem inválida'));
  }

  const cursor = oneQueryValue(query, 'cursor', errors) || null;
  if (cursor && (cursor.length < 8 || cursor.length > 512)) {
    errors.push(fieldError('cursor', 'invalid_cursor', 'Cursor inválido'));
  }

  if (errors.length) return { ok: false, errors };

  return {
    ok: true,
    value: {
      limit,
      cursor,
      filters: {
        tipo,
        categoria,
        data_inicio: dataInicio,
        data_fim: dataFim,
        origem
      }
    },
    errors: []
  };
}

function validateIdempotencyKey(value) {
  if (typeof value !== 'string') return null;
  const normalized = value.trim();
  if (normalized.length < 8 || normalized.length > 128 || !/^[\x21-\x7e]+$/.test(normalized))
    return null;
  return normalized;
}

function validatePreviewHash(value) {
  return typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value) ? value.toLowerCase() : null;
}

module.exports = {
  ALL_CATEGORIES,
  CATEGORIES_BY_TYPE,
  MAX_BULK_ITEMS,
  MAX_DESCRIPTION_LENGTH,
  MAX_PAGE_SIZE,
  fieldError,
  isPlainObject,
  normalizeDescription,
  normalizeOrigin,
  parsePositiveInteger,
  parseStrictBoolean,
  validateIdempotencyKey,
  validatePreviewHash,
  validateTransactionInput,
  validateTransactionListQuery,
  validateUserId
};
