'use strict';

const crypto = require('crypto');
const { PluggyClientError } = require('../integrations/pluggy/errors');
const { tryMapPluggyTransaction } = require('../integrations/pluggy/transactionMapper');
const { BankRepositoryError } = require('../repositories/bankRepository');

class BankServiceError extends Error {
  constructor(code, publicMessage, statusCode = 500, options = {}) {
    super(
      options.internalMessage || publicMessage,
      options.cause ? { cause: options.cause } : undefined
    );
    this.name = 'BankServiceError';
    this.code = code;
    this.publicMessage = publicMessage;
    this.statusCode = statusCode;
    this.status = statusCode;
    this.expose = true;
  }
}

function noop() {}

function normalizeLogger(logger) {
  return {
    info: typeof logger?.info === 'function' ? logger.info.bind(logger) : noop,
    warn: typeof logger?.warn === 'function' ? logger.warn.bind(logger) : noop,
    error: typeof logger?.error === 'function' ? logger.error.bind(logger) : noop
  };
}

function requireUserId(value) {
  const userId = Number(value);
  if (!Number.isSafeInteger(userId) || userId < 1) {
    throw new BankServiceError('AUTH_REQUIRED', 'Autenticacao obrigatoria', 401);
  }
  return userId;
}

function requireItemId(value) {
  const itemId = String(value || '').trim();
  if (!itemId || itemId.length > 150) {
    throw new BankServiceError('BANK_ITEM_INVALID', 'Identificador bancario invalido', 400);
  }
  return itemId;
}

function requireIdempotencyKey(value) {
  const key = String(value || '').trim();
  if (!/^[A-Za-z0-9._:-]{8,128}$/.test(key)) {
    throw new BankServiceError(
      'BANK_IDEMPOTENCY_KEY_REQUIRED',
      'Envie uma chave Idempotency-Key valida para sincronizar',
      400
    );
  }
  return key;
}

function isoDate(value, name) {
  if (!value) return null;
  const normalized = String(value).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(normalized)) {
    throw new BankServiceError('BANK_SYNC_DATE_INVALID', `${name} invalida`, 400);
  }
  const date = new Date(`${normalized}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== normalized) {
    throw new BankServiceError('BANK_SYNC_DATE_INVALID', `${name} invalida`, 400);
  }
  return normalized;
}

function defaultDateFrom(days) {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - days);
  return date.toISOString().slice(0, 10);
}

function hashRequest(value) {
  return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

function serviceError(error) {
  if (
    error instanceof BankServiceError ||
    error instanceof BankRepositoryError ||
    error instanceof PluggyClientError
  ) {
    return error;
  }
  return new BankServiceError(
    'BANK_OPERATION_FAILED',
    'Nao foi possivel concluir a operacao bancaria',
    500,
    { cause: error }
  );
}

function createBankService(options) {
  const repository = options?.repository;
  const pluggyClient = options?.pluggyClient;
  if (!repository || typeof repository.getOwnedConnection !== 'function') {
    throw new TypeError('createBankService requires a bank repository');
  }
  if (!pluggyClient || typeof pluggyClient.getItem !== 'function') {
    throw new TypeError('createBankService requires a Pluggy client');
  }

  const logger = normalizeLogger(options.logger);
  const randomUUID = options.randomUUID || crypto.randomUUID;
  const syncLeaseSeconds = Number(options.syncLeaseSeconds || 180);
  const defaultLookbackDays = Number(options.defaultLookbackDays || 180);
  const connectTokenOptions = Object.freeze({ ...(options.connectTokenOptions || {}) });
  const widgetConnectOptions = Object.freeze({
    includeSandbox: connectTokenOptions.includeSandbox === true,
    ...(Array.isArray(connectTokenOptions.countries)
      ? { countries: Object.freeze(connectTokenOptions.countries.map(String).slice(0, 10)) }
      : {}),
    ...(typeof connectTokenOptions.language === 'string'
      ? { language: connectTokenOptions.language }
      : {}),
    ...(Array.isArray(connectTokenOptions.products)
      ? { products: Object.freeze(connectTokenOptions.products.map(String).slice(0, 10)) }
      : {}),
    ...(Array.isArray(connectTokenOptions.connectorTypes)
      ? {
          connectorTypes: Object.freeze(connectTokenOptions.connectorTypes.map(String).slice(0, 10))
        }
      : {})
  });

  if (!Number.isInteger(syncLeaseSeconds) || syncLeaseSeconds < 30 || syncLeaseSeconds > 3600) {
    throw new TypeError('syncLeaseSeconds must be between 30 and 3600');
  }
  if (
    !Number.isInteger(defaultLookbackDays) ||
    defaultLookbackDays < 1 ||
    defaultLookbackDays > 3650
  ) {
    throw new TypeError('defaultLookbackDays must be between 1 and 3650');
  }

  function assertExternalOwner(item, userId, expectedItemId) {
    if (!item || typeof item !== 'object') {
      throw new BankServiceError(
        'BANK_PROVIDER_INVALID_ITEM',
        'O provedor bancario retornou uma conexao invalida',
        502
      );
    }
    if (item.id && String(item.id) !== String(expectedItemId)) {
      throw new BankServiceError(
        'BANK_PROVIDER_ITEM_MISMATCH',
        'O provedor bancario retornou uma conexao diferente da solicitada',
        502
      );
    }
    if (String(item.clientUserId || '') !== String(userId)) {
      throw new BankServiceError(
        'BANK_ITEM_OWNERSHIP_MISMATCH',
        'A conexao bancaria nao pertence ao usuario autenticado',
        403
      );
    }
  }

  function connectorName(item) {
    return String(
      item.connector?.name ||
        item.connectorName ||
        item.connector?.institutionName ||
        item.name ||
        'Instituicao financeira'
    )
      .trim()
      .slice(0, 150);
  }

  async function getStatus(input) {
    const userId = requireUserId(input?.userId);
    return {
      configured: true,
      connections: await repository.listConnections(userId)
    };
  }

  async function createConnectToken(input) {
    const userId = requireUserId(input?.userId);
    const itemId = input.itemId ? requireItemId(input.itemId) : null;

    if (itemId) {
      const local = await repository.getOwnedConnection(userId, itemId);
      if (!local) {
        throw new BankServiceError(
          'BANK_CONNECTION_NOT_FOUND',
          'Conexao bancaria nao encontrada',
          404
        );
      }
      const external = await pluggyClient.getItem(itemId, { signal: input.signal });
      assertExternalOwner(external, userId, itemId);
    }

    try {
      const response = await pluggyClient.createConnectToken({
        ...widgetConnectOptions,
        clientUserId: String(userId),
        itemId,
        avoidDuplicates: true,
        signal: input.signal
      });
      const connectToken = response?.accessToken || response?.connectToken || response?.token;
      if (!connectToken) {
        throw new BankServiceError(
          'BANK_PROVIDER_INVALID_TOKEN',
          'O provedor bancario nao retornou um token de conexao',
          502
        );
      }
      return { connectToken, itemId, connectOptions: widgetConnectOptions };
    } catch (error) {
      throw serviceError(error);
    }
  }

  async function associateConnection(input) {
    const userId = requireUserId(input?.userId);
    const itemId = requireItemId(input?.itemId);

    try {
      const external = await pluggyClient.getItem(itemId, { signal: input.signal });
      assertExternalOwner(external, userId, itemId);
      const connection = await repository.associateVerifiedItem({
        userId,
        itemId,
        clientUserId: String(external.clientUserId),
        connectorName: connectorName(external)
      });
      return { connection };
    } catch (error) {
      throw serviceError(error);
    }
  }

  async function syncConnection(input) {
    const userId = requireUserId(input?.userId);
    const itemId = requireItemId(input?.itemId);
    const idempotencyKey = requireIdempotencyKey(input?.idempotencyKey);
    const dateFrom =
      isoDate(input.dateFrom, 'Data inicial') || defaultDateFrom(defaultLookbackDays);
    const dateTo = isoDate(input.dateTo, 'Data final');
    if (dateTo && dateFrom > dateTo) {
      throw new BankServiceError(
        'BANK_SYNC_DATE_RANGE_INVALID',
        'A data inicial deve ser anterior a data final',
        400
      );
    }

    const requestHash = hashRequest({ itemId, dateFrom, dateTo });
    const priorBatch = await repository.getImportBatch(userId, idempotencyKey);
    if (priorBatch) {
      if (priorBatch.request_hash !== requestHash) {
        throw new BankServiceError(
          'BANK_IDEMPOTENCY_CONFLICT',
          'A chave de idempotencia ja foi usada para outra operacao',
          409
        );
      }
      if (priorBatch.status === 'completed') {
        return {
          batchId: priorBatch.id,
          reused: true,
          processed: Number(priorBatch.processados),
          inserted: Number(priorBatch.inseridos),
          updated: Number(priorBatch.atualizados),
          skipped: Number(priorBatch.ignorados)
        };
      }
    }

    const lockToken = randomUUID();
    let bankConnection = null;
    let batch = null;
    let lastCursor = null;

    try {
      bankConnection = await repository.claimSync({
        userId,
        itemId,
        lockToken,
        leaseSeconds: syncLeaseSeconds
      });

      batch = await repository.beginImportBatch({
        userId,
        connectionId: bankConnection.id,
        idempotencyKey,
        requestHash
      });
      if (batch.reused) {
        await repository.completeSync({
          userId,
          connectionId: bankConnection.id,
          lockToken,
          cursor: batch.ultimo_cursor
        });
        return {
          batchId: batch.id,
          reused: true,
          processed: Number(batch.processados),
          inserted: Number(batch.inseridos),
          updated: Number(batch.atualizados),
          skipped: Number(batch.ignorados)
        };
      }

      const external = await pluggyClient.getItem(itemId, { signal: input.signal });
      assertExternalOwner(external, userId, itemId);
      const accounts = await pluggyClient.listAccounts(itemId, { signal: input.signal });

      for (const account of accounts) {
        const accountId = String(account?.id || '').trim();
        if (!accountId) {
          logger.warn('Skipping invalid bank account', {
            batchId: batch.id,
            code: 'BANK_ACCOUNT_INVALID_ID'
          });
          await repository.upsertTransactionsPage({
            userId,
            connectionId: bankConnection.id,
            batchId: batch.id,
            transactions: [],
            skipped: 1,
            cursor: lastCursor
          });
          continue;
        }

        for await (const page of pluggyClient.paginateTransactions({
          accountId,
          dateFrom,
          dateTo,
          signal: input.signal
        })) {
          const mapped = [];
          const mappingErrors = new Map();
          for (const transaction of page.results) {
            const result = tryMapPluggyTransaction(transaction, {
              accountId,
              accountType: account.type,
              connectionId: bankConnection.id
            });
            if (result.value) mapped.push(result.value);
            else
              mappingErrors.set(result.error.code, (mappingErrors.get(result.error.code) || 0) + 1);
          }

          lastCursor = JSON.stringify({ accountId, after: page.nextCursor || null });
          await repository.upsertTransactionsPage({
            userId,
            connectionId: bankConnection.id,
            batchId: batch.id,
            transactions: mapped,
            skipped: page.results.length - mapped.length,
            cursor: lastCursor
          });
          await repository.heartbeatSync({
            userId,
            connectionId: bankConnection.id,
            lockToken,
            leaseSeconds: syncLeaseSeconds
          });

          if (mappingErrors.size) {
            logger.warn('Some bank transactions were rejected by the mapper', {
              batchId: batch.id,
              mappingErrors: Object.fromEntries(mappingErrors)
            });
          }
        }
      }

      const summary = await repository.completeImportBatch(userId, batch.id);
      await repository.completeSync({
        userId,
        connectionId: bankConnection.id,
        lockToken,
        cursor: lastCursor
      });

      return {
        batchId: summary.id,
        reused: false,
        processed: Number(summary.processados),
        inserted: Number(summary.inseridos),
        updated: Number(summary.atualizados),
        skipped: Number(summary.ignorados)
      };
    } catch (rawError) {
      const error = serviceError(rawError);
      if (batch?.id) {
        try {
          await repository.failImportBatch(userId, batch.id, error.code);
        } catch (cleanupError) {
          logger.error('Failed to mark import batch as failed', { code: cleanupError.code });
        }
      }
      if (bankConnection?.id) {
        try {
          await repository.failSync({
            userId,
            connectionId: bankConnection.id,
            lockToken,
            errorCode: error.code
          });
        } catch (cleanupError) {
          logger.error('Failed to release bank sync lease', { code: cleanupError.code });
        }
      }
      throw error;
    }
  }

  async function disconnectConnection(input) {
    const userId = requireUserId(input?.userId);
    const itemId = requireItemId(input?.itemId);
    let marked = false;

    try {
      await repository.markDisconnecting(userId, itemId);
      marked = true;

      try {
        const external = await pluggyClient.getItem(itemId, { signal: input.signal });
        assertExternalOwner(external, userId, itemId);
        await pluggyClient.deleteItem(itemId, { signal: input.signal });
      } catch (error) {
        if (!(error instanceof PluggyClientError && error.code === 'BANK_ITEM_NOT_FOUND')) {
          throw error;
        }
      }

      await repository.removeConnection({
        userId,
        itemId,
        purgeImportedTransactions: input.purgeImportedTransactions === true
      });
      return {
        disconnected: true,
        importedTransactionsPurged: input.purgeImportedTransactions === true
      };
    } catch (rawError) {
      const error = serviceError(rawError);
      if (marked) {
        try {
          await repository.restoreAfterDisconnectFailure(userId, itemId, error.code);
        } catch (cleanupError) {
          logger.error('Failed to restore bank connection status', { code: cleanupError.code });
        }
      }
      throw error;
    }
  }

  return {
    associateConnection,
    createConnectToken,
    disconnectConnection,
    getStatus,
    syncConnection
  };
}

module.exports = {
  BankServiceError,
  createBankService,
  serviceError
};
