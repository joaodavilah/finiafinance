'use strict';

const { badRequest, notFound } = require('../lib/httpError');
const { normalizeName } = require('./authService');

const MAX_AVATAR_BYTES = 1024 * 1024;
const AVATAR_TYPES = Object.freeze({
  'image/png': (buffer) =>
    buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex')),
  'image/jpeg': (buffer) =>
    buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff,
  'image/webp': (buffer) =>
    buffer.length >= 12 &&
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP'
});

function presentProfile(row) {
  return {
    id: Number(row.id),
    nome_completo: row.nome_completo,
    email: row.email,
    plano: row.plano,
    avatar: row.avatar_updated_at
      ? { presente: true, atualizado_em: row.avatar_updated_at }
      : { presente: false, atualizado_em: null }
  };
}

function createProfileService(repository) {
  if (!repository?.findByUserId) throw new TypeError('profile repository obrigatorio');

  async function getForUser(userId) {
    const row = await repository.findByUserId(userId);
    if (!row) throw notFound('Usuario nao encontrado');
    return presentProfile(row);
  }

  async function updateName(userId, value) {
    const name = normalizeName(value);
    const updated = await repository.updateName(userId, name);
    if (!updated) throw notFound('Usuario nao encontrado');
    return getForUser(userId);
  }

  async function saveAvatar(userId, file) {
    const imageData = file?.buffer;
    const mimeType = String(file?.mimetype || '').toLowerCase();
    if (
      !Buffer.isBuffer(imageData) ||
      imageData.length < 16 ||
      imageData.length > MAX_AVATAR_BYTES
    ) {
      throw badRequest('INVALID_AVATAR', 'Escolha uma imagem de ate 1 MB');
    }
    if (!AVATAR_TYPES[mimeType] || !AVATAR_TYPES[mimeType](imageData)) {
      throw badRequest('INVALID_AVATAR', 'Use uma imagem PNG, JPEG ou WebP valida');
    }
    const profile = await repository.upsertAvatar({ userId, mimeType, imageData });
    return presentProfile(profile);
  }

  async function getAvatar(userId) {
    const avatar = await repository.getAvatar(userId);
    if (!avatar) throw notFound('Foto de perfil nao encontrada');
    return {
      mimeType: avatar.mime_type,
      data: avatar.image_data,
      byteSize: Number(avatar.byte_size),
      updatedAt: avatar.updated_at
    };
  }

  async function removeAvatar(userId) {
    await repository.deleteAvatar(userId);
    return { ok: true };
  }

  return Object.freeze({ getForUser, updateName, saveAvatar, getAvatar, removeAvatar });
}

module.exports = {
  MAX_AVATAR_BYTES,
  createProfileService
};
