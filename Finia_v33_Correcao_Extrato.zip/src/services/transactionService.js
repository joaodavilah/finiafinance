'use strict';

const crypto = require('crypto');
const {
  decodeTransactionCursor,
  encodeTransactionCursor,
  transactionFilterHash
} = require('../utils/transactionCursor');
const { addMonthsCivil } = require('../utils/transactionDate');
const {
  buildEncodedOriginId,
  createPreviewHash,
  keyDigest,
  publicTransactionShape,
  safeHashEqual,
  sourceDigest
} = require('../utils/transactionImportIdentity');
const { centsToDecimal, splitCents } = require('../utils/transactionMoney');
const {
  TransactionError,
  transactionBadRequest,
  transactionConflict,
  transactionNotFound,
  transactionPrecondition,
  transactionValidationError
} = require('../utils/transactionErrors');
const {
  MAX_BULK_ITEMS,
  fieldError,
  isPlainObject,
  validateIdempotencyKey,
  validatePreviewHash,
  validateTransactionInput,
  validateTransactionListQuery,
  validateUserId
} = require('../validators/transactionValidator');

const MAX_EXPANDED_IMPORT_ROWS = 1000;

function requireUserId(rawUserId) {
  const userId = validateUserId(rawUserId);
  if (!userId) {
    throw new TransactionError(401, 'INVALID_USER_CONTEXT', 'Sessão inválida ou expirada');
  }
  return userId;
}

function requireTransactionId(rawId) {
  const id = validateUserId(rawId);
  if (!id) throw transactionBadRequest('INVALID_TRANSACTION_ID', 'ID do lançamento inválido');
  return id;
}

function publicCanonical(transaction) {
  return publicTransactionShape(transaction);
}

function scheduleCount(transaction) {
  if (transaction.parcelado) return transaction.parcelas_total;
  if (transaction.recorrente) return transaction.recorrencias_total;
  return 1;
}

function seriesOriginId(transaction, occurrence) {
  if (!transaction.origem_id) return null;
  if (scheduleCount(transaction) === 1) return transaction.origem_id;
  return `s.${sourceDigest(transaction, 0)}.${occurrence}`;
}

function expandTransaction(transaction, userId, options = {}) {
  const count = scheduleCount(transaction);
  const installmentValues = transaction.parcelado
    ? splitCents(transaction.valor_centavos, count)
    : null;
  const installmentGroup = transaction.parcelado ? crypto.randomUUID() : null;
  const recurrenceGroup = transaction.recorrente ? crypto.randomUUID() : null;
  const rows = [];

  for (let index = 0; index < count; index++) {
    const occurrence = index + 1;
    const suffix = count > 1 ? ` (${occurrence}/${count})` : '';
    const civilDate = addMonthsCivil(transaction.data_lancamento, index);
    if (!civilDate) {
      throw transactionValidationError([
        fieldError(
          'data_lancamento',
          'date_out_of_range',
          'A série ultrapassa o intervalo válido de datas'
        )
      ]);
    }

    const cents = transaction.parcelado ? installmentValues[index] : transaction.valor_centavos;
    const generatedOriginId =
      typeof options.originIdFactory === 'function'
        ? options.originIdFactory(occurrence)
        : seriesOriginId(transaction, occurrence);

    rows.push({
      usuario_id: userId,
      carteira_id: transaction.carteira_id,
      data_compra: transaction.recorrente ? civilDate : transaction.data_lancamento,
      tipo: transaction.tipo,
      descricao: `${transaction.descricao}${suffix}`,
      descricao_original: transaction.descricao_original || null,
      valor: centsToDecimal(cents),
      categoria: transaction.categoria,
      data_lancamento: civilDate,
      parcelado: transaction.parcelado,
      parcela_atual: transaction.parcelado ? occurrence : null,
      parcelas_total: transaction.parcelado ? count : null,
      grupo_parcelamento: installmentGroup,
      recorrente: transaction.recorrente,
      recorrencia_atual: transaction.recorrente ? occurrence : null,
      recorrencias_total: transaction.recorrente ? count : null,
      grupo_recorrencia: recurrenceGroup,
      origem: transaction.origem,
      origem_id: generatedOriginId
    });
  }
  return rows;
}

function originKeys(transactions) {
  return transactions.flatMap((transaction, index) => {
    if (!transaction || !transaction.origem_id) return [];
    return [
      {
        index,
        origem: transaction.origem,
        rawOriginId: transaction.origem_id,
        sourceDigest: sourceDigest(transaction, index)
      }
    ];
  });
}

function duplicateIndexes(keys, matches) {
  const duplicates = new Set();
  for (const key of keys) {
    const matched = matches.some(
      (row) =>
        row.origem === key.origem &&
        (row.origem_id === key.rawOriginId || row.sourceDigest === key.sourceDigest)
    );
    if (matched) duplicates.add(key.index);
  }
  return duplicates;
}

function normalizeParserErrors(errors) {
  if (!Array.isArray(errors)) return [];
  return errors.slice(0, 100).map((error) => ({
    index: Number.isInteger(error?.index) ? error.index : null,
    row: Number.isInteger(error?.row) ? error.row : undefined,
    field: typeof error?.field === 'string' ? error.field : 'row',
    code: typeof error?.code === 'string' ? error.code : 'parse_error',
    message:
      typeof error?.message === 'string' ? error.message : 'Não foi possível interpretar esta linha'
  }));
}

function createTransactionService(repository) {
  if (!repository) throw new TypeError('createTransactionService requires a repository');

  async function list(rawUserId, rawQuery = {}) {
    const userId = requireUserId(rawUserId);
    const validation = validateTransactionListQuery(rawQuery);
    if (!validation.ok) {
      throw transactionBadRequest(
        'INVALID_TRANSACTION_FILTERS',
        'Filtros de lançamentos inválidos',
        validation.errors
      );
    }

    const { limit, filters } = validation.value;
    const filterHash = transactionFilterHash(filters);
    const cursor = validation.value.cursor
      ? decodeTransactionCursor(validation.value.cursor, filterHash)
      : null;
    const rows = await repository.listByUser({ userId, limit, filters, cursor });
    const hasMore = rows.length > limit;
    const items = hasMore ? rows.slice(0, limit) : rows;
    const last = items[items.length - 1];

    return {
      items,
      next_cursor:
        hasMore && last
          ? encodeTransactionCursor({
              data_lancamento: last.data_lancamento,
              id: last.id,
              filterHash
            })
          : null,
      has_more: hasMore,
      limit
    };
  }

  async function create(rawUserId, body) {
    const userId = requireUserId(rawUserId);
    const validation = validateTransactionInput(body, { mode: 'create', defaultOrigin: 'manual' });
    if (!validation.ok) throw transactionValidationError(validation.errors);
    const transaction = validation.value;

    try {
      return await repository.withTransaction(async (connection) => {
        if (!(await repository.lockUser(connection, userId))) {
          throw new TransactionError(401, 'INVALID_USER_CONTEXT', 'Sessão inválida ou expirada');
        }

        if (transaction.origem_id) {
          const keys = originKeys([transaction]);
          const matches = await repository.findOriginMatches(connection, userId, keys);
          if (matches.length) {
            throw transactionConflict(
              'DUPLICATE_TRANSACTION_ORIGIN',
              'Este lançamento de origem externa já foi importado'
            );
          }
        }

        const rows = expandTransaction(transaction, userId);
        const result = await repository.insertRows(connection, rows);
        return {
          id: result.insertId,
          created: result.affectedRows
        };
      });
    } catch (error) {
      if (error?.code === 'ER_DUP_ENTRY') {
        throw transactionConflict(
          'DUPLICATE_TRANSACTION_ORIGIN',
          'Este lançamento de origem externa já foi importado'
        );
      }
      throw error;
    }
  }

  async function update(rawUserId, rawId, body) {
    const userId = requireUserId(rawUserId);
    const id = requireTransactionId(rawId);
    const validation = validateTransactionInput(body, { mode: 'update', defaultOrigin: 'manual' });
    if (!validation.ok) throw transactionValidationError(validation.errors);

    const transaction = validation.value;
    const updated = await repository.updateById(userId, id, {
      tipo: transaction.tipo,
      descricao: transaction.descricao,
      valor: centsToDecimal(transaction.valor_centavos),
      carteira_id: transaction.carteira_id,
      categoria: transaction.categoria,
      data_lancamento: transaction.data_lancamento
    });
    if (!updated) throw transactionNotFound();
    return { ok: true };
  }

  async function remove(rawUserId, rawId) {
    const userId = requireUserId(rawUserId);
    const id = requireTransactionId(rawId);
    const deleted = await repository.deleteById(userId, id);
    if (!deleted) throw transactionNotFound();
    return { ok: true };
  }

  async function previewImport(rawUserId, rawItems, options = {}) {
    const userId = requireUserId(rawUserId);
    if (!Array.isArray(rawItems)) {
      throw transactionBadRequest(
        'INVALID_IMPORT_ITEMS',
        'Envie items como uma lista de lançamentos'
      );
    }
    if (!rawItems.length) {
      throw transactionBadRequest(
        'EMPTY_IMPORT',
        'Nenhum lançamento foi enviado para pré-visualização'
      );
    }
    if (rawItems.length > MAX_BULK_ITEMS) {
      throw new TransactionError(
        413,
        'TOO_MANY_IMPORT_ITEMS',
        'A importação excede o limite de itens',
        {
          max_items: MAX_BULK_ITEMS
        }
      );
    }

    const normalized = [];
    const errors = normalizeParserErrors(options.preErrors);
    const explicitOriginSeen = new Map();

    rawItems.forEach((rawItem, index) => {
      const input = isPlainObject(rawItem) ? { ...rawItem } : rawItem;
      if (isPlainObject(input) && !input.origem && options.defaultOrigin) {
        input.origem = options.defaultOrigin;
      }
      const validation = validateTransactionInput(input, {
        mode: 'import',
        defaultOrigin: options.defaultOrigin || 'import'
      });
      if (!validation.ok) {
        for (const error of validation.errors) errors.push({ index, ...error });
        return;
      }

      const transaction = validation.value;
      normalized[index] = transaction;
      if (transaction.origem_id) {
        const key = `${transaction.origem}\u0000${transaction.origem_id}`;
        if (explicitOriginSeen.has(key)) {
          errors.push({
            index,
            field: 'origem_id',
            code: 'duplicate_origin_in_payload',
            message: `Origem repetida no mesmo lote; primeira ocorrência no item ${explicitOriginSeen.get(key)}`
          });
        } else {
          explicitOriginSeen.set(key, index);
        }
      }
    });

    const validTransactions = normalized.filter(Boolean);
    const expandedCount = validTransactions.reduce(
      (sum, transaction) => sum + scheduleCount(transaction),
      0
    );
    if (expandedCount > MAX_EXPANDED_IMPORT_ROWS) {
      errors.push({
        index: null,
        field: 'items',
        code: 'expanded_import_too_large',
        message: `Parcelamentos e recorrências expandem o lote além de ${MAX_EXPANDED_IMPORT_ROWS} linhas`
      });
    }

    const keys = originKeys(normalized);
    const matches = keys.length ? await repository.findOriginMatchesByUser(userId, keys) : [];
    const existingDuplicates = duplicateIndexes(keys, matches);
    const previewHash = createPreviewHash(validTransactions);

    const result = {
      ok: errors.length === 0,
      preview_hash: previewHash,
      items: validTransactions.map(publicCanonical),
      valid_count: validTransactions.length,
      error_count: errors.length,
      duplicate_count: existingDuplicates.size,
      will_insert_count: validTransactions.length - existingDuplicates.size,
      expanded_count: expandedCount,
      duplicate_indexes: [...existingDuplicates].sort((left, right) => left - right),
      errors: errors.slice(0, 100),
      warnings: Array.isArray(options.warnings) ? options.warnings.slice(0, 50) : []
    };
    Object.defineProperties(result, {
      _normalized: { value: normalized, enumerable: false },
      _existingDuplicates: { value: existingDuplicates, enumerable: false }
    });
    return result;
  }

  async function importBulk(rawUserId, envelope, rawIdempotencyKey, options = {}) {
    const userId = requireUserId(rawUserId);
    if (!isPlainObject(envelope)) {
      throw transactionBadRequest('INVALID_IMPORT_BODY', 'Envie um objeto de importação válido');
    }
    const unexpected = Object.keys(envelope).filter(
      (key) => !['items', 'preview_hash'].includes(key)
    );
    if (unexpected.length) {
      throw transactionBadRequest(
        'INVALID_IMPORT_BODY',
        'A importação contém campos não permitidos',
        {
          fields: unexpected
        }
      );
    }

    const idempotencyKey = validateIdempotencyKey(rawIdempotencyKey);
    if (!idempotencyKey) {
      throw transactionBadRequest(
        'INVALID_IDEMPOTENCY_KEY',
        'Envie Idempotency-Key com 8 a 128 caracteres ASCII visíveis'
      );
    }

    const suppliedPreviewHash = validatePreviewHash(envelope.preview_hash);
    if (!suppliedPreviewHash) {
      throw transactionPrecondition('Faça a pré-visualização do lote antes de gravar');
    }

    const preview = await previewImport(userId, envelope.items, options);
    if (!preview.ok) {
      throw transactionValidationError(
        {
          preview_hash: preview.preview_hash,
          errors: preview.errors,
          warnings: preview.warnings
        },
        'A importação contém erros; nenhum lançamento foi gravado'
      );
    }
    if (!safeHashEqual(suppliedPreviewHash, preview.preview_hash)) {
      throw transactionPrecondition('O lote mudou após a pré-visualização; gere uma nova prévia', {
        expected_preview_hash: preview.preview_hash
      });
    }

    const digest = keyDigest(idempotencyKey);
    const previewDigest = preview.preview_hash.slice(0, 24);
    const transactions = preview._normalized;

    try {
      return await repository.withTransaction(async (connection) => {
        if (!(await repository.lockUser(connection, userId))) {
          throw new TransactionError(401, 'INVALID_USER_CONTEXT', 'Sessão inválida ou expirada');
        }

        const idempotencyRecords = await repository.findIdempotencyRecords(
          connection,
          userId,
          digest
        );
        if (idempotencyRecords.length) {
          const compatible = idempotencyRecords.every(
            (record) => record.encoded && record.encoded.previewDigest === previewDigest
          );
          if (!compatible) {
            throw transactionConflict(
              'IDEMPOTENCY_KEY_REUSED',
              'A Idempotency-Key já foi usada com outro conteúdo'
            );
          }
          const replayedSources = new Set(
            idempotencyRecords.map((record) => record.encoded.sourceDigest)
          );
          const duplicateIndexesOnFirstRun = [];
          transactions.forEach((transaction, index) => {
            if (!transaction || replayedSources.has(sourceDigest(transaction, index))) return;
            if (preview._existingDuplicates.has(index)) duplicateIndexesOnFirstRun.push(index);
          });
          return {
            ok: true,
            replayed: true,
            imported: idempotencyRecords.length,
            skipped_duplicates: duplicateIndexesOnFirstRun.length,
            duplicate_indexes: duplicateIndexesOnFirstRun,
            preview_hash: preview.preview_hash
          };
        }

        const keys = originKeys(transactions);
        const matches = keys.length
          ? await repository.findOriginMatches(connection, userId, keys)
          : [];
        const duplicates = duplicateIndexes(keys, matches);
        const rows = [];

        transactions.forEach((transaction, index) => {
          if (!transaction || duplicates.has(index)) return;
          const source = sourceDigest(transaction, index);
          rows.push(
            ...expandTransaction(transaction, userId, {
              originIdFactory: (occurrence) =>
                buildEncodedOriginId({
                  idempotencyKey,
                  previewHash: preview.preview_hash,
                  source,
                  occurrence
                })
            })
          );
        });

        if (rows.length > MAX_EXPANDED_IMPORT_ROWS) {
          throw transactionValidationError({
            field: 'items',
            code: 'expanded_import_too_large',
            max_rows: MAX_EXPANDED_IMPORT_ROWS
          });
        }
        if (!rows.length) {
          throw transactionConflict(
            'IMPORT_NOTHING_TO_INSERT',
            'Todos os lançamentos do lote já existem; nenhum item foi gravado',
            { duplicate_indexes: [...duplicates].sort((left, right) => left - right) }
          );
        }

        const result = await repository.insertRows(connection, rows);
        return {
          ok: true,
          replayed: false,
          imported: result.affectedRows,
          skipped_duplicates: duplicates.size,
          duplicate_indexes: [...duplicates].sort((left, right) => left - right),
          preview_hash: preview.preview_hash
        };
      });
    } catch (error) {
      if (error?.code === 'ER_DUP_ENTRY') {
        throw transactionConflict(
          'DUPLICATE_TRANSACTION_ORIGIN',
          'Um lançamento do lote já havia sido importado; nenhum item foi gravado'
        );
      }
      throw error;
    }
  }

  return {
    create,
    importBulk,
    list,
    previewImport,
    remove,
    update
  };
}

module.exports = {
  MAX_EXPANDED_IMPORT_ROWS,
  createTransactionService,
  expandTransaction
};
