'use strict';

const nodemailer = require('nodemailer');

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function createMailService({ config, transporterFactory = nodemailer.createTransport } = {}) {
  if (!config || !config.smtp) {
    throw new TypeError('config.smtp e obrigatoria');
  }

  let transport = null;

  function getTransport() {
    if (!config.smtp.enabled) return null;
    if (transport) return transport;

    transport = transporterFactory({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.secure,
      requireTLS: config.smtp.requireTls,
      auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.password } : undefined,
      connectionTimeout: 10_000,
      greetingTimeout: 10_000,
      socketTimeout: 15_000,
      pool: true,
      maxConnections: 3,
      maxMessages: 100,
      disableFileAccess: true,
      disableUrlAccess: true,
      tls: { rejectUnauthorized: true }
    });

    return transport;
  }

  async function sendPasswordReset({ to, resetUrl }) {
    const currentTransport = getTransport();
    if (!currentTransport) return { sent: false, reason: 'smtp_disabled' };

    const safeUrl = escapeHtml(resetUrl);
    await currentTransport.sendMail({
      from: config.smtp.from,
      to,
      disableFileAccess: true,
      disableUrlAccess: true,
      subject: 'Recuperacao de senha - Finia',
      text: [
        'Voce solicitou a redefinicao da sua senha no Finia.',
        '',
        'Acesse o link abaixo para criar uma nova senha:',
        resetUrl,
        '',
        'O link tem prazo curto e so pode ser usado uma vez.',
        'Se voce nao solicitou isso, ignore este e-mail.'
      ].join('\n'),
      html: [
        '<p>Voce solicitou a redefinicao da sua senha no Finia.</p>',
        '<p>Acesse o link abaixo para criar uma nova senha:</p>',
        `<p><a href="${safeUrl}" rel="noreferrer">Redefinir minha senha</a></p>`,
        '<p>O link tem prazo curto e so pode ser usado uma vez.</p>',
        '<p>Se voce nao solicitou isso, ignore este e-mail.</p>'
      ].join('')
    });

    return { sent: true };
  }

  async function verifyConnection() {
    const currentTransport = getTransport();
    if (!currentTransport) return false;
    await currentTransport.verify();
    return true;
  }

  return Object.freeze({
    isEnabled: () => Boolean(config.smtp.enabled),
    sendPasswordReset,
    verifyConnection
  });
}

module.exports = {
  createMailService
};
