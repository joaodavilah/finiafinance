'use strict';

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const BCRYPT_COST = 12;
const DUMMY_PASSWORD_HASH = bcrypt.hashSync('finia-dummy-password-never-used', BCRYPT_COST);
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RESET_TOKEN_PATTERN = /^[a-f0-9]{64}$/i;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

class AuthError extends Error {
  constructor(code, status, publicMessage) {
    super(publicMessage);
    this.name = 'AuthError';
    this.code = code;
    this.status = status;
    this.publicMessage = publicMessage;
  }
}

function sha256(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function safeEqualText(left, right) {
  const leftBuffer = Buffer.from(String(left));
  const rightBuffer = Buffer.from(String(right));
  return (
    leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer)
  );
}

function normalizeEmail(value) {
  if (typeof value !== 'string') {
    throw new AuthError('INVALID_INPUT', 400, 'Dados invalidos');
  }
  const email = value.trim().toLowerCase();
  if (!email || email.length > 150 || !EMAIL_PATTERN.test(email)) {
    throw new AuthError('INVALID_INPUT', 400, 'Dados invalidos');
  }
  return email;
}

function normalizeName(value) {
  if (typeof value !== 'string') {
    throw new AuthError('INVALID_INPUT', 400, 'Dados invalidos');
  }
  const name = value.trim().replace(/\s+/g, ' ');
  const letterCount = (name.match(/\p{L}/gu) || []).length;
  if (
    name.length > 150 ||
    letterCount < 3 ||
    /[0-9]/.test(name) ||
    !/^[\p{L}\s'.-]+$/u.test(name)
  ) {
    throw new AuthError('INVALID_INPUT', 400, 'Dados invalidos');
  }
  return name;
}

function validateLoginPassword(value, maxBytes) {
  if (typeof value !== 'string' || !value || Buffer.byteLength(value, 'utf8') > maxBytes) {
    throw new AuthError('INVALID_CREDENTIALS', 401, 'E-mail ou senha invalidos');
  }
  return value;
}

function validateNewPassword(value, config) {
  if (typeof value !== 'string') {
    throw new AuthError('WEAK_PASSWORD', 400, 'A senha nao atende aos requisitos de seguranca');
  }

  const characterLength = Array.from(value).length;
  const byteLength = Buffer.byteLength(value, 'utf8');
  const hasRequiredClasses =
    /[A-Z]/.test(value) && /[0-9]/.test(value) && /[^A-Za-z0-9]/.test(value);

  if (
    characterLength < config.auth.passwordMinCharacters ||
    byteLength > config.auth.passwordMaxBytes ||
    !hasRequiredClasses
  ) {
    throw new AuthError('WEAK_PASSWORD', 400, 'A senha nao atende aos requisitos de seguranca');
  }

  return value;
}

function createAuthService({
  config,
  userRepository,
  sessionRepository,
  mailService,
  logger = null,
  now = () => Date.now()
} = {}) {
  if (!config?.jwt?.secret || !userRepository || !sessionRepository || !mailService) {
    throw new TypeError('config, userRepository, sessionRepository e mailService sao obrigatorios');
  }
  if (config.auth.bcryptCost !== BCRYPT_COST) {
    throw new TypeError(`O custo bcrypt deve permanecer em ${BCRYPT_COST}`);
  }

  function safeLog(event, error) {
    if (!logger || typeof logger.error !== 'function') return;
    logger.error(event, {
      errorCode: typeof error?.code === 'string' ? error.code.slice(0, 80) : 'INTERNAL_ERROR'
    });
  }

  function safeWarn(event, context = {}) {
    if (!logger || typeof logger.warn !== 'function') return;
    logger.warn(event, context);
  }

  function metadataHash(label, value) {
    if (!value) return null;
    return crypto
      .createHmac('sha256', config.jwt.secret)
      .update(`${label}:${String(value).slice(0, 512)}`)
      .digest('hex');
  }

  function buildResetUrl(rawToken) {
    const url = new URL(`${config.appUrl}/`);
    url.hash = `screen-reset-password&token=${encodeURIComponent(rawToken)}`;
    return url.toString();
  }

  async function register({ name, email, password }) {
    const normalizedName = normalizeName(name);
    const normalizedEmail = normalizeEmail(email);
    const validPassword = validateNewPassword(password, config);
    const passwordHash = await bcrypt.hash(validPassword, BCRYPT_COST);

    try {
      return await userRepository.createUser({
        name: normalizedName,
        email: normalizedEmail,
        passwordHash
      });
    } catch (error) {
      if (error?.code === 'ER_DUP_ENTRY') {
        throw new AuthError('REGISTRATION_REJECTED', 409, 'Nao foi possivel concluir o cadastro');
      }
      throw error;
    }
  }

  async function login({ email, password, ip, userAgent }) {
    let normalizedEmail;
    try {
      normalizedEmail = normalizeEmail(email);
    } catch {
      normalizedEmail = null;
    }

    let validPassword;
    let passwordInputIsValid = true;
    try {
      validPassword = validateLoginPassword(password, config.auth.passwordMaxBytes);
    } catch {
      passwordInputIsValid = false;
      validPassword = '';
    }

    const row = normalizedEmail ? await userRepository.findAuthByEmail(normalizedEmail) : null;
    const passwordMatches = await bcrypt.compare(
      validPassword,
      row?.password_hash || DUMMY_PASSWORD_HASH
    );

    if (!row || !passwordMatches || !passwordInputIsValid) {
      throw new AuthError('INVALID_CREDENTIALS', 401, 'E-mail ou senha invalidos');
    }

    const issuedAtMs = now();
    const sessionId = crypto.randomUUID();
    const jwtId = crypto.randomUUID();
    const csrfToken = crypto.randomBytes(32).toString('base64url');
    const expiresAtMs = issuedAtMs + config.jwt.sessionTtlSeconds * 1000;

    await sessionRepository.createSession({
      id: sessionId,
      userId: Number(row.id),
      jwtJtiHash: sha256(jwtId),
      csrfTokenHash: sha256(csrfToken),
      expiresAtMs,
      ipHash: metadataHash('ip', ip),
      userAgentHash: metadataHash('ua', userAgent)
    });

    const token = jwt.sign({ sid: sessionId }, config.jwt.secret, {
      algorithm: config.jwt.algorithm,
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
      subject: String(row.id),
      jwtid: jwtId,
      expiresIn: config.jwt.sessionTtlSeconds
    });

    return {
      user: userRepository.publicUser(row),
      token,
      csrfToken,
      expiresAtMs,
      sessionId
    };
  }

  async function authenticate(token) {
    if (typeof token !== 'string' || !token) {
      throw new AuthError('UNAUTHENTICATED', 401, 'Sessao invalida ou expirada');
    }

    let payload;
    try {
      payload = jwt.verify(token, config.jwt.secret, {
        algorithms: [config.jwt.algorithm],
        issuer: config.jwt.issuer,
        audience: config.jwt.audience,
        clockTolerance: 5
      });
    } catch {
      throw new AuthError('UNAUTHENTICATED', 401, 'Sessao invalida ou expirada');
    }

    const userId = Number(payload.sub);
    if (
      !Number.isInteger(userId) ||
      userId < 1 ||
      !UUID_PATTERN.test(payload.sid || '') ||
      !UUID_PATTERN.test(payload.jti || '')
    ) {
      throw new AuthError('UNAUTHENTICATED', 401, 'Sessao invalida ou expirada');
    }

    const session = await sessionRepository.findActiveById(payload.sid, now());
    if (
      !session ||
      session.userId !== userId ||
      !safeEqualText(session.jwtJtiHash, sha256(payload.jti))
    ) {
      throw new AuthError('UNAUTHENTICATED', 401, 'Sessao invalida ou expirada');
    }

    const user = await userRepository.findPublicById(userId);
    if (!user) {
      throw new AuthError('UNAUTHENTICATED', 401, 'Sessao invalida ou expirada');
    }

    return { user, session };
  }

  function verifyCsrf({ session, cookieToken, headerToken }) {
    if (!session || typeof cookieToken !== 'string' || typeof headerToken !== 'string')
      return false;
    if (!safeEqualText(cookieToken, headerToken)) return false;
    return safeEqualText(sha256(headerToken), session.csrfTokenHash);
  }

  async function logout({ sessionId, userId }) {
    await sessionRepository.revokeSession({ sessionId, userId });
  }

  async function logoutAll(userId) {
    await sessionRepository.revokeAllForUser(userId);
  }

  async function requestPasswordReset(emailValue) {
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = sha256(rawToken);
    let normalizedEmail = null;

    try {
      normalizedEmail = normalizeEmail(emailValue);
    } catch {
      // A resposta externa permanece invariavel.
    }

    const target = normalizedEmail
      ? await userRepository.findResetTargetByEmail(normalizedEmail)
      : null;

    if (target) {
      await userRepository.setResetToken({
        userId: target.id,
        tokenHash,
        ttlMinutes: config.auth.resetTokenTtlMinutes
      });
      const resetUrl = buildResetUrl(rawToken);

      try {
        const result = await mailService.sendPasswordReset({
          to: target.email,
          resetUrl
        });
        if (!result.sent) {
          await userRepository.clearResetToken({ userId: target.id, tokenHash });
          safeWarn('password_reset_delivery_skipped', {
            reason: result.reason || 'mail_service_disabled'
          });
        }
      } catch (error) {
        try {
          await userRepository.clearResetToken({ userId: target.id, tokenHash });
        } catch (cleanupError) {
          safeLog('password_reset_cleanup_failed', cleanupError);
        }
        safeLog('password_reset_delivery_failed', error);
      }
    }

    return { accepted: true };
  }

  async function resetPassword({ token, newPassword }) {
    if (typeof token !== 'string' || !RESET_TOKEN_PATTERN.test(token)) {
      throw new AuthError('INVALID_RESET_TOKEN', 400, 'Token invalido ou expirado');
    }

    const validPassword = validateNewPassword(newPassword, config);
    const passwordHash = await bcrypt.hash(validPassword, BCRYPT_COST);
    const tokenHash = sha256(token);

    const changed = await userRepository.withTransaction(async (connection) => {
      const target = await userRepository.findValidResetTokenForUpdate(tokenHash, connection);
      if (!target) return false;

      await userRepository.updatePasswordAndClearReset(
        {
          userId: target.id,
          passwordHash
        },
        connection
      );
      await sessionRepository.revokeAllForUser(target.id, connection);
      return true;
    });

    if (!changed) {
      throw new AuthError('INVALID_RESET_TOKEN', 400, 'Token invalido ou expirado');
    }

    return { changed: true };
  }

  async function changePassword({ userId, currentPassword, newPassword }) {
    let passwordInput;
    try {
      passwordInput = validateLoginPassword(currentPassword, config.auth.passwordMaxBytes);
    } catch {
      throw new AuthError('INVALID_CURRENT_PASSWORD', 400, 'A senha atual esta incorreta');
    }

    const target = await userRepository.findAuthById(userId);
    const matches = await bcrypt.compare(
      passwordInput,
      target?.password_hash || DUMMY_PASSWORD_HASH
    );
    if (!target || !matches) {
      throw new AuthError('INVALID_CURRENT_PASSWORD', 400, 'A senha atual esta incorreta');
    }

    const validatedPassword = validateNewPassword(newPassword, config);
    if (await bcrypt.compare(validatedPassword, target.password_hash)) {
      throw new AuthError('PASSWORD_REUSED', 400, 'Escolha uma senha diferente da atual');
    }

    const passwordHash = await bcrypt.hash(validatedPassword, BCRYPT_COST);
    await userRepository.withTransaction(async (connection) => {
      await userRepository.updatePasswordForUser({ userId, passwordHash }, connection);
      await sessionRepository.revokeAllForUser(userId, connection);
    });
    return { changed: true };
  }

  return Object.freeze({
    register,
    login,
    authenticate,
    verifyCsrf,
    logout,
    logoutAll,
    requestPasswordReset,
    resetPassword,
    changePassword
  });
}

module.exports = {
  AuthError,
  createAuthService,
  normalizeName,
  validateNewPassword
};
