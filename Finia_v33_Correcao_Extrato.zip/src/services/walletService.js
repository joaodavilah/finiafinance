'use strict';
const { transactionBadRequest } = require('../utils/transactionErrors');
const { parseMoneyToCents } = require('../utils/transactionMoney');
const { isValidCivilDate } = require('../utils/transactionDate');
const fail = (message) => {
  throw transactionBadRequest('WALLET_INVALID', message);
};
const cents = (v) => Math.round(Number(v || 0) * 100);
const today = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
function money(v, zero = true) {
  const n = parseMoneyToCents(v ?? 0, { allowZero: zero });
  if (n === null) fail('Informe um valor válido com até duas casas decimais.');
  return n / 100;
}
async function ensureDefault(c, userId) {
  const [rows] = await c.execute(
    'SELECT id FROM carteiras WHERE usuario_id=? AND padrao=1 LIMIT 1',
    [userId]
  );
  if (rows[0]) return Number(rows[0].id);
  const [r] = await c.execute(
    "INSERT INTO carteiras(usuario_id,nome,tipo,padrao) VALUES(?,'Débito','debito',1)",
    [userId]
  );
  return Number(r.insertId);
}
async function validateWallet(c, userId, id, tipo) {
  const walletId = id || (await ensureDefault(c, userId));
  const [rows] = await c.execute('SELECT * FROM carteiras WHERE id=? AND usuario_id=?', [
    walletId,
    userId
  ]);
  if (!rows[0]) fail('Carteira não encontrada para este usuário.');
  if (rows[0].tipo === 'credito' && tipo === 'entrada')
    fail('No cartão, registre compras. Receitas pertencem à conta ou ao VR.');
  return Number(walletId);
}
async function validateCategory(c, userId, category) {
  if (!category?.startsWith('custom_')) return;
  const [rows] = await c.execute('SELECT id FROM categorias_usuario WHERE usuario_id=? AND id=?', [
    userId,
    category
  ]);
  if (!rows[0]) {
    const [old] = await c.execute(
      'SELECT id FROM lancamentos WHERE usuario_id=? AND categoria=? LIMIT 1',
      [userId, category]
    );
    if (!old[0]) fail('Crie esta categoria em Categorias antes de usá-la.');
  }
}
async function balances(c, userId, date) {
  const [wallets] = await c.execute(
    'SELECT * FROM carteiras WHERE usuario_id=? ORDER BY padrao DESC,id',
    [userId]
  );
  const [txs] = await c.execute(
    `SELECT carteira_id,tipo,SUM(valor) valor FROM lancamentos
    WHERE usuario_id=? AND (data_lancamento<=? OR
      (tipo='saida' AND carteira_id IN(SELECT id FROM carteiras WHERE usuario_id=? AND tipo='credito')
       AND data_compra<=? AND recorrente=0))
    GROUP BY carteira_id,tipo`,
    [userId, date, userId, date]
  );
  const [payments] = await c.execute(
    'SELECT origem_id,destino_id,SUM(valor) valor FROM pagamentos_fatura WHERE usuario_id=? AND data_pagamento<=? GROUP BY origem_id,destino_id',
    [userId, date]
  );
  return wallets.map((w) => {
    let net = cents(w.saldo_inicial),
      debt = cents(w.divida_inicial);
    for (const t of txs)
      if (Number(t.carteira_id) === Number(w.id) || (!t.carteira_id && w.padrao)) {
        net += t.tipo === 'entrada' ? cents(t.valor) : -cents(t.valor);
        debt += t.tipo === 'saida' ? cents(t.valor) : -cents(t.valor);
      }
    for (const p of payments) {
      if (Number(p.origem_id) === Number(w.id)) net -= cents(p.valor);
      if (Number(p.destino_id) === Number(w.id)) debt -= cents(p.valor);
    }
    return {
      ...w,
      id: Number(w.id),
      saldo: net / 100,
      divida: debt / 100,
      disponivel: (cents(w.limite) - debt) / 100
    };
  });
}
async function checkCreditDebt(c, userId) {
  const ws = await balances(c, userId, today());
  if (ws.some((w) => w.tipo === 'credito' && w.divida < 0))
    fail(
      'Esta alteração deixaria o cartão com pagamentos maiores que a dívida. Estorne o pagamento primeiro.'
    );
}
const categoryIcons=['Shapes','Utensils','CarFront','HeartPulse','Gamepad2','House','ReceiptText','BookOpen','WalletCards','LaptopMinimal','Landmark','Sparkles'];
function closingDay(value){const day=Number(value);if(!Number.isInteger(day)||day<1||day>31)fail('Informe o dia de fechamento entre 1 e 31.');return day;}
function createWalletService(pool) {
  async function locked(userId, fn) {
    const c = await pool.getConnection();
    try {
      await c.beginTransaction();
      const [u] = await c.execute('SELECT id FROM usuarios WHERE id=? FOR UPDATE', [userId]);
      if (!u[0]) fail('Usuário inválido.');
      await ensureDefault(c, userId);
      const result = await fn(c);
      await c.commit();
      return result;
    } catch (e) {
      await c.rollback();
      throw e;
    } finally {
      c.release();
    }
  }
  return {
    async list(userId) {
      return locked(userId, (c) => balances(c, userId, today()));
    },
    async remove(userId, id) {
      if (!Number.isSafeInteger(Number(id)) || Number(id)<=0) fail('Carteira inválida.');
      return locked(userId, async c => {
        const [rows]=await c.execute('SELECT * FROM carteiras WHERE usuario_id=? AND id=?',[userId,id]);
        const wallet=rows[0];
        if(!wallet) fail('Carteira não encontrada.');
        const [txs]=await c.execute('SELECT id FROM lancamentos WHERE usuario_id=? AND (carteira_id=? OR (carteira_id IS NULL AND ?=1)) LIMIT 1',[userId,id,wallet.padrao]);
        const [payments]=await c.execute('SELECT id FROM pagamentos_fatura WHERE usuario_id=? AND (origem_id=? OR destino_id=?) LIMIT 1',[userId,id,id]);
        if(txs.length || payments.length) fail('Esta carteira possui movimentações vinculadas. Revise os lançamentos antes de excluir.');
        if(wallet.padrao){
          const [others]=await c.execute("SELECT id FROM carteiras WHERE usuario_id=? AND id<>? AND tipo='debito' ORDER BY id LIMIT 1",[userId,id]);
          if(!others.length) fail('Crie outra carteira de débito antes de excluir a carteira padrão.');
          await c.execute('UPDATE carteiras SET padrao=1 WHERE usuario_id=? AND id=?',[userId,others[0].id]);
        }
        await c.execute('DELETE FROM carteiras WHERE usuario_id=? AND id=?',[userId,id]);
        return {ok:true};
      });
    },
    async removeCategory(userId,id){
      return locked(userId,async c=>{
        const [rows]=await c.execute('SELECT id FROM categorias_usuario WHERE usuario_id=? AND id=?',[userId,id]);
        if(!rows.length) fail('Categoria personalizada não encontrada.');
        const [used]=await c.execute('SELECT id FROM lancamentos WHERE usuario_id=? AND categoria=? LIMIT 1',[userId,id]);
        if(used.length) fail('Esta categoria está em uso. Altere a categoria dos lançamentos antes de excluir.');
        await c.execute('DELETE FROM categorias_usuario WHERE usuario_id=? AND id=?',[userId,id]);
        return {ok:true};
      });
    },
    async setClosing(userId,id,body){
      const day=closingDay(body?.dia_fechamento);
      return locked(userId,async c=>{
        const [rows]=await c.execute("SELECT id FROM carteiras WHERE usuario_id=? AND id=? AND tipo='credito'",[userId,id]);
        if(!rows.length)fail('Cartão não encontrado.');
        await c.execute('UPDATE carteiras SET dia_fechamento=? WHERE usuario_id=? AND id=?',[day,userId,id]);
        return {ok:true};
      });
    },
    async create(userId, b) {
      if (!b || typeof b !== 'object') fail('Envie os dados da carteira.');
      const nome = String(b.nome || '').trim();
      if (nome.length < 2 || nome.length > 60 || !['debito', 'credito', 'vr'].includes(b.tipo))
        fail('Informe nome (2 a 60 caracteres) e tipo da carteira.');
      const closing=b.tipo==='credito'&&b.dia_fechamento!=null?closingDay(b.dia_fechamento):null;
      const saldo = money(b.saldo_inicial),
        limite = money(b.limite),
        divida = money(b.divida_inicial);
      if (b.tipo === 'credito' && (saldo || divida > limite))
        fail('A dívida inicial não pode superar o limite; cartão não tem saldo inicial.');
      return locked(userId, async (c) => {
        try {
          const [r] = await c.execute(
            'INSERT INTO carteiras(usuario_id,nome,tipo,saldo_inicial,limite,divida_inicial,dia_fechamento) VALUES(?,?,?,?,?,?,?)',
            [
              userId,
              nome,
              b.tipo,
              b.tipo === 'credito' ? 0 : saldo,
              b.tipo === 'credito' ? limite : 0,
              b.tipo === 'credito' ? divida : 0,
              closing
            ]
          );
          return { id: r.insertId };
        } catch (e) {
          if (e.code === 'ER_DUP_ENTRY') fail('Já existe uma carteira com esse nome.');
          throw e;
        }
      });
    },
    async pay(userId, b) {
      if (!b || typeof b !== 'object') fail('Envie os dados do pagamento.');
      const value = money(b.valor, false),
        date = b.data_pagamento;
      if (!isValidCivilDate(date) || date > today()) fail('Informe uma data válida até hoje.');
      if (typeof b.chave !== 'string' || !/^[-a-zA-Z0-9]{8,80}$/.test(b.chave))
        fail('Identificador de pagamento inválido.');
      return locked(userId, async (c) => {
        const [previous] = await c.execute(
          "SELECT *,DATE_FORMAT(data_pagamento,'%Y-%m-%d') dia FROM pagamentos_fatura WHERE usuario_id=? AND chave=?",
          [userId, b.chave]
        );
        if (previous[0]) {
          const p = previous[0];
          if (
            Number(p.origem_id) !== Number(b.origem_id) ||
            Number(p.destino_id) !== Number(b.destino_id) ||
            cents(p.valor) !== cents(value) ||
            p.dia !== date
          )
            fail('Identificador já usado por outro pagamento.');
          return { id: p.id, replayed: true };
        }
        const ws = await balances(c, userId, date);
        const origin = ws.find((w) => w.id === Number(b.origem_id)),
          dest = ws.find((w) => w.id === Number(b.destino_id));
        if (!origin || origin.tipo !== 'debito' || !dest || dest.tipo !== 'credito')
          fail('Escolha uma conta de débito e um cartão deste usuário.');
        if (cents(origin.saldo) < cents(value))
          fail('Saldo insuficiente na conta de origem na data escolhida.');
        if (cents(dest.divida) < cents(value))
          fail('O pagamento supera a dívida do cartão na data escolhida.');
        const current = await balances(c, userId, today());
        if (cents(current.find((w) => w.id === dest.id).divida) < cents(value))
          fail('Este valor já foi quitado por outro pagamento.');
        const [r] = await c.execute(
          'INSERT INTO pagamentos_fatura(usuario_id,origem_id,destino_id,valor,data_pagamento,chave) VALUES(?,?,?,?,?,?)',
          [userId, origin.id, dest.id, value, date, b.chave]
        );
        return { id: r.insertId };
      });
    },
    async payments(userId) {
      const [r] = await pool.execute(
        "SELECT id,origem_id,destino_id,valor,DATE_FORMAT(data_pagamento,'%Y-%m-%d') data_pagamento FROM pagamentos_fatura WHERE usuario_id=? ORDER BY data_pagamento DESC,id DESC",
        [userId]
      );
      return r;
    },
    async undo(userId, id) {
      return locked(userId, async (c) => {
        const [r] = await c.execute('DELETE FROM pagamentos_fatura WHERE usuario_id=? AND id=?', [
          userId,
          id
        ]);
        if (!r.affectedRows) fail('Pagamento não encontrado.');
        return { ok: true };
      });
    },
    async categories(userId) {
      const [r] = await pool.execute(
        'SELECT id,label,type,icon,color FROM categorias_usuario WHERE usuario_id=? ORDER BY label',
        [userId]
      );
      return r;
    },
    async category(userId, b) {
      if (!b || typeof b !== 'object') fail('Envie os dados da categoria.');
      const label = String(b.label || '')
          .trim()
          .replace(/\s+/g, ' '),
        type = b.type;
      if (label.length < 2 || label.length > 32 || !['entrada', 'saida'].includes(type))
        fail('Informe um nome entre 2 e 32 caracteres e o tipo da categoria.');
      const icon=b.icon||'Shapes';
      const color=b.color??'#F2B84B';
      if(typeof color!=='string'||!/^#[0-9a-fA-F]{6}$/.test(color))fail('Escolha uma cor válida.');
      if(!categoryIcons.includes(icon))fail('Escolha um ícone válido.');
      const id = `custom_${type}_${require('crypto').randomUUID().replace(/-/g, '')}`;
      return locked(userId, async (c) => {
        try {
          await c.execute(
            'INSERT INTO categorias_usuario(usuario_id,id,label,type,icon,color) VALUES(?,?,?,?,?,?)',
            [userId, id, label, type, icon, color.toUpperCase()]
          );
          return { id, label, type, icon, color:color.toUpperCase() };
        } catch (e) {
          if (e.code === 'ER_DUP_ENTRY') fail('Essa categoria já existe.');
          throw e;
        }
      });
    }
  };
}
module.exports = {
  createWalletService,
  validateWallet,
  validateCategory,
  balances,
  checkCreditDebt
};
