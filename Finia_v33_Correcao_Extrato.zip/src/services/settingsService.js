'use strict';

const { badRequest, notFound } = require('../lib/httpError');

function createSettingsService(repository) {
  return {
    async getForUser(userId) {
      const settings = await repository.findByUserId(userId);
      if (!settings) throw notFound('Usuario nao encontrado');
      return { limite_gastos_mensal: Number(settings.limite_gastos_mensal || 0) };
    },

    async updateMonthlyLimit(userId, rawValue) {
      let monthlyLimit;
      if (typeof rawValue === 'number') {
        monthlyLimit = rawValue;
      } else if (
        typeof rawValue === 'string' &&
        /^\d{1,8}(?:[.,]\d{1,2})?$/.test(rawValue.trim())
      ) {
        monthlyLimit = Number(rawValue.trim().replace(',', '.'));
      } else {
        throw badRequest('INVALID_MONTHLY_LIMIT', 'Limite mensal invalido');
      }

      if (!Number.isFinite(monthlyLimit) || monthlyLimit < 0 || monthlyLimit > 99_999_999.99) {
        throw badRequest('INVALID_MONTHLY_LIMIT', 'Limite mensal invalido');
      }
      const rounded = Math.round(monthlyLimit * 100) / 100;
      const updated = await repository.updateMonthlyLimit(userId, rounded);
      if (!updated) throw notFound('Usuario nao encontrado');
      return { ok: true, limite_gastos_mensal: rounded };
    }
  };
}

module.exports = { createSettingsService };
