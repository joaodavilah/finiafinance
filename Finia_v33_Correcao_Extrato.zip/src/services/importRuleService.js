'use strict';
const crypto=require('crypto');
const {merchantKey,types}=require('../../public/transaction-catalog');
const {transactionBadRequest}=require('../utils/transactionErrors');
const fail=message=>{throw transactionBadRequest('INVALID_IMPORT_RULE',message);};
function createImportRuleService(pool){
 async function list(userId){const [rows]=await pool.execute('SELECT chave,tipo,estabelecimento,nome,categoria FROM regras_importacao WHERE usuario_id=? ORDER BY nome',[userId]);return rows;}
 async function save(userId,body){
  if(!body||Object.keys(body).some(k=>k!=='rules')||!Array.isArray(body.rules)||!body.rules.length||body.rules.length>100)fail('Envie entre 1 e 100 regras.');
  const unique=new Map();
  for(const rule of body.rules){
   if(!rule||typeof rule!=='object'||Object.keys(rule).some(k=>!['tipo','descricao_original','nome','categoria'].includes(k)))fail('Regra inválida.');
   if(!Object.hasOwn(types,rule.tipo)||typeof rule.descricao_original!=='string'||rule.descricao_original.length>1000)fail('Descrição ou tipo inválido.');
   const estabelecimento=merchantKey(rule.descricao_original);
   const nome=typeof rule.nome==='string'?rule.nome.replace(/\s+/g,' ').trim():'';
   const categoria=rule.categoria;
   if(estabelecimento.length<4||estabelecimento.length>220||!nome||nome.length>150||typeof categoria!=='string'||categoria.length>100)fail('Informe o nome e a categoria para este estabelecimento.');
   if(!types[rule.tipo].includes(categoria)&&!new RegExp(`^custom_${rule.tipo}_[a-z0-9_]{1,70}$`).test(categoria))fail('Categoria incompatível com a regra.');
   const chave=crypto.createHash('sha256').update(`${rule.tipo}\0${estabelecimento}`).digest('hex');
   const item={chave,tipo:rule.tipo,estabelecimento,nome,categoria};
   if(unique.has(chave)&&JSON.stringify(unique.get(chave))!==JSON.stringify(item))fail('Há correções diferentes para o mesmo estabelecimento. Escolha uma única regra antes de confirmar.');
   unique.set(chave,item);
  }
  const c=await pool.getConnection();
  try{
   await c.beginTransaction();
   const [users]=await c.execute('SELECT id FROM usuarios WHERE id=? FOR UPDATE',[userId]);if(!users.length)fail('Usuário inválido.');
   const [existing]=await c.execute('SELECT chave FROM regras_importacao WHERE usuario_id=?',[userId]);
   const keys=new Set(existing.map(r=>r.chave));for(const key of unique.keys())keys.add(key);
   if(keys.size>500)fail('Limite de 500 regras. Remova regras que não usa mais.');
   for(const r of unique.values()){
    if(r.categoria.startsWith('custom_')){const [cats]=await c.execute('SELECT id FROM categorias_usuario WHERE usuario_id=? AND id=? AND type=?',[userId,r.categoria,r.tipo]);if(!cats.length)fail('A categoria personalizada não pertence a esta conta ou foi removida.');}
    await c.execute('DELETE FROM regras_importacao WHERE usuario_id=? AND chave=?',[userId,r.chave]);
    await c.execute('INSERT INTO regras_importacao(usuario_id,chave,tipo,estabelecimento,nome,categoria) VALUES(?,?,?,?,?,?)',[userId,r.chave,r.tipo,r.estabelecimento,r.nome,r.categoria]);
   }
   await c.commit();return {saved:unique.size};
  }catch(error){await c.rollback();throw error;}finally{c.release();}
 }
 async function remove(userId,key){if(!/^[a-f0-9]{64}$/.test(key))fail('Regra inválida.');await pool.execute('DELETE FROM regras_importacao WHERE usuario_id=? AND chave=?',[userId,key]);return {ok:true};}
 return {list,save,remove};
}
module.exports={createImportRuleService};
