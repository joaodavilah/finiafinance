# Finia Finance v9 — importação e categorias

- Mantém as melhorias da v8 para filtros, mobile, perfil e organizações.
- Novas categorias padrão para despesas e receitas, sem remover categorias personalizadas.
- Prévia de PDF e CSV: seleção de lançamentos, edição do nome e categoria e escolha da organização antes de salvar.
- Sugestões por regras locais de nomes e palavras-chave. Não envia extratos a serviços de IA.
- Leitor ajustado ao extrato consolidado Santander do exemplo: associa as linhas do estabelecimento à movimentação correta e mantém a data contábil; não importa novamente o resumo de compras.
- Descrições originais ficam disponíveis nos detalhes dos lançamentos importados.
- Aplicações, resgates e pagamentos de fatura ficam desmarcados por padrão. Se incluídos, entram nos totais de entrada/saída; revise para não duplicar movimentações patrimoniais.
- Pix sem finalidade identificável permanece sinalizado para revisão. As sugestões não garantem o propósito de uma compra.

## Atualização

A estrutura do ZIP e os arquivos de configuração de hospedagem foram preservados. A nova migração 009 adiciona somente um campo opcional para a descrição original; o inicializador existente executa as migrações ao iniciar. As migrações anteriores permanecem intactas.

A classificação se aplica às novas importações. Lançamentos antigos não são recategorizados automaticamente. Extratos importados pelo leitor antigo podem não ser reconhecidos como duplicados pelo leitor corrigido: confira os registros existentes antes de importar novamente.

Outros layouts de PDF continuam sujeitos ao reconhecimento do leitor genérico. PDFs sem texto extraível não são suportados.

## Verificação

22 testes automatizados aprovados, incluindo categorias, associação de linhas, idempotência, preservação da descrição original, parcelas, saldos e limites. O texto extraído do PDF fornecido resultou em 92 movimentações, com os totais conferindo com o resumo do extrato. Também foi testado o fluxo de confirmação da interface com respostas controladas.

A validação visual em navegador e o teste em MySQL/Hostinger não foram executados neste ambiente.
