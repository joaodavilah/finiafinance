'use strict';
// Lightweight SQL test adapter. Production remains mysql2/MySQL; this does not certify MySQL migrations.
const { DatabaseSync } = require('node:sqlite');
function createTestPool() {
  const db = new DatabaseSync(':memory:');
  db.function('DATE_FORMAT', (value, _format) =>
    value == null ? null : String(value).slice(0, 10)
  );
  db.exec(`PRAGMA foreign_keys=ON;
 CREATE TABLE regras_importacao(usuario_id INTEGER,chave TEXT,tipo TEXT,estabelecimento TEXT,nome TEXT,categoria TEXT,PRIMARY KEY(usuario_id,chave));
 CREATE TABLE usuarios(id INTEGER PRIMARY KEY,nome_completo TEXT);
 INSERT INTO usuarios VALUES(1,'Teste'),(2,'Outro usuário');
 CREATE TABLE carteiras(id INTEGER PRIMARY KEY AUTOINCREMENT,usuario_id INTEGER NOT NULL,nome TEXT NOT NULL,tipo TEXT NOT NULL,saldo_inicial NUMERIC DEFAULT 0,limite NUMERIC DEFAULT 0,divida_inicial NUMERIC DEFAULT 0,padrao INTEGER DEFAULT 0,dia_fechamento INTEGER,UNIQUE(usuario_id,nome));
 CREATE TABLE categorias_usuario(usuario_id INTEGER,id TEXT,label TEXT,type TEXT,icon TEXT DEFAULT 'Shapes',color TEXT DEFAULT '#F2B84B',PRIMARY KEY(usuario_id,id),UNIQUE(usuario_id,type,label));
 CREATE TABLE pagamentos_fatura(id INTEGER PRIMARY KEY AUTOINCREMENT,usuario_id INTEGER,origem_id INTEGER,destino_id INTEGER,valor NUMERIC,data_pagamento TEXT,chave TEXT,UNIQUE(usuario_id,chave));
 CREATE TABLE lancamentos(id INTEGER PRIMARY KEY AUTOINCREMENT,usuario_id INTEGER,tipo TEXT,descricao TEXT,descricao_original TEXT,valor NUMERIC,categoria TEXT,data_lancamento TEXT,data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,parcelado INTEGER,parcela_atual INTEGER,parcelas_total INTEGER,grupo_parcelamento TEXT,recorrente INTEGER,recorrencia_atual INTEGER,recorrencias_total INTEGER,grupo_recorrencia TEXT,origem TEXT,origem_id TEXT,carteira_id INTEGER,data_compra TEXT);
 `);
  async function execute(sql, args = []) {
    const statement = db.prepare(sql.replace(/ FOR UPDATE/g, ''));
    try {
      if (/^\s*SELECT/i.test(sql)) return [statement.all(...args)];
      const result = statement.run(...args);
      return [{ insertId: Number(result.lastInsertRowid), affectedRows: Number(result.changes) }];
    } catch (e) {
      if (e.message.includes('UNIQUE constraint')) e.code = 'ER_DUP_ENTRY';
      throw e;
    }
  }
  let tail = Promise.resolve();
  return {
    db,
    execute,
    async getConnection() {
      let unlock;
      const next = new Promise((r) => (unlock = r));
      const previous = tail;
      tail = next;
      await previous;
      return {
        execute,
        beginTransaction: async () => db.exec('BEGIN'),
        commit: async () => db.exec('COMMIT'),
        rollback: async () => db.exec('ROLLBACK'),
        release: () => unlock()
      };
    }
  };
}
module.exports = { createTestPool };
