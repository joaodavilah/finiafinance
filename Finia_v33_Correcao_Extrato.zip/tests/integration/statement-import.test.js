'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const catalog=require('../../public/transaction-catalog');
const {parsePdfTransactions}=require('../../src/parsers/transactionPdfParser');
const {createTestPool}=require('../helpers/sqlitePool');
const {createTransactionRepository}=require('../../src/repositories/transactionRepository');
const {createTransactionService}=require('../../src/services/transactionService');
const {validateTransactionInput}=require('../../src/validators/transactionValidator');
const fixture=`EXTRATO CONSOLIDADO INTELIGENTE
junho/2026
Movimentação
01/06 DEBITO VISA ELECTRON BRASIL 123456 19,90-
30/05 BURGER KING
PIX RECEBIDO - 50,00
Pessoa Exemplo
E xtrato_P F _A4_Inteligente - 27/11/2024
P agina: 2/12
EXTRATO CONSOLIDADO INTELIGENTE
junho/2026
DEBITO VISA ELECTRON BRASIL 654321 100,00- 80,10
31/05 RedeDePostosPoffo
02/06 APLICACAO CDB/RDB - 40,00-
Saldos por Período
03/06 IGNORAR 999,00
Compras com Cartão de Débito
30/05 BURGER KING 19,90`;
test('Santander: merchant stays with its value and booking date, across headers; balances and card summary excluded',()=>{
 const rows=parsePdfTransactions(fixture);assert.equal(rows.length,4);
 assert.equal(rows[0].data_lancamento,'2026-06-01');assert.match(rows[0].descricao_original,/BURGER KING/);assert.equal(rows[0].valor,19.9);
 assert.match(rows[1].descricao_original,/Pessoa Exemplo/);assert.doesNotMatch(rows[1].descricao_original,/EXTRATO|Pagina/);assert.equal(rows[2].valor,100);assert.equal(rows[2].data_lancamento,'2026-06-01');
 assert.deepEqual(rows,parsePdfTransactions(fixture));
});
test('identical purchases are retained with distinct, repeatable identities',()=>{
 const text='EXTRATO CONSOLIDADO INTELIGENTE\njunho/2026\nMovimentação\n01/06 DEBITO VISA ELECTRON BRASIL - 10,00-\n01/06 LOJA\nDEBITO VISA ELECTRON BRASIL - 10,00-\n01/06 LOJA\nSaldos por Período';
 const rows=parsePdfTransactions(text);assert.equal(rows.length,2);assert.notEqual(rows[0].origem_id,rows[1].origem_id);assert.deepEqual(rows,parsePdfTransactions(text));
});
test('classification: merchants, salary, uncertain Pix, investment and bill exclusions',()=>{
 for(const [description,type,category] of [['DEBITO VISA ELECTRON BRASIL 30/05 BURGER KING','saida','alimentacao'],['RedeDePostosPoffo','saida','combustivel'],['LACOSTE TIJUCAS','saida','vestuario'],['3 . FORCE ONE ACADE','saida','academia'],['LIQUIDO DE VENCIMENTO MULTILOG','entrada','salario'],['RECARGA TELEFONE CELULAR TIM','saida','telefonia']])assert.equal(catalog.suggest(description,type).categoria,category);
 assert.equal(catalog.suggest('PIX ENVIADO Pessoa Exemplo','saida').revisar,true);
 assert.equal(catalog.suggest('PIX RECEBIDO BURGER KING','entrada').categoria,'transferencias');
 for(const [s,t] of [['APLICACAO CDB/RDB','saida'],['RESGATE CDB/RDB','entrada'],['PAGAMENTO CARTAO CREDITO BCE','saida']])assert.equal(catalog.suggest(s,t).selecionado,false);
 assert.equal(catalog.suggest('DEBITO VISA ELECTRON BRASIL 30/05 BURGER KING','saida').descricao,'Burger King');
});
test('all default categories validate for their type; custom categories remain accepted',()=>{
 for(const [tipo,categories] of Object.entries(catalog.types))for(const categoria of categories){const result=validateTransactionInput({tipo,categoria,descricao:'Teste',valor:10,data_lancamento:'2026-06-01'});assert.equal(result.ok,true,JSON.stringify(result));}
 assert.equal(validateTransactionInput({tipo:'saida',categoria:'custom_saida_teste',descricao:'Teste',valor:10,data_lancamento:'2026-06-01'}).ok,true);
});
test('bulk review preserves original text, wallet and edited name; retry and reimport do not duplicate; original cannot be edited',async()=>{
 const pool=createTestPool();const service=createTransactionService(createTransactionRepository(pool));
 const original=parsePdfTransactions(fixture)[0];const suggestion=catalog.suggest(original.descricao_original,original.tipo);
 const item={...original,descricao:suggestion.descricao,categoria:suggestion.categoria};
 const preview=await service.previewImport(1,[item]);assert.equal(preview.ok,true);
 const body={items:preview.items,preview_hash:preview.preview_hash};
 const result=await service.importBulk(1,body,'test-review-0001');assert.equal(result.imported,1);
 const rows=(await service.list(1,{})).items;assert.equal(rows[0].descricao,'Burger King');assert.equal(rows[0].descricao_original,item.descricao_original);
 await service.importBulk(1,body,'test-review-0001');assert.equal((await service.list(1,{})).items.length,1);
 const second=await service.previewImport(1,[{...item,descricao:'Almoço'}]);assert.equal(second.duplicate_count,1);
 await service.update(1,rows[0].id,{tipo:'saida',categoria:'alimentacao',descricao:'Almoço',valor:19.9,data_lancamento:'2026-06-01'});
 assert.equal((await service.list(1,{})).items[0].descricao_original,item.descricao_original);
 await assert.rejects(service.update(1,rows[0].id,{tipo:'saida',categoria:'alimentacao',descricao:'Almoço',descricao_original:'alterado',valor:19.9,data_lancamento:'2026-06-01'}));
});
test('CSV accepts readable labels for all new default categories',()=>{
 const {parseCsvTransactions}=require('../../src/parsers/transactionCsvParser');
 for(const [tipo,ids] of Object.entries(catalog.types))for(const id of ids){
  const parsed=parseCsvTransactions(`data;tipo;descricao;valor;categoria\n01/06/2026;${tipo};Teste;10,00;${catalog.labels[id]}`);
  assert.equal(parsed.items[0].categoria,id,catalog.labels[id]);
 }
});
