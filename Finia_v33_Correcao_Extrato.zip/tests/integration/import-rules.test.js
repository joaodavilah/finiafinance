'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const {createTestPool}=require('../helpers/sqlitePool');
const {createImportRuleService}=require('../../src/services/importRuleService');
const {createWalletService}=require('../../src/services/walletService');
const {parsePdfTransactions}=require('../../src/parsers/transactionPdfParser');
const catalog=require('../../public/transaction-catalog');
test('fragmented PDF text uses booking dates, reads amount after merchant, stops before repeated card summary',()=>{
 const text=`EXT R ATO CO N S O LID AD O IN TE LIGE N TE\njunho / 2026\nMovi m entação\n01 / 06 D EBITO VISA E L ECT R O N BR ASIL\n30 / 05 LACO S TE TIJU CAS\n123456 369,00-\nPIX R ECEBID O\nPessoa Teste\n- 30,00\nAPLICACAO C D B/ RD B - 100,00-\nS aldos por Pe r iodo\n30 / 05 LACO S TE TIJU CAS 369,00`;
 const rows=parsePdfTransactions(text);assert.equal(rows.length,3);assert.equal(rows[0].data_lancamento,'2026-06-01');assert.equal(rows[0].valor,369);
 assert.equal(catalog.suggest(rows[0].descricao_original,'saida').descricao,'Lacoste Tijucas');assert.equal(catalog.suggest(rows[0].descricao_original,'saida').categoria,'vestuario');assert.equal(catalog.suggest(rows[2].descricao_original,'saida').selecionado,false);
});
test('known text repairs preserve unknown names and distinguish merchant keys',()=>{
 assert.equal(catalog.repairText('BUR GE R KIN G'),'Burger King');assert.equal(catalog.repairText('Pessoa Diferente'),'Pessoa Diferente');
 assert.equal(catalog.merchantKey('DEBITO VISA ELECTRON BRASIL 01 / 06 LACO S TE TIJU CAS'),catalog.merchantKey('DEBITO VISA ELECTRON BRASIL 10/07 LACOSTE TIJUCAS'));
 assert.notEqual(catalog.merchantKey('PIX ENVIADO Ana Silva'),catalog.merchantKey('PIX ENVIADO Ana Silveira'));
});
const base={tipo:'saida',descricao_original:'DEBITO VISA ELECTRON BRASIL 01/06 LOJA EXEMPLO',nome:'Minha loja',categoria:'vestuario'};
test('rules persist by user and type; replacement and deletion cannot affect another account',async()=>{
 const s=createImportRuleService(createTestPool());await s.save(1,{rules:[base]});assert.equal((await s.list(1)).length,1);assert.equal((await s.list(2)).length,0);
 const key=(await s.list(1))[0].chave;await s.remove(2,key);assert.equal((await s.list(1)).length,1);
 await s.save(1,{rules:[{...base,nome:'Roupas'}]});assert.equal((await s.list(1)).length,1);assert.equal((await s.list(1))[0].nome,'Roupas');
 await s.save(2,{rules:[base]});await s.remove(1,key);assert.equal((await s.list(1)).length,0);assert.equal((await s.list(2)).length,1);
});
test('conflicting corrections, mismatched categories and foreign custom categories fail atomically',async()=>{
 const pool=createTestPool(),s=createImportRuleService(pool),w=createWalletService(pool);
 await assert.rejects(s.save(1,{rules:[base,{...base,nome:'Outro nome'}]}));assert.equal((await s.list(1)).length,0);
 await assert.rejects(s.save(1,{rules:[{...base,categoria:'salario'}]}));
 const category=await w.category(2,{label:'Exclusiva',type:'saida',icon:'Shapes'});
 const foreign=(await w.categories(2))[0].id;
 await assert.rejects(s.save(1,{rules:[base,{...base,descricao_original:'OUTRA LOJA',categoria:foreign}]}));assert.equal((await s.list(1)).length,0);
 await assert.rejects(s.save(1,{rules:[{...base,tipo:'__proto__'}]}));
 await assert.rejects(s.save(1,{rules:[{...base,descricao_original:'A'.repeat(300)}]}));
});
