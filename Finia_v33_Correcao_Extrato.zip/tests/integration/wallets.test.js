'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createTestPool } = require('../helpers/sqlitePool');
const { createWalletService } = require('../../src/services/walletService');
const { createTransactionRepository } = require('../../src/repositories/transactionRepository');
const { createTransactionService } = require('../../src/services/transactionService');
function setup() {
  const pool = createTestPool();
  return {
    pool,
    w: createWalletService(pool),
    t: createTransactionService(createTransactionRepository(pool))
  };
}
const date = '2026-01-15';
function tx(wallet, value = 100, tipo = 'saida', extra = {}) {
  return {
    carteira_id: wallet,
    valor: value,
    tipo,
    descricao: 'Teste',
    categoria: tipo === 'entrada' ? 'salario' : 'outros',
    data_lancamento: date,
    ...extra
  };
}
async function seed() {
  const x = setup();
  const [debit] = await x.w.list(1);
  const card = await x.w.create(1, { nome: 'Crédito', tipo: 'credito', limite: 5000 });
  return { ...x, debit: debit.id, card: card.id };
}
test('salary 3000, credit purchase 1000, payment: cash 2000, full limit; no expense duplication', async () => {
  const { w, t, debit, card } = await seed();
  await t.create(1, tx(debit, 3000, 'entrada'));
  await t.create(1, tx(card, 1000));
  let ws = await w.list(1);
  assert.equal(ws.find((x) => x.id === debit).saldo, 3000);
  assert.equal(ws.find((x) => x.id === card).disponivel, 4000);
  await w.pay(1, {
    origem_id: debit,
    destino_id: card,
    valor: 1000,
    data_pagamento: date,
    chave: 'pay-test-0001'
  });
  ws = await w.list(1);
  assert.equal(ws.find((x) => x.id === debit).saldo, 2000);
  assert.equal(ws.find((x) => x.id === card).disponivel, 5000);
  assert.equal(ws.find((x) => x.id === card).divida, 0);
  const rows = (await t.list(1, {})).items;
  assert.equal(rows.length, 2);
  assert.equal(
    rows.filter((r) => r.tipo === 'saida').reduce((s, r) => s + r.valor, 0),
    1000
  );
});
test('partial payment, retry idempotency and reversal', async () => {
  const { w, t, debit, card } = await seed();
  await t.create(1, tx(debit, 3000, 'entrada'));
  await t.create(1, tx(card, 1000));
  const payload = {
    origem_id: debit,
    destino_id: card,
    valor: 400,
    data_pagamento: date,
    chave: 'pay-test-0002'
  };
  const p = await w.pay(1, payload);
  assert.equal((await w.pay(1, payload)).replayed, true);
  await assert.rejects(w.pay(1, { ...payload, valor: 401 }));
  let ws = await w.list(1);
  assert.equal(ws.find((x) => x.id === card).divida, 600);
  assert.equal(ws.find((x) => x.id === debit).saldo, 2600);
  await w.undo(1, p.id);
  ws = await w.list(1);
  assert.equal(ws.find((x) => x.id === debit).saldo, 3000);
  assert.equal(ws.find((x) => x.id === card).divida, 1000);
});
test('installments reserve total immediately, preserve cents and purchase date', async () => {
  const { w, t, card } = await seed();
  await t.create(1, tx(card, 1000, 'saida', { parcelado: true, parcelas_total: 12 }));
  const rows = (await t.list(1, {})).items;
  assert.equal(rows.length, 12);
  assert.equal(
    rows.reduce((s, r) => s + Math.round(r.valor * 100), 0),
    100000
  );
  assert.ok(rows.every((r) => r.data_compra === date));
  assert.equal((await w.list(1)).find((x) => x.id === card).disponivel, 4000);
});
test('VR balance is independent of cash and credit', async () => {
  const { w, t, debit, card } = await seed();
  const vr = await w.create(1, { nome: 'VR', tipo: 'vr', saldo_inicial: 700 });
  await t.create(1, tx(vr.id, 50));
  const ws = await w.list(1);
  assert.equal(ws.find((x) => x.id === vr.id).saldo, 650);
  assert.equal(ws.find((x) => x.id === debit).saldo, 0);
  assert.equal(ws.find((x) => x.id === card).disponivel, 5000);
});
test('wallet and category ownership enforced, categories saved per user', async () => {
  const { w, t, card } = await seed();
  const category = await w.category(1, { label: 'Academia', type: 'saida' });
  await t.create(1, tx(card, 50, 'saida', { categoria: category.id }));
  assert.equal((await w.categories(1))[0].label, 'Academia');
  assert.equal((await w.categories(2)).length, 0);
  await assert.rejects(t.create(2, tx(card)));
  await assert.rejects(t.create(2, tx(null, 50, 'saida', { categoria: category.id })));
  await assert.rejects(t.create(1, tx(card, 50, 'entrada')));
});
test('payments reject another user, insufficient cash, VR origin and excess debt', async () => {
  const { w, t, debit, card } = await seed();
  await t.create(1, tx(card, 100));
  const body = {
    origem_id: debit,
    destino_id: card,
    valor: 100,
    data_pagamento: date,
    chave: 'pay-test-0003'
  };
  await assert.rejects(w.pay(2, body));
  await assert.rejects(w.pay(1, body));
  await t.create(1, tx(debit, 3000, 'entrada'));
  await assert.rejects(w.pay(1, { ...body, valor: 101 }));
  const vr = await w.create(1, { nome: 'VR', tipo: 'vr', saldo_inicial: 700 });
  await assert.rejects(w.pay(1, { ...body, origem_id: vr.id }));
});
test('concurrent payments cannot pay the same debt twice', async () => {
  const { w, t, debit, card } = await seed();
  await t.create(1, tx(debit, 3000, 'entrada'));
  await t.create(1, tx(card, 1000));
  const body = { origem_id: debit, destino_id: card, valor: 1000, data_pagamento: date };
  const results = await Promise.allSettled([
    w.pay(1, { ...body, chave: 'concurrent-1' }),
    w.pay(1, { ...body, chave: 'concurrent-2' })
  ]);
  assert.equal(results.filter((r) => r.status === 'fulfilled').length, 1);
});
test('editing or deleting paid purchases rolls back; reversal unlocks correction', async () => {
  const { w, t, debit, card } = await seed();
  await t.create(1, tx(debit, 3000, 'entrada'));
  const purchase = await t.create(1, tx(card, 1000));
  const p = await w.pay(1, {
    origem_id: debit,
    destino_id: card,
    valor: 1000,
    data_pagamento: date,
    chave: 'pay-test-0004'
  });
  await assert.rejects(t.remove(1, purchase.id));
  await assert.rejects(t.update(1, purchase.id, tx(card, 500)));
  assert.equal((await t.list(1, {})).items.find((x) => x.id === purchase.id).valor, 1000);
  await w.undo(1, p.id);
  await t.remove(1, purchase.id);
  assert.equal((await w.list(1)).find((x) => x.id === card).divida, 0);
});
test('legacy transactions and imports without wallet resolve to default', async () => {
  const { w, t, debit, pool } = await seed();
  await t.create(1, tx(null, 90));
  await pool.execute(
    "INSERT INTO lancamentos(usuario_id,tipo,valor,data_lancamento) VALUES(1,'entrada',500,?)",
    [date]
  );
  assert.equal((await w.list(1)).find((x) => x.id === debit).saldo, 410);
});
test('pagination returns all transactions without dropping older pages', async () => {
  const { t, debit } = await seed();
  for (let i = 0; i < 105; i++) await t.create(1, tx(debit, 1));
  const first = await t.list(1, { limit: '100' });
  assert.equal(first.items.length, 100);
  assert.equal(first.has_more, true);
  const second = await t.list(1, { limit: '100', cursor: first.next_cursor });
  assert.equal(second.items.length, 5);
  assert.equal(second.has_more, false);
});
test('opening debt frees limit on payment without counting old expense again', async () => {
  const { w, t, debit } = await seed();
  const card = await w.create(1, {
    nome: 'Outro cartão',
    tipo: 'credito',
    limite: 2000,
    divida_inicial: 1000
  });
  await t.create(1, tx(debit, 3000, 'entrada'));
  await w.pay(1, {
    origem_id: debit,
    destino_id: card.id,
    valor: 1000,
    data_pagamento: date,
    chave: 'pay-test-0005'
  });
  assert.equal((await w.list(1)).find((x) => x.id === card.id).disponivel, 2000);
  assert.equal((await t.list(1, {})).items.filter((x) => x.tipo === 'saida').length, 0);
});
test('bulk import preserves chosen wallet through preview hash and persistence', async () => {
  const { w, t, card } = await seed();
  const preview = await t.previewImport(1, [tx(card, 30)]);
  assert.equal(preview.items[0].carteira_id, card);
  await t.importBulk(
    1,
    { items: preview.items, preview_hash: preview.preview_hash },
    'import-test-0001'
  );
  assert.equal((await w.list(1)).find((x) => x.id === card).divida, 30);
});
test('deletion is private and refuses linked wallets or categories',async()=>{
 const {w,t,debit,card}=await seed();
 const category=await w.category(1,{label:'Teste exclusão',type:'saida'});
 await assert.rejects(w.removeCategory(2,category.id));
 await t.create(1,tx(card,100,'saida',{categoria:category.id}));
 await assert.rejects(w.removeCategory(1,category.id),/em uso/);
 await assert.rejects(w.remove(1,card),/movimentações/);
 await assert.rejects(w.remove(2,card),/não encontrada/);
 const unused=await w.category(1,{label:'Sem uso',type:'saida'});
 await w.removeCategory(1,unused.id);
 assert.equal((await w.categories(1)).some(c=>c.id===unused.id),false);
 const spare=await w.create(1,{nome:'Reserva',tipo:'vr'});
 await w.remove(1,spare.id);
 assert.equal((await w.list(1)).some(c=>c.id===spare.id),false);
 await assert.rejects(w.remove(1,debit),/outra carteira/);
 const replacement=await w.create(1,{nome:'Conta nova',tipo:'debito'});
 await w.remove(1,debit);
 assert.equal((await w.list(1)).find(c=>c.padrao).id,replacement.id);
});
test('recurring income repeats full 300 monthly; expense installments still split 300',async()=>{
 const {w,t}=setup(); const [wallet]=await w.list(1);
 await t.create(1,tx(wallet.id,300,'entrada',{data_lancamento:'2026-01-31',recorrente:true,recorrencias_total:3}));
 const income=(await t.list(1,{})).items;
 assert.equal(income.length,3);
 assert.deepEqual(income.map(x=>Number(x.valor)),[300,300,300]);
 assert.deepEqual(income.map(x=>x.data_lancamento.slice(0,10)).sort(),['2026-01-31','2026-02-28','2026-03-31']);
 assert.ok(income.every(x=>Number(x.recorrente)===1&&!Number(x.parcelado)));
 await t.create(1,tx(wallet.id,300,'saida',{parcelado:true,parcelas_total:3}));
 const expenses=(await t.list(1,{})).items.filter(x=>x.tipo==='saida');
 assert.deepEqual(expenses.map(x=>Number(x.valor)),[100,100,100]);
});
test('closing day and category icon persist and remain private',async()=>{
 const {w}=setup();
 const card=await w.create(1,{nome:'Cartão fiscal',tipo:'credito',limite:5000,dia_fechamento:10});
 assert.equal((await w.list(1)).find(x=>x.id===card.id).dia_fechamento,10);
 await assert.rejects(w.setClosing(2,card.id,{dia_fechamento:20}));
 await assert.rejects(w.setClosing(1,card.id,{dia_fechamento:32}));
 await w.setClosing(1,card.id,{dia_fechamento:31});
 assert.equal((await w.list(1)).find(x=>x.id===card.id).dia_fechamento,31);
 const c=await w.category(1,{label:'Saúde extra',type:'saida',icon:'HeartPulse'});
 assert.equal((await w.categories(1)).find(x=>x.id===c.id).icon,'HeartPulse');
 await assert.rejects(w.category(1,{label:'Inválida',type:'saida',icon:'<script>'}));
});
test('category colors persist, default safely and reject malformed CSS',async()=>{
 const {w}=setup();
 const c=await w.category(1,{label:'Roxa',type:'saida',color:'#8b5cf6'});
 assert.equal((await w.categories(1)).find(x=>x.id===c.id).color,'#8B5CF6');
 assert.equal((await w.categories(2)).length,0);
 const standard=await w.category(1,{label:'Padrão',type:'entrada'});
 assert.equal(standard.color,'#F2B84B');
 await assert.rejects(w.category(1,{label:'Inválida',type:'saida',color:'red;background:url(test)'}));
});
