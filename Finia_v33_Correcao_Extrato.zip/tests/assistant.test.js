const {test}=require('node:test');
const assert=require('node:assert/strict');
const {range,expenses,sum,groups,previous}=require('../public/assistant');
test('month bounds, leap year, partial month and year crossing',()=>{
 assert.deepEqual(range('2024-02','2026-10-02'),{from:'2024-02-01',to:'2024-02-29'});
 assert.deepEqual(previous({month:'2026-01'},'2026-01-02'),{month:'2025-12',from:'2025-12-01',to:'2025-12-02'});
 assert.equal(previous({month:'2026-03'},'2026-03-31').to,'2026-02-28');
 assert.equal(previous({month:'2026-09'},'2026-10-02').to,'2026-08-31');
});
test('expenses respect wallet, category, day, posting date and today',()=>{
 const tx=[
  {tipo:'saida',valor:.1,carteira_id:1,categoria:'food',data_lancamento:'2026-10-01',data_compra:'2026-08-01'},
  {tipo:'saida',valor:.2,carteira_id:1,categoria:'food',data_lancamento:'2026-10-01'},
  {tipo:'entrada',valor:500,carteira_id:1,data_lancamento:'2026-10-01'},
  {tipo:'saida',valor:99,carteira_id:2,data_lancamento:'2026-10-01'},
  {tipo:'saida',valor:88,carteira_id:1,data_lancamento:'2026-10-03'},
 ];
 const selected=expenses(tx,[],{month:'2026-10',wallet:'1',category:'food',day:'2026-10-01'},'2026-10-02');
 assert.equal(selected.length,2);assert.equal(sum(selected),.3);
 assert.deepEqual(groups(selected,t=>t.categoria),[{key:'food',value:.3}]);
 assert.equal(expenses(tx,[],{month:'2026-08',wallet:'1'},'2026-10-02').length,0);
 assert.equal(expenses(tx,[],{month:'2026-11',wallet:'all'},'2026-10-02').length,0);
});
test('ties deterministic and legacy default organization honored',()=>{
 assert.deepEqual(groups([{valor:10,key:'b'},{valor:10,key:'a'}],t=>t.key).map(g=>g.key),['a','b']);
 assert.equal(expenses([{tipo:'saida',valor:10,data_lancamento:'2026-09-01'}],[{id:1,padrao:true}],{month:'2026-09',wallet:'1'},'2026-10-02').length,1);
});

test('invoice boundaries match closing month, including closing day and leap February',()=>{
 const {invoiceRange}=require('../public/assistant');
 assert.deepEqual(invoiceRange('2026-10',10),{from:'2026-09-10',to:'2026-10-09'});
 assert.deepEqual(invoiceRange('2024-03',31),{from:'2024-02-29',to:'2024-03-30'});
 assert.deepEqual(invoiceRange('2026-01',1),{from:'2025-12-01',to:'2025-12-31'});
 const tx=['2026-09-09','2026-09-10','2026-10-09','2026-10-10'].map(data_lancamento=>({tipo:'saida',valor:10,carteira_id:2,data_lancamento}));
 assert.deepEqual(expenses(tx,[],{month:'2026-10',wallet:'2',mode:'invoice',closing:10},'2026-10-02').map(t=>t.data_lancamento),['2026-09-10','2026-10-09']);
 assert.deepEqual(previous({month:'2026-10',mode:'invoice',closing:10},'2026-10-02'),{month:'2026-09',from:'2026-08-10',to:'2026-09-09'});
});
