'use strict';

// Bootstrap compatível com hospedagens gerenciadas (Hostinger):
// abre a porta HTTP primeiro e só depois carrega a aplicação completa.
// Assim uma validação/configuração externa não derruba o processo e gera 503.
const path = require('path');
const express = require('express');

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const publicDirectory = path.join(__dirname, 'public');

const shell = express();
shell.disable('x-powered-by');
shell.set('etag', 'strong');

let fullApplicationReady = false;
let startupError = null;

shell.get('/health', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.status(200).json({
    ok: true,
    service: 'finia',
    node: process.version,
    applicationReady: fullApplicationReady,
    startupError: startupError ? startupError.code || startupError.name || 'STARTUP_ERROR' : null
  });
});

// Mantém o frontend atual disponível mesmo enquanto banco/configuração iniciam.
shell.use(
  express.static(publicDirectory, {
    index: false,
    fallthrough: true,
    maxAge: 0
  })
);

shell.get(['/', '/app'], (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(publicDirectory, 'index.html'));
});

// Enquanto o backend completo ainda não terminou de inicializar, APIs recebem
// uma resposta explícita em vez de fazer o processo cair e a Hostinger devolver 503.
shell.use('/api/v1', (req, res, next) => {
  if (fullApplicationReady) return next();
  return res.status(503).json({
    erro: 'Backend inicializando',
    codigo: 'BACKEND_STARTING'
  });
});

const server = shell.listen(PORT, HOST, () => {
  console.log('[finia] HTTP ativo', { node: process.version, host: HOST, port: PORT });
});

server.requestTimeout = 30_000;
server.headersTimeout = 15_000;
server.keepAliveTimeout = 5_000;
server.maxHeadersCount = 100;

async function initializeFullApplication() {
  try {
    require('dotenv').config();
    const { loadConfig } = require('./src/config');
    const {
      createDatabasePool,
      createMigrationRunner,
      testDatabaseConnection
    } = require('./src/database');
    const { createReadiness } = require('./src/lib/readiness');
    const logger = require('./src/lib/logger');
    const { createApplication } = require('./src/app');

    const config = loadConfig(process.env);
    const readiness = createReadiness();
    const pool = createDatabasePool(config.database);
    const fullApp = createApplication({ config, pool, readiness, logger });

    // O app completo é anexado após as rotas de bootstrap. As rotas de API
    // passam a cair nele assim que a flag de readiness é ativada.
    shell.use(fullApp);
    fullApplicationReady = false;
    startupError = null;
    console.log('[finia] aplicação completa carregada');

    const initializeDatabase = async () => {
      try {
        await testDatabaseConnection(pool);
        readiness.set('database', true);
        const migrationRunner = createMigrationRunner({ pool, logger });
        const migrationResult = await migrationRunner.run();
        readiness.set('migrations', true);
        fullApplicationReady = true;
        logger.info('database_migrations_ready', {
          appliedCount: migrationResult.applied.length,
          totalCount: migrationResult.total
        });
      } catch (error) {
        readiness.set('database', false);
        readiness.set('migrations', false);
        fullApplicationReady = false;
        logger.error('database_initialization_failed', {
          errorName: error?.name || 'Error',
          errorCode: error?.code || 'DATABASE_STARTUP_FAILED',
          message: error?.message || 'Falha ao inicializar banco de dados'
        });
      }
    };

    void initializeDatabase();
    const retryTimer = setInterval(() => {
      if (!readiness.snapshot().ready) void initializeDatabase();
    }, 30_000);
    retryTimer.unref();
  } catch (error) {
    startupError = error;
    console.error('[finia] falha ao carregar backend completo', {
      name: error?.name,
      code: error?.code,
      message: error?.message,
      variables: error?.variables
    });
  }
}

// Dá ao proxy da hospedagem tempo para detectar a porta antes de carregar
// módulos e integrações do backend.
setTimeout(() => {
  void initializeFullApplication();
}, 250).unref();

process.on('uncaughtException', (error) => {
  console.error('[finia] uncaughtException', error);
});
process.on('unhandledRejection', (error) => {
  console.error('[finia] unhandledRejection', error);
});
