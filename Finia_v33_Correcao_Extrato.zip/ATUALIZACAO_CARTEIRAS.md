# Finia Finance — atualização da gestão de carteiras e categorias

## Deploy na Hostinger

1. Guarde o backup SQL do banco e o ZIP anterior.
2. Envie este ZIP no fluxo de implantação da aplicação Node.js. A raiz contém package.json e app.js. Não extraia o backend em public_html nem substitua hbuilds manualmente.
3. Mantenha Node.js 24, entrada app.js e as variáveis de ambiente atuais do painel. O .env recebido foi preservado; variáveis do painel têm prioridade.
4. Instalação: npm ci. Build, se solicitado: npm run build. Início: npm start. O frontend em public já está compilado.
5. Não é necessária uma migration adicional para esta atualização. A migration 006 continua disponível para instalações que ainda não receberam carteiras.
6. Verifique login, carteiras, categorias e filtro da home após o deploy. Não importe os SQL antigos de criação no banco atual.

## Alterações desta versão

- Formulário e listas de categorias alinhados na mesma largura, com adaptação para celular.
- Botão de excluir para categorias personalizadas. Categorias fixas do sistema continuam disponíveis. Categorias usadas em lançamentos só podem ser excluídas após a reclassificação desses lançamentos.
- Botões Voltar ao painel padronizados com seta e estilo arredondado dourado.
- Home sem caixas extras de carteiras. O filtro atualiza os cards existentes e os lançamentos.
- Débito e VR: saldo da carteira, entradas e saídas do período e limite mensal configurado na conta.
- Crédito: dívida em aberto, entradas e saídas do período e limite disponível. O limite considera a dívida total, incluindo parcelas futuras; não há renovação mensal automática.
- Todas as carteiras: saldo somado das contas e benefícios, sem somar limite de crédito como dinheiro.
- Pagamento de fatura e histórico removidos da interface e das rotas públicas. Pagamentos antigos permanecem no banco e no cálculo dos saldos para preservar o histórico financeiro.
- Carteiras podem ser excluídas quando não têm lançamentos ou pagamentos antigos vinculados. A exclusão da carteira padrão requer outra conta de débito, que passa a ser padrão automaticamente.
- Exclusões exigem confirmação, autenticação e proteção CSRF, e verificam a propriedade dos dados no servidor.

## Verificação

Build de produção aprovado. 13 testes de regras/repositório aprovados, incluindo exclusões, isolamento entre usuários e proteção de dados vinculados. Teste DOM aprovado para filtro e cards, exclusões visíveis, botões de voltar e ausência das telas de pagamento.
Os testes de banco usam um adaptador SQLite; o MySQL da hospedagem não foi acessado. A conferência visual no navegador e validação do deploy devem ser feitas na hospedagem.

## Atualização v3

Carteiras e Categorias agora ficam na área de funções rápidas da home. O filtro de carteiras permanece acima dos cards. Os botões Voltar ao painel ficam no cabeçalho do conteúdo das páginas, fora da navbar.

Nas novas entradas, Entrada recorrente repete o valor integral mensalmente por 2 a 120 meses, incluindo o mês escolhido. R$ 300 por 3 meses gera 3 lançamentos de R$ 300. Nas saídas, o parcelamento continua dividindo o valor por 2 a 60 parcelas. Trocar entre Entrada e Saída desmarca a repetição para evitar aplicar a modalidade errada. Lançamentos existentes não são convertidos automaticamente.

Build e 14 testes aprovados, incluindo recorrência com dia 31 e divisão das saídas. Conferência DOM aprovada para navegação e alternância das opções do formulário. Não requer nova migration.

## Atualização v4

Formulário de criação antes das carteiras. Lista com duas colunas no desktop e uma em telas até 700px, mostrando apenas nome e exclusão. Atalho e título de edição renomeados para Editar limite débito. Alterações de apresentação, sem mudanças no cálculo ou no banco. Build de produção aprovado.

## Atualização v5

Inserir movimentação e Visão detalhada aparecem primeiro nas funções da home. Os filtros de carteira, período, tipo e categoria estão acima dos gráficos na Visão detalhada. Login, cadastro, recuperação de senha, redefinição, movimentação e limite usam formulários nativos com envio por Enter; categorias, carteiras e configurações já usavam formulários.

SEO: removido o bloqueio global de robots.txt, adicionados sitemap.xml, título descritivo, meta description, canonical e Open Graph. A página pública mantém conteúdo visível sobre o produto. Não foi alterada a autenticação das APIs.

Depois do deploy: abra https://search.google.com/search-console, adicione o domínio finiafinance.com.br, verifique sua propriedade com o registro TXT indicado pelo Google no DNS, envie https://finiafinance.com.br/sitemap.xml em Sitemaps e solicite a indexação de https://finiafinance.com.br/ em Inspeção de URL. Essa etapa depende da sua conta e ainda não foi executada. O Google não garante inclusão nem prazo; o rastreamento pode levar dias ou semanas.

## Atualização v6

- Cartões de crédito têm dia de fechamento (1 a 31). Cartões já existentes podem definir ou alterar o dia na tela Carteiras. Não foi presumido um fechamento para cartões antigos.
- Na Visão detalhada, selecione uma carteira de crédito com fechamento e o período Fatura do cartão; depois escolha Fatura de: mês/ano. O mês é o do fechamento, com o dia de fechamento excluído. Exemplo: dia 10, setembro inclui 10/08 a 09/09. Meses curtos usam seu último dia. Parcelas são classificadas pela data de cada parcela. Alterar o fechamento recalcula a classificação do histórico; não existe fechamento bancário definitivo nem pagamento automático.
- Período Entre duas datas: início e fim inclusivos. Intervalo invertido exibe aviso e nenhum resultado.
- Categorias novas têm escolha entre 12 ícones; categorias antigas recebem o ícone geral.
- Foto/avatar na navegação abre Configurações por clique ou teclado.

A migration 007 adiciona dia_fechamento e icon automaticamente na inicialização. Mantenha um backup SQL atualizado antes do deploy. Não precisa importar SQL manualmente. Build, 15 testes de regras/repositório e verificações DOM passaram, incluindo fechamento, virada do ano, ano bissexto e intervalo inclusivo. MySQL real e renderização visual na hospedagem não foram verificados neste ambiente.

## Atualização v7

O dia do fechamento pertence à próxima fatura. Fechamento dia 25: setembro inclui 25/08 a 24/09; compras em 25/09 entram em outubro. Fechamentos nos dias 29–31 são ajustados ao último dia em meses curtos, que também pertence à fatura seguinte. A classificação é recalculada sem alterar as datas ou valores dos lançamentos.

Ao criar categoria, é possível escolher sua cor. Ela é salva por usuário, aparece no ícone, na borda da categoria e no gráfico de gastos por categoria. Categorias antigas recebem a cor padrão dourada. A migration 008 adiciona o campo automaticamente. Faça backup SQL atualizado antes do deploy.
